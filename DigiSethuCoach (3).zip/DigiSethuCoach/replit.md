# Overview

DigiSethuCoach is an AI-powered digital literacy and skills training simulator designed to provide interactive practice in real-world phone and app scenarios. The application offers five core simulation modes: mock phone calls, text messaging practice, digital payments training, forms filling guidance, and customer support interactions. Each simulation provides audio guidance through text-to-speech technology and delivers personalized feedback to help users build confidence in digital interactions safely.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built with React and TypeScript, using a component-based architecture with Wouter for client-side routing. The UI leverages shadcn/ui components built on top of Radix UI primitives, providing accessible and consistent design patterns. The application follows a mobile-first design approach optimized for smartphone usage.

Key architectural decisions:
- **Component Structure**: Modular components with separation of UI components (`/components/ui/`) and application-specific components
- **State Management**: React Query for server state management and React hooks for local state
- **Styling**: Tailwind CSS with CSS custom properties for theming, supporting both light and dark modes
- **Accessibility**: Text-to-Speech (TTS) integration through Web Speech API for audio guidance and instructions

## Backend Architecture
The server implements a RESTful API using Express.js with TypeScript, following a layered architecture pattern. WebSocket connections enable real-time communication for chat-based simulations.

Core architectural patterns:
- **Storage Abstraction**: Interface-based storage layer (`IStorage`) with in-memory implementation for development
- **Route Organization**: Centralized route registration with middleware for request logging and error handling
- **AI Integration**: OpenAI GPT integration for generating contextual responses and feedback across simulation types
- **Session Management**: WebSocket-based real-time communication for interactive simulations

## Data Layer
The application uses Drizzle ORM with PostgreSQL for production data persistence, while maintaining an in-memory storage option for development and testing.

Database schema design:
- **Users Table**: Basic user authentication and profile management
- **Simulations Table**: Tracks user simulation sessions with status, scoring, and feedback storage
- **Messages Table**: Stores conversation history for chat-based simulations
- **JSONB Storage**: Flexible feedback storage allowing structured scoring and improvement recommendations

## Real-time Communication
WebSocket implementation supports bidirectional communication between client and server for interactive simulations, particularly messaging and support scenarios. The architecture includes automatic reconnection logic and message queuing for reliability.

# External Dependencies

## Core Framework Dependencies
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Express.js**: Node.js web framework for RESTful API development
- **TypeScript**: Type safety across both frontend and backend
- **Vite**: Development server and build tool with hot module replacement

## Database and ORM
- **Drizzle ORM**: Type-safe SQL ORM with PostgreSQL dialect support
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon database
- **Drizzle Kit**: Database migration and schema management tools

## UI and Design System
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Radix UI**: Headless UI components providing accessibility foundations
- **shadcn/ui**: Pre-built component library built on Radix UI primitives
- **Lucide React**: Consistent icon system for UI elements

## AI and Communication
- **OpenAI API**: GPT integration for generating conversational responses and feedback
- **Web Speech API**: Browser-native text-to-speech for accessibility features
- **WebSocket (ws)**: Real-time bidirectional communication for interactive simulations

## Development and Build Tools
- **React Query (@tanstack/react-query)**: Server state management and caching
- **Wouter**: Lightweight client-side routing solution
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility

## Authentication and Session Management
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **Crypto (Node.js)**: Built-in cryptographic functions for secure ID generation

The application is designed to be deployment-ready on platforms like Replit, with environment-based configuration for database connections and API keys. The modular architecture allows for easy scaling and feature additions while maintaining type safety and code quality across the full stack.