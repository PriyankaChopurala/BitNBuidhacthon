import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { HelpModal } from '@/components/HelpModal';
import { useTTSContext } from '@/components/TTSProvider';
import { 
  Phone, 
  MessageCircle, 
  CreditCard, 
  FileText, 
  Headphones, 
  HelpCircle, 
  VolumeX, 
  GraduationCap,
  ChevronRight
} from 'lucide-react';

const simulations = [
  {
    id: 'phone-call',
    title: 'Mock Phone Calls',
    description: 'Practice talking with AI partners',
    icon: Phone,
    color: 'bg-green-100',
    iconColor: 'text-green-600',
    path: '/phone-call'
  },
  {
    id: 'messaging',
    title: 'Text Messages',
    description: 'Learn chat communication skills',
    icon: MessageCircle,
    color: 'bg-blue-100',
    iconColor: 'text-blue-600',
    path: '/messaging'
  },
  {
    id: 'payment',
    title: 'Digital Payments',
    description: 'Safe UPI and wallet practice',
    icon: CreditCard,
    color: 'bg-purple-100',
    iconColor: 'text-purple-600',
    path: '/payment'
  },
  {
    id: 'forms',
    title: 'Online Forms',
    description: 'Practice filling government forms',
    icon: FileText,
    color: 'bg-orange-100',
    iconColor: 'text-orange-600',
    path: '/forms'
  },
  {
    id: 'support',
    title: 'Customer Support',
    description: 'Get help from AI agents',
    icon: Headphones,
    color: 'bg-red-100',
    iconColor: 'text-red-600',
    path: '/support'
  }
];

const progressData = [
  { name: 'Phone Calls', progress: 75 },
  { name: 'Messaging', progress: 50 },
  { name: 'Payments', progress: 25 },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const { speak, isSupported } = useTTSContext();

  const handleAudioGuide = () => {
    if (isSupported) {
      speak(
        "Welcome to DigiSethuCoach! Choose any simulation to start practicing digital skills safely. Each practice session uses AI partners and is completely safe.",
        { rate: 0.9 }
      );
    }
  };

  const handleStartTour = () => {
    setIsHelpOpen(false);
    // TODO: Implement guided tour functionality
    console.log('Starting app tour...');
  };

  const handleSimulationClick = (simulation: typeof simulations[0]) => {
    if (isSupported) {
      speak(
        `Starting ${simulation.title}. ${simulation.description}. Get ready to practice!`,
        { rate: 0.9 }
      );
    }
    setLocation(simulation.path);
  };

  return (
    <>
      <div className="p-4 pb-20">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">DigiSethuCoach</h1>
            <p className="text-muted-foreground text-sm">Digital Skills Training</p>
          </div>
          <Button
            data-testid="button-help"
            onClick={() => setIsHelpOpen(true)}
            className="bg-secondary text-secondary-foreground px-4 py-2 rounded-lg hover:bg-secondary/90 transition-colors"
          >
            <HelpCircle className="w-4 h-4 mr-2" />
            Help
          </Button>
        </div>

        {/* Welcome Card */}
        <Card className="mb-6 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center mb-3">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                <GraduationCap className="text-primary text-xl" />
              </div>
              <div>
                <h2 className="font-semibold text-card-foreground">Welcome to Training!</h2>
                <p className="text-muted-foreground text-sm">Practice digital skills safely</p>
              </div>
            </div>
            <Button
              data-testid="button-audio-guide"
              onClick={handleAudioGuide}
              disabled={!isSupported}
              className="w-full bg-primary text-primary-foreground py-2 rounded-md hover:bg-primary/90 transition-colors"
            >
              <VolumeX className="w-4 h-4 mr-2" />
              Listen to Instructions
            </Button>
          </CardContent>
        </Card>

        {/* Simulation Categories */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg text-foreground mb-3">Choose Your Practice</h3>
          
          {simulations.map((simulation) => {
            const IconComponent = simulation.icon;
            return (
              <Card
                key={simulation.id}
                className="shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleSimulationClick(simulation)}
                data-testid={`card-simulation-${simulation.id}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className={`w-12 h-12 ${simulation.color} rounded-full flex items-center justify-center mr-4`}>
                      <IconComponent className={`${simulation.iconColor} text-xl`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-card-foreground">{simulation.title}</h4>
                      <p className="text-muted-foreground text-sm">{simulation.description}</p>
                    </div>
                    <ChevronRight className="text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Progress Section */}
        <Card className="mt-8 shadow-sm">
          <CardContent className="p-4">
            <h3 className="font-semibold text-card-foreground mb-3">Your Progress</h3>
            <div className="space-y-3">
              {progressData.map((item) => (
                <div key={item.name} className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                  <div className="flex items-center">
                    <div className="w-20 h-2 bg-muted rounded-full mr-2">
                      <div 
                        className="h-2 bg-accent rounded-full transition-all duration-300"
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium">{item.progress}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <HelpModal 
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onStartTour={handleStartTour}
      />
    </>
  );
}
