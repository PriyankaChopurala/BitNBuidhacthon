import { useState, useRef, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useTTSContext } from '@/components/TTSProvider';
import { 
  ArrowLeft, 
  Store, 
  Lock, 
  CreditCard, 
  Building2, 
  Wallet,
  Shield,
  CheckCircle
} from 'lucide-react';

export default function Payment() {
  const [, setLocation] = useLocation();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [pin, setPin] = useState(['', '', '', '']);
  const [showSuccess, setShowSuccess] = useState(false);
  const pinRefs = useRef<(HTMLInputElement | null)[]>([]);
  const { speak } = useTTSContext();

  useEffect(() => {
    speak(
      "Welcome to payment practice! This is a completely safe simulation of digital payments. Enter an amount, add your UPI PIN, and practice making payments. Remember, no real money is involved - this is just for learning!",
      { rate: 0.9 }
    );
  }, [speak]);

  const handlePinChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);

    // Auto-focus next input
    if (value && index < 3) {
      pinRefs.current[index + 1]?.focus();
    }
  };

  const handlePinKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      pinRefs.current[index - 1]?.focus();
    }
  };

  const handlePayment = () => {
    if (!amount || pin.some(digit => !digit)) {
      return;
    }

    // Simulate payment process
    setShowSuccess(true);
    speak("Payment successful! Well done practicing digital payments safely.", { rate: 0.9 });
    
    setTimeout(() => {
      setLocation('/');
    }, 3000);
  };

  if (showSuccess) {
    return (
      <div className="h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Payment Successful!</h2>
          <p className="text-muted-foreground mb-4">
            Great job! You've successfully completed a practice payment.
          </p>
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="text-sm text-muted-foreground">Amount Paid</div>
            <div className="text-2xl font-bold text-foreground">₹{amount}</div>
            <div className="text-sm text-muted-foreground mt-1">to Raj Electronics</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center">
        <Button
          data-testid="button-back"
          onClick={() => setLocation('/')}
          variant="ghost"
          size="sm"
          className="mr-4 text-primary-foreground hover:bg-primary-foreground/10"
        >
          <ArrowLeft className="text-xl" />
        </Button>
        <h2 className="text-lg font-semibold">UPI Payment</h2>
      </div>

      {/* Guidance */}
      <div className="bg-accent/10 border-l-4 border-accent p-4">
        <div className="flex items-start">
          <Shield className="text-accent text-xl mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-accent-foreground mb-1">Safe Practice Payment</h3>
            <p className="text-sm text-accent-foreground">
              This is a safe practice payment. Enter the amount, confirm, and see what happens. No real money involved!
            </p>
          </div>
        </div>
      </div>

      {/* Payment Form */}
      <div className="p-4 space-y-6 overflow-y-auto pb-20">
        {/* Merchant Info */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                <Store className="text-green-600 text-xl" />
              </div>
              <div>
                <h3 className="font-semibold text-card-foreground">Raj Electronics</h3>
                <p className="text-muted-foreground text-sm">9876543210@paytm</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Amount Input */}
        <div>
          <Label htmlFor="amount" className="block text-sm font-medium text-foreground mb-2">
            Enter Amount
          </Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-xl">
              ₹
            </span>
            <Input
              id="amount"
              data-testid="input-amount"
              type="number"
              placeholder="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-input border-border rounded-lg pl-8 pr-4 py-3 text-2xl font-semibold focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>

        {/* Payment Note */}
        <div>
          <Label htmlFor="note" className="block text-sm font-medium text-foreground mb-2">
            Payment Note (Optional)
          </Label>
          <Input
            id="note"
            data-testid="input-note"
            type="text"
            placeholder="Add a note..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="w-full bg-input border-border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* UPI PIN */}
        <div>
          <Label className="block text-sm font-medium text-foreground mb-2">UPI PIN</Label>
          <div className="flex space-x-3">
            {pin.map((digit, index) => (
              <Input
                key={index}
                data-testid={`input-pin-${index}`}
                ref={(el) => pinRefs.current[index] = el}
                type="password"
                maxLength={1}
                value={digit}
                onChange={(e) => handlePinChange(index, e.target.value)}
                onKeyDown={(e) => handlePinKeyDown(index, e)}
                className="w-12 h-12 bg-input border-border rounded-lg text-center text-xl font-bold focus:outline-none focus:ring-2 focus:ring-ring"
              />
            ))}
          </div>
        </div>

        {/* Payment Button */}
        <Button
          data-testid="button-pay"
          onClick={handlePayment}
          disabled={!amount || pin.some(digit => !digit)}
          className="w-full bg-accent text-accent-foreground py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-colors"
        >
          <Lock className="w-5 h-5 mr-2" />
          Pay Securely
        </Button>

        {/* Payment Methods */}
        <div className="pt-4 border-t border-border">
          <h4 className="text-sm font-medium text-foreground mb-3">Other Payment Options</h4>
          <div className="grid grid-cols-3 gap-3">
            <Button
              variant="outline"
              className="p-3 border-border rounded-lg hover:border-primary transition-colors flex flex-col items-center"
            >
              <CreditCard className="text-xl text-muted-foreground mb-2" />
              <div className="text-xs text-muted-foreground">Card</div>
            </Button>
            <Button
              variant="outline"
              className="p-3 border-border rounded-lg hover:border-primary transition-colors flex flex-col items-center"
            >
              <Building2 className="text-xl text-muted-foreground mb-2" />
              <div className="text-xs text-muted-foreground">Bank</div>
            </Button>
            <Button
              variant="outline"
              className="p-3 border-border rounded-lg hover:border-primary transition-colors flex flex-col items-center"
            >
              <Wallet className="text-xl text-muted-foreground mb-2" />
              <div className="text-xs text-muted-foreground">Wallet</div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
