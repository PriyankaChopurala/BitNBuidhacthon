import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useTTSContext } from '@/components/TTSProvider';
import { 
  ArrowLeft, 
  FileText, 
  Send,
  Info,
  CheckCircle
} from 'lucide-react';

interface FormData {
  fullName: string;
  aadhaar: string;
  dob: string;
  gender: string;
  mobile: string;
  email: string;
  address: string;
  pincode: string;
  state: string;
  terms: boolean;
}

export default function Forms() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    aadhaar: '',
    dob: '',
    gender: '',
    mobile: '',
    email: '',
    address: '',
    pincode: '',
    state: '',
    terms: false
  });
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { speak } = useTTSContext();

  useEffect(() => {
    speak(
      "Welcome to form filling practice! This is a safe simulation of a government form. Fill in all the required fields carefully. I will help guide you if you make any mistakes. Take your time and practice entering information correctly.",
      { rate: 0.9 }
    );
  }, [speak]);

  const validateForm = (): boolean => {
    const newErrors: Partial<FormData> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.aadhaar.trim()) {
      newErrors.aadhaar = 'Aadhaar number is required';
    } else if (!/^\d{4}\s\d{4}\s\d{4}$/.test(formData.aadhaar.trim())) {
      newErrors.aadhaar = 'Please enter a valid Aadhaar number (XXXX XXXX XXXX)';
    }

    if (!formData.dob) {
      newErrors.dob = 'Date of birth is required';
    }

    if (!formData.gender) {
      newErrors.gender = 'Gender is required';
    }

    if (!formData.mobile.trim()) {
      newErrors.mobile = 'Mobile number is required';
    } else if (!/^\+91\s\d{5}\s\d{5}$/.test(formData.mobile.trim())) {
      newErrors.mobile = 'Please enter a valid mobile number (+91 98765 43210)';
    }

    if (!formData.address.trim()) {
      newErrors.address = 'Address is required';
    }

    if (!formData.pincode.trim()) {
      newErrors.pincode = 'PIN code is required';
    } else if (!/^\d{6}$/.test(formData.pincode.trim())) {
      newErrors.pincode = 'Please enter a valid 6-digit PIN code';
    }

    if (!formData.state) {
      newErrors.state = 'State is required';
    }

    if (!formData.terms) {
      newErrors.terms = true as any; // Error flag for checkbox
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsSubmitted(true);
      speak("Excellent! You've successfully filled out the form. This is how you complete government forms online.", { rate: 0.9 });
      
      setTimeout(() => {
        setLocation('/');
      }, 3000);
    } else {
      speak("Please check the form for any errors and fill in all required fields.", { rate: 0.9 });
    }
  };

  const handleInputChange = (field: keyof FormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  if (isSubmitted) {
    return (
      <div className="h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Form Submitted Successfully!</h2>
          <p className="text-muted-foreground mb-4">
            Great job! You've learned how to fill government forms online.
          </p>
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="text-sm text-muted-foreground">Application Reference</div>
            <div className="text-lg font-bold text-foreground">ADH2024{Math.random().toString().substr(2, 6)}</div>
            <div className="text-sm text-muted-foreground mt-1">Keep this for your records</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center">
        <Button
          data-testid="button-back"
          onClick={() => setLocation('/')}
          variant="ghost"
          size="sm"
          className="mr-4 text-primary-foreground hover:bg-primary-foreground/10"
        >
          <ArrowLeft className="text-xl" />
        </Button>
        <h2 className="text-lg font-semibold">Aadhaar Update Form</h2>
      </div>

      {/* Guidance */}
      <div className="bg-accent/10 border-l-4 border-accent p-4">
        <div className="flex items-start">
          <Info className="text-accent text-xl mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-accent-foreground mb-1">Practice Form Filling</h3>
            <p className="text-sm text-accent-foreground">
              This is a sample form. Try filling it correctly, and I will guide you if anything is wrong.
            </p>
          </div>
        </div>
      </div>

      {/* Form Content */}
      <div className="p-4 overflow-y-auto pb-20">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">Personal Information</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="fullName" className="block text-sm font-medium text-foreground mb-2">
                  Full Name *
                </Label>
                <Input
                  id="fullName"
                  data-testid="input-full-name"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  className={`w-full ${errors.fullName ? 'border-red-500' : ''}`}
                />
                {errors.fullName && (
                  <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="aadhaar" className="block text-sm font-medium text-foreground mb-2">
                  Aadhaar Number *
                </Label>
                <Input
                  id="aadhaar"
                  data-testid="input-aadhaar"
                  type="text"
                  placeholder="XXXX XXXX XXXX"
                  value={formData.aadhaar}
                  onChange={(e) => handleInputChange('aadhaar', e.target.value)}
                  className={`w-full ${errors.aadhaar ? 'border-red-500' : ''}`}
                />
                {errors.aadhaar && (
                  <p className="text-red-500 text-sm mt-1">{errors.aadhaar}</p>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dob" className="block text-sm font-medium text-foreground mb-2">
                    Date of Birth *
                  </Label>
                  <Input
                    id="dob"
                    data-testid="input-dob"
                    type="date"
                    value={formData.dob}
                    onChange={(e) => handleInputChange('dob', e.target.value)}
                    className={`w-full ${errors.dob ? 'border-red-500' : ''}`}
                  />
                  {errors.dob && (
                    <p className="text-red-500 text-sm mt-1">{errors.dob}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="gender" className="block text-sm font-medium text-foreground mb-2">
                    Gender *
                  </Label>
                  <Select 
                    value={formData.gender}
                    onValueChange={(value) => handleInputChange('gender', value)}
                  >
                    <SelectTrigger 
                      data-testid="select-gender"
                      className={`w-full ${errors.gender ? 'border-red-500' : ''}`}
                    >
                      <SelectValue placeholder="Select Gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.gender && (
                    <p className="text-red-500 text-sm mt-1">{errors.gender}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Contact Information</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="mobile" className="block text-sm font-medium text-foreground mb-2">
                  Mobile Number *
                </Label>
                <Input
                  id="mobile"
                  data-testid="input-mobile"
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={formData.mobile}
                  onChange={(e) => handleInputChange('mobile', e.target.value)}
                  className={`w-full ${errors.mobile ? 'border-red-500' : ''}`}
                />
                {errors.mobile && (
                  <p className="text-red-500 text-sm mt-1">{errors.mobile}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                  Email Address
                </Label>
                <Input
                  id="email"
                  data-testid="input-email"
                  type="email"
                  placeholder="example@email.com"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
          </div>

          {/* Address Information */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Address Information</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="address" className="block text-sm font-medium text-foreground mb-2">
                  Street Address *
                </Label>
                <Textarea
                  id="address"
                  data-testid="input-address"
                  placeholder="Enter your complete address"
                  rows={3}
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className={`w-full ${errors.address ? 'border-red-500' : ''}`}
                />
                {errors.address && (
                  <p className="text-red-500 text-sm mt-1">{errors.address}</p>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pincode" className="block text-sm font-medium text-foreground mb-2">
                    PIN Code *
                  </Label>
                  <Input
                    id="pincode"
                    data-testid="input-pincode"
                    type="text"
                    placeholder="110001"
                    value={formData.pincode}
                    onChange={(e) => handleInputChange('pincode', e.target.value)}
                    className={`w-full ${errors.pincode ? 'border-red-500' : ''}`}
                  />
                  {errors.pincode && (
                    <p className="text-red-500 text-sm mt-1">{errors.pincode}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="state" className="block text-sm font-medium text-foreground mb-2">
                    State *
                  </Label>
                  <Select 
                    value={formData.state}
                    onValueChange={(value) => handleInputChange('state', value)}
                  >
                    <SelectTrigger 
                      data-testid="select-state"
                      className={`w-full ${errors.state ? 'border-red-500' : ''}`}
                    >
                      <SelectValue placeholder="Select State" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="delhi">Delhi</SelectItem>
                      <SelectItem value="maharashtra">Maharashtra</SelectItem>
                      <SelectItem value="karnataka">Karnataka</SelectItem>
                      <SelectItem value="tamil-nadu">Tamil Nadu</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.state && (
                    <p className="text-red-500 text-sm mt-1">{errors.state}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Submit Section */}
          <div className="pt-6 border-t border-border">
            <div className="flex items-start mb-4">
              <Checkbox
                id="terms"
                data-testid="checkbox-terms"
                checked={formData.terms}
                onCheckedChange={(checked) => handleInputChange('terms', !!checked)}
                className={`mt-1 mr-3 ${errors.terms ? 'border-red-500' : ''}`}
              />
              <Label htmlFor="terms" className="text-sm text-foreground cursor-pointer">
                I declare that the information provided is true and accurate to the best of my knowledge.
              </Label>
            </div>
            {errors.terms && (
              <p className="text-red-500 text-sm mb-4">{errors.terms}</p>
            )}
            
            <Button
              data-testid="button-submit-form"
              type="submit"
              className="w-full bg-accent text-accent-foreground py-3 rounded-lg font-semibold hover:bg-accent/90 transition-colors"
            >
              <Send className="w-4 h-4 mr-2" />
              Submit Application
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
