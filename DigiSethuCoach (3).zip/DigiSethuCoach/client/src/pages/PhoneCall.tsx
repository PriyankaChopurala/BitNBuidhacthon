import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useTTSContext } from '@/components/TTSProvider';
import { 
  ArrowLeft, 
  Phone, 
  PhoneOff, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  Building2,
  Info
} from 'lucide-react';

export default function PhoneCall() {
  const [, setLocation] = useLocation();
  const [callTimer, setCallTimer] = useState(0);
  const [isCallActive, setIsCallActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const { speak, isSupported } = useTTSContext();

  useEffect(() => {
    // Auto-start call when component mounts
    setIsCallActive(true);
    speak(
      "You are starting a mock call with a bank agent. Listen carefully and reply as if you are really on the phone. This is safe practice!",
      { rate: 0.9 }
    );
  }, [speak]);

  useEffect(() => {
    if (isCallActive) {
      timerRef.current = setInterval(() => {
        setCallTimer(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isCallActive]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setIsCallActive(false);
    setCallTimer(0);
    // TODO: Show feedback modal before returning home
    setTimeout(() => {
      setLocation('/');
    }, 1000);
  };

  const toggleMute = () => {
    const newMutedState = !isMuted;
    setIsMuted(newMutedState);
    
    if (!newMutedState && isSupported) {
      speak("Microphone unmuted. You can now speak during the call.", { rate: 0.9 });
    }
    // When muted, we don't announce it to avoid confusion
  };

  const toggleSpeaker = () => {
    const newSpeakerState = !isSpeakerOn;
    setIsSpeakerOn(newSpeakerState);
    
    if (isSupported && !isMuted) {
      speak(
        newSpeakerState 
          ? "Speaker phone activated. The call volume is now louder." 
          : "Speaker phone deactivated. Using earpiece mode.",
        { rate: 0.9, volume: newSpeakerState ? 1 : 0.7 }
      );
    }
  };

  return (
    <div className="h-screen bg-slate-900 text-white relative">
      {/* Status Bar */}
      <div className="flex justify-between items-center p-4 text-sm">
        <span>DigiSethu</span>
        <span>{new Date().toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false 
        })}</span>
        <div className="flex space-x-1">
          <div className="w-4 h-2 bg-white rounded-sm"></div>
          <div className="w-1 h-2 bg-white rounded-sm"></div>
          <div className="w-1 h-2 bg-white/50 rounded-sm"></div>
        </div>
      </div>

      {/* Call Header */}
      <div className="text-center py-8">
        <div className="text-sm text-gray-400 mb-2">
          {isCallActive ? 'Connected' : 'Incoming call'}
        </div>
        <div className="text-2xl font-semibold mb-1">Bank Customer Service</div>
        <div className="text-gray-400">+91 98765 43210</div>
      </div>

      {/* Avatar */}
      <div className="flex justify-center my-8">
        <div className="relative">
          <div className="w-32 h-32 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
            <Building2 className="text-4xl text-white" />
          </div>
          {isCallActive && (
            <div className="absolute inset-0 w-32 h-32 border-4 border-white/30 rounded-full animate-ping"></div>
          )}
        </div>
      </div>

      {/* Call Timer */}
      <div className="text-center mb-8">
        <div 
          data-testid="text-call-timer"
          className="text-lg text-gray-300"
        >
          {formatTime(callTimer)}
        </div>
      </div>

      {/* Guidance Message */}
      <div className="mx-4 bg-black/30 backdrop-blur-sm rounded-lg p-4 mb-8">
        <div className="flex items-start">
          <Info className="text-blue-400 mt-1 mr-3 flex-shrink-0" />
          <div>
            <p className="text-sm">
              You are starting a mock call with a bank agent. Listen carefully and reply as if you are really on the phone. This is safe practice!
            </p>
          </div>
        </div>
      </div>

      {/* Call Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6">
        <div className="flex justify-center space-x-8 mb-6">
          {/* Mute */}
          <Button
            data-testid="button-mute"
            onClick={toggleMute}
            className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
              isMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            {isMuted ? <MicOff className="text-xl" /> : <Mic className="text-xl" />}
          </Button>
          
          {/* Speaker */}
          <Button
            data-testid="button-speaker"
            onClick={toggleSpeaker}
            className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
              isSpeakerOn ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            {isSpeakerOn ? <Volume2 className="text-xl" /> : <VolumeX className="text-xl" />}
          </Button>
        </div>
        
        {/* End Call */}
        <div className="flex justify-center space-x-4">
          <Button
            data-testid="button-end-call"
            onClick={handleEndCall}
            className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors"
          >
            <PhoneOff className="text-xl" />
          </Button>
        </div>
      </div>
    </div>
  );
}
