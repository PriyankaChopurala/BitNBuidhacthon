import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useWebSocket } from '@/hooks/use-websocket';
import { useTTSContext } from '@/components/TTSProvider';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  ArrowLeft, 
  Send, 
  Headphones, 
  CreditCard, 
  Lock, 
  Smartphone,
  Info
} from 'lucide-react';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: string;
}

const commonIssues = [
  {
    id: 'payment-failed',
    text: 'Payment not completed',
    icon: CreditCard,
    scenario: 'User needs help with a failed payment transaction'
  },
  {
    id: 'forgot-password',
    text: 'Forgot my password',
    icon: Lock,
    scenario: 'User needs help recovering their account password'
  },
  {
    id: 'mobile-verification',
    text: 'Mobile number not verified',
    icon: Smartphone,
    scenario: 'User needs help verifying their mobile number'
  }
];

export default function Support() {
  const [, setLocation] = useLocation();
  const [currentMessage, setCurrentMessage] = useState('');
  const [simulationId, setSimulationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { speak } = useTTSContext();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Create simulation mutation
  const createSimulationMutation = useMutation({
    mutationFn: async (scenario: string) => {
      const response = await apiRequest('POST', '/api/simulations', {
        type: 'support',
        scenario,
        status: 'active'
      });
      return response.json();
    },
    onSuccess: (simulation) => {
      setSimulationId(simulation.id);
      // Add initial support message
      const initialMessage: Message = {
        id: 'initial',
        sender: 'ai',
        content: "Hello! I'm here to help you with your query. How can I assist you today?",
        timestamp: new Date().toISOString()
      };
      setMessages([initialMessage]);
    }
  });

  // WebSocket for real-time messaging
  const { sendMessage: sendWSMessage } = useWebSocket({
    onMessage: (data) => {
      if (data.type === 'ai_response') {
        setIsTyping(false);
        const aiMessage: Message = {
          id: data.message.id,
          sender: 'ai',
          content: data.message.content,
          timestamp: data.message.timestamp
        };
        setMessages(prev => [...prev, aiMessage]);

        if (data.shouldEnd) {
          // Handle simulation end
          setTimeout(() => {
            setLocation('/');
          }, 2000);
        }
      }
    }
  });

  useEffect(() => {
    // Initialize with general support scenario
    createSimulationMutation.mutate('General customer support inquiry');
    speak(
      "Welcome to customer support practice! This is a safe simulation where you can learn to get help from support agents. Describe your problem clearly, and I will respond like a real support representative. Practice asking questions and explaining issues.",
      { rate: 0.9 }
    );
  }, []);

  const sendMessage = (content: string) => {
    if (!content.trim() || !simulationId) return;

    // Add user message to UI
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: content.trim(),
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, userMessage]);

    // Send to WebSocket for AI response
    sendWSMessage({
      type: 'chat_message',
      simulationId,
      content: content.trim()
    });

    setCurrentMessage('');
    setIsTyping(true);
  };

  const handleQuickIssue = (issue: typeof commonIssues[0]) => {
    // Create new simulation with specific scenario
    createSimulationMutation.mutate(issue.scenario);
    sendMessage(issue.text);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(currentMessage);
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center">
        <Button
          data-testid="button-back"
          onClick={() => setLocation('/')}
          variant="ghost"
          size="sm"
          className="mr-4 text-primary-foreground hover:bg-primary-foreground/10"
        >
          <ArrowLeft className="text-xl" />
        </Button>
        <div className="flex items-center flex-1">
          <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-3">
            <Headphones className="text-white" />
          </div>
          <div>
            <div className="font-semibold">Customer Support</div>
            <div className="text-xs opacity-80">Agent Available</div>
          </div>
        </div>
      </div>

      {/* Guidance Banner */}
      <div className="bg-accent/10 border-l-4 border-accent p-3">
        <div className="flex items-center">
          <Info className="text-accent mr-2" />
          <p className="text-sm text-accent-foreground">
            This is a practice support session. Ask your question, and I will guide you like a real support agent.
          </p>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'items-start'}`}
          >
            {message.sender === 'ai' && (
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                <Headphones className="text-white text-sm" />
              </div>
            )}
            
            <div
              className={`max-w-xs p-3 rounded-lg ${
                message.sender === 'user'
                  ? 'bg-primary text-primary-foreground ml-auto'
                  : 'bg-muted'
              }`}
              style={{
                borderRadius: message.sender === 'user' 
                  ? '1rem 1rem 0.25rem 1rem' 
                  : '1rem 1rem 1rem 0.25rem'
              }}
            >
              {message.sender === 'ai' && (
                <p className="text-sm font-medium mb-1">Support Agent</p>
              )}
              <p className="text-sm">{message.content}</p>
              <div className={`text-xs mt-1 ${
                message.sender === 'user' 
                  ? 'text-primary-foreground/70' 
                  : 'text-muted-foreground'
              }`}>
                {formatTime(message.timestamp)}
              </div>
            </div>
          </div>
        ))}

        {/* Quick Actions */}
        {messages.length === 1 && (
          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium text-card-foreground mb-3">Common Issues</h4>
              <div className="space-y-2">
                {commonIssues.map((issue) => {
                  const IconComponent = issue.icon;
                  return (
                    <Button
                      key={issue.id}
                      data-testid={`button-quick-issue-${issue.id}`}
                      onClick={() => handleQuickIssue(issue)}
                      variant="outline"
                      className="w-full justify-start px-3 py-2 text-sm bg-muted hover:bg-muted/80 transition-colors"
                    >
                      <IconComponent className="mr-2 text-primary" />
                      {issue.text}
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start">
            <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center mr-3 mt-1">
              <Headphones className="text-white text-sm" />
            </div>
            <div 
              className="bg-muted p-3 rounded-lg"
              style={{ borderRadius: '1rem 1rem 1rem 0.25rem' }}
            >
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <Input
            data-testid="input-support-message"
            type="text"
            placeholder="Describe your problem..."
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-input border-border rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <Button
            data-testid="button-send-support-message"
            onClick={() => sendMessage(currentMessage)}
            disabled={!currentMessage.trim()}
            className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
