import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TTSProvider } from "@/components/TTSProvider";
import { Layout } from "@/components/Layout";
import Home from "@/pages/Home";
import PhoneCall from "@/pages/PhoneCall";
import Messaging from "@/pages/Messaging";
import Payment from "@/pages/Payment";
import Forms from "@/pages/Forms";
import Support from "@/pages/Support";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/phone-call">
        <Layout showBottomNav={false}>
          <PhoneCall />
        </Layout>
      </Route>
      <Route path="/messaging">
        <Layout showBottomNav={false}>
          <Messaging />
        </Layout>
      </Route>
      <Route path="/payment">
        <Layout showBottomNav={false}>
          <Payment />
        </Layout>
      </Route>
      <Route path="/forms">
        <Layout showBottomNav={false}>
          <Forms />
        </Layout>
      </Route>
      <Route path="/support">
        <Layout showBottomNav={false}>
          <Support />
        </Layout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <TTSProvider>
          <Layout>
            <Toaster />
            <Router />
          </Layout>
        </TTSProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
