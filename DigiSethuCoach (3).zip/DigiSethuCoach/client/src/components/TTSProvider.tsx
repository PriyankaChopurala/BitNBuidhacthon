import { createContext, useContext, ReactNode } from 'react';
import { useTTS } from '@/hooks/use-tts';

interface TTSContextType {
  isSupported: boolean;
  isSpeaking: boolean;
  speak: (text: string, options?: { rate?: number; pitch?: number; volume?: number; lang?: string }) => void;
  stop: () => void;
  pause: () => void;
  resume: () => void;
}

const TTSContext = createContext<TTSContextType | undefined>(undefined);

interface TTSProviderProps {
  children: ReactNode;
}

export function TTSProvider({ children }: TTSProviderProps) {
  const tts = useTTS();

  return (
    <TTSContext.Provider value={tts}>
      {children}
    </TTSContext.Provider>
  );
}

export function useTTSContext() {
  const context = useContext(TTSContext);
  if (context === undefined) {
    throw new Error('useTTSContext must be used within a TTSProvider');
  }
  return context;
}
