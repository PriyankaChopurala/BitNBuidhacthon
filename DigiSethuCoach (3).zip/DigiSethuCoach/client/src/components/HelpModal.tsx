import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Play, X } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartTour: () => void;
}

export function HelpModal({ isOpen, onClose, onStartTour }: HelpModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bottom-0 translate-y-0 max-w-md mx-auto rounded-t-xl p-6 max-h-96 overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold text-foreground">
              How to Use DigiSethuCoach
            </DialogTitle>
            <Button
              data-testid="button-close-help"
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground p-1"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <div className="border-l-4 border-primary pl-4">
            <h4 className="font-semibold text-foreground mb-1">Getting Started</h4>
            <p className="text-sm text-muted-foreground">
              Choose any simulation from the home screen to start practicing. Each simulation is completely safe and uses AI partners.
            </p>
          </div>
          
          <div className="border-l-4 border-secondary pl-4">
            <h4 className="font-semibold text-foreground mb-1">Audio Guidance</h4>
            <p className="text-sm text-muted-foreground">
              Look for the speaker icon to hear instructions read aloud. This helps you understand what to do in each simulation.
            </p>
          </div>
          
          <div className="border-l-4 border-accent pl-4">
            <h4 className="font-semibold text-foreground mb-1">Safe Practice</h4>
            <p className="text-sm text-muted-foreground">
              All payments, calls, and messages are simulated. No real money or data is involved. Practice freely!
            </p>
          </div>
          
          <div className="border-l-4 border-orange-500 pl-4">
            <h4 className="font-semibold text-foreground mb-1">Getting Feedback</h4>
            <p className="text-sm text-muted-foreground">
              After each simulation, you'll see your score and tips for improvement. Keep practicing to get better!
            </p>
          </div>
        </div>
        
        <Button
          data-testid="button-start-tour"
          onClick={onStartTour}
          className="w-full mt-6 bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
        >
          <Play className="w-4 h-4 mr-2" />
          Start App Tour
        </Button>
      </DialogContent>
    </Dialog>
  );
}
