import { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';
import { useLocation } from 'wouter';

interface LayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
}

export function Layout({ children, showBottomNav = true }: LayoutProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background relative">
      {children}
      
      {showBottomNav && (
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 max-w-md mx-auto">
          <div className="flex justify-center">
            <Button
              data-testid="button-home-nav"
              onClick={() => setLocation('/')}
              className="px-6 py-2 bg-primary text-primary-foreground rounded-full font-medium hover:bg-primary/90 transition-colors"
            >
              <Home className="w-4 h-4 mr-2" />
              Home
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
