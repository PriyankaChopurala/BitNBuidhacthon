import { useCallback, useRef, useState } from 'react';

export function useTTS() {
  const [isSupported, setIsSupported] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const checkSupport = useCallback(() => {
    const supported = 'speechSynthesis' in window;
    setIsSupported(supported);
    return supported;
  }, []);

  const speak = useCallback((text: string, options?: { rate?: number; pitch?: number; volume?: number; lang?: string }) => {
    if (!checkSupport()) {
      console.warn('Speech synthesis not supported');
      return;
    }

    // Stop any current speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options?.rate || 0.9;
    utterance.pitch = options?.pitch || 1;
    utterance.volume = options?.volume || 1;
    utterance.lang = options?.lang || 'en-US';

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [checkSupport]);

  const stop = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  const pause = useCallback(() => {
    window.speechSynthesis.pause();
  }, []);

  const resume = useCallback(() => {
    window.speechSynthesis.resume();
  }, []);

  // Initialize support check
  useState(() => {
    checkSupport();
  });

  return {
    isSupported,
    isSpeaking,
    speak,
    stop,
    pause,
    resume
  };
}
