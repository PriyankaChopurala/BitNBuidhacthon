import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

export interface ConversationContext {
  type: 'phone-call' | 'messaging' | 'support';
  scenario: string;
  messages: Array<{ sender: 'user' | 'ai'; content: string }>;
}

export interface AIResponse {
  content: string;
  shouldEnd?: boolean;
  score?: number;
  feedback?: string;
}

export async function generateAIResponse(context: ConversationContext): Promise<AIResponse> {
  try {
    const systemPrompts = {
      'phone-call': `You are playing the role of a professional customer service representative in a phone call simulation. The scenario is: ${context.scenario}. 
      
      Guidelines:
      - Speak naturally as if you're on a phone call
      - Be helpful, patient, and professional
      - Ask clarifying questions when needed
      - Keep responses conversational and not too long
      - If the user seems confused, gently guide them
      - End the call naturally when the issue is resolved
      
      Respond with JSON in this format: { "content": "your response", "shouldEnd": false, "score": 0-100, "feedback": "brief feedback if call should end" }`,
      
      'messaging': `You are an AI partner for text messaging practice. The scenario is: ${context.scenario}.
      
      Guidelines:
      - Write like a real person texting
      - Use casual but polite language
      - Keep messages short and natural
      - Help the user practice good communication skills
      - Be encouraging and supportive
      
      Respond with JSON in this format: { "content": "your message", "shouldEnd": false }`,
      
      'support': `You are a customer support agent helping with the issue: ${context.scenario}.
      
      Guidelines:
      - Be professional and helpful
      - Ask for specific information you need
      - Provide clear step-by-step solutions
      - Show empathy for the customer's problem
      - Follow up to ensure the issue is resolved
      
      Respond with JSON in this format: { "content": "your response", "shouldEnd": false, "score": 0-100, "feedback": "brief feedback if issue is resolved" }`
    };

    const messages = [
      { role: "system" as const, content: systemPrompts[context.type] },
      ...context.messages.map(msg => ({
        role: msg.sender === 'user' ? 'user' as const : 'assistant' as const,
        content: msg.content
      }))
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      content: result.content || "I'm sorry, I didn't understand that. Could you please repeat?",
      shouldEnd: result.shouldEnd || false,
      score: result.score || undefined,
      feedback: result.feedback || undefined
    };
  } catch (error) {
    console.error('AI generation error:', error);
    return {
      content: "I'm sorry, I'm having trouble responding right now. Please try again.",
      shouldEnd: false
    };
  }
}

export async function generateFeedback(type: string, messages: Array<{ sender: string; content: string }>): Promise<{ score: number; feedback: string; strengths: string[]; improvements: string[] }> {
  try {
    const prompt = `Analyze this ${type} simulation conversation and provide feedback. 
    
    Messages: ${JSON.stringify(messages)}
    
    Provide a score (0-100) and detailed feedback including:
    - Overall score based on communication effectiveness
    - Strengths shown by the user
    - Areas for improvement
    - Specific next steps
    
    Respond with JSON in this format: {
      "score": number,
      "feedback": "overall feedback summary",
      "strengths": ["strength1", "strength2"],
      "improvements": ["improvement1", "improvement2"]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      score: result.score || 50,
      feedback: result.feedback || "Good effort! Keep practicing to improve your skills.",
      strengths: result.strengths || ["Completed the simulation"],
      improvements: result.improvements || ["Practice more to build confidence"]
    };
  } catch (error) {
    console.error('Feedback generation error:', error);
    return {
      score: 50,
      feedback: "Simulation completed. Keep practicing to improve your digital skills!",
      strengths: ["Completed the practice session"],
      improvements: ["Continue practicing to build confidence"]
    };
  }
}
