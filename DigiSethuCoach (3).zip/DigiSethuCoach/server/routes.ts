import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { generateAIResponse, generateFeedback } from "./services/ai";
import { insertSimulationSchema, insertMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create simulation
  app.post("/api/simulations", async (req, res) => {
    try {
      const validatedData = insertSimulationSchema.parse(req.body);
      const simulation = await storage.createSimulation(validatedData);
      res.json(simulation);
    } catch (error) {
      res.status(400).json({ error: "Invalid simulation data" });
    }
  });

  // Get simulation
  app.get("/api/simulations/:id", async (req, res) => {
    try {
      const simulation = await storage.getSimulation(req.params.id);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }
      res.json(simulation);
    } catch (error) {
      res.status(500).json({ error: "Failed to get simulation" });
    }
  });

  // Complete simulation
  app.post("/api/simulations/:id/complete", async (req, res) => {
    try {
      const simulation = await storage.getSimulation(req.params.id);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }

      const messages = await storage.getSimulationMessages(req.params.id);
      const feedback = await generateFeedback(simulation.type, messages);

      const updated = await storage.updateSimulation(req.params.id, {
        status: 'completed',
        score: feedback.score,
        feedback: feedback,
        completedAt: new Date()
      });

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to complete simulation" });
    }
  });

  // Get simulation messages
  app.get("/api/simulations/:id/messages", async (req, res) => {
    try {
      const messages = await storage.getSimulationMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'chat_message') {
          // Save user message
          const userMessage = await storage.createMessage({
            simulationId: message.simulationId,
            sender: 'user',
            content: message.content
          });

          // Get simulation context
          const simulation = await storage.getSimulation(message.simulationId);
          if (!simulation) return;

          // Get conversation history
          const messages = await storage.getSimulationMessages(message.simulationId);
          const conversationHistory = messages.map(msg => ({
            sender: msg.sender as 'user' | 'ai',
            content: msg.content
          }));

          // Generate AI response
          const aiResponse = await generateAIResponse({
            type: simulation.type as any,
            scenario: simulation.scenario,
            messages: conversationHistory
          });

          // Save AI message
          const aiMessage = await storage.createMessage({
            simulationId: message.simulationId,
            sender: 'ai',
            content: aiResponse.content
          });

          // Send response back to client
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'ai_response',
              message: aiMessage,
              shouldEnd: aiResponse.shouldEnd,
              score: aiResponse.score,
              feedback: aiResponse.feedback
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Failed to process message'
          }));
        }
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  return httpServer;
}
