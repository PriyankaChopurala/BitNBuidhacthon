import { type User, type InsertUser, type Simulation, type InsertSimulation, type Message, type InsertMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createSimulation(simulation: InsertSimulation): Promise<Simulation>;
  getSimulation(id: string): Promise<Simulation | undefined>;
  getUserSimulations(userId: string): Promise<Simulation[]>;
  updateSimulation(id: string, updates: Partial<Simulation>): Promise<Simulation | undefined>;
  
  createMessage(message: InsertMessage): Promise<Message>;
  getSimulationMessages(simulationId: string): Promise<Message[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private simulations: Map<string, Simulation>;
  private messages: Map<string, Message>;

  constructor() {
    this.users = new Map();
    this.simulations = new Map();
    this.messages = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async createSimulation(insertSimulation: InsertSimulation): Promise<Simulation> {
    const id = randomUUID();
    const simulation: Simulation = {
      ...insertSimulation,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.simulations.set(id, simulation);
    return simulation;
  }

  async getSimulation(id: string): Promise<Simulation | undefined> {
    return this.simulations.get(id);
  }

  async getUserSimulations(userId: string): Promise<Simulation[]> {
    return Array.from(this.simulations.values()).filter(
      (simulation) => simulation.userId === userId
    );
  }

  async updateSimulation(id: string, updates: Partial<Simulation>): Promise<Simulation | undefined> {
    const simulation = this.simulations.get(id);
    if (!simulation) return undefined;
    
    const updated = { ...simulation, ...updates };
    this.simulations.set(id, updated);
    return updated;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getSimulationMessages(simulationId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.simulationId === simulationId)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime());
  }
}

export const storage = new MemStorage();
