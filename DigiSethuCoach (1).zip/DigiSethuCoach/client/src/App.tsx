import { Switch, Route } from "wouter";
import { useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LocalStorage, STORAGE_KEYS } from "@/lib/storage";

// Pages
import PhoneEntry from "@/pages/phone-entry";
import Welcome from "@/pages/welcome";
import Home from "@/pages/home";
import CategoryDetail from "@/pages/category-detail";
import Practice from "@/pages/practice";
import NotFound from "@/pages/not-found";

function Router() {
  const isFirstLaunch = LocalStorage.get<boolean>(STORAGE_KEYS.IS_FIRST_LAUNCH) ?? true;

  return (
    <Switch>
      <Route path="/" component={isFirstLaunch ? PhoneEntry : Home} />
      <Route path="/phone-entry" component={PhoneEntry} />
      <Route path="/welcome" component={Welcome} />
      <Route path="/home" component={Home} />
      <Route path="/category/:categoryId" component={CategoryDetail} />
      <Route path="/practice/:categoryId/:scenarioId" component={Practice} />
      <Route path="/practice/:categoryId" component={Practice} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  useEffect(() => {
    // Register service worker for PWA functionality
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then((registration) => {
            console.log('SW registered: ', registration);
          })
          .catch((registrationError) => {
            console.log('SW registration failed: ', registrationError);
          });
      });
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
