import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/header';
import { useLocalStorage } from '@/hooks/use-storage';
import { LocalStorage, STORAGE_KEYS } from '@/lib/storage';
import { categories } from '@shared/schema';
import type { UserProgress, CategoryId } from '@/types';

export default function Home() {
  const [, setLocation] = useLocation();
  const [userProgress, setUserProgress] = useLocalStorage<UserProgress>(STORAGE_KEYS.USER_PROGRESS, {
    dialer: false,
    sms: false,
    whatsapp: false,
    "upi-send": false,
    "upi-scanner": false,
    "upi-history": false,
    facebook: false,
    instagram: false,
    ott: false
  });
  const [readWhileTyping, setReadWhileTyping] = useLocalStorage<boolean>(STORAGE_KEYS.READ_WHILE_TYPING, false);

  const completedCount = Object.values(userProgress).filter(Boolean).length;
  const totalCount = Object.keys(userProgress).length;
  const progressPercentage = (completedCount / totalCount) * 100;

  const handleCategoryClick = (categoryId: CategoryId) => {
    setLocation(`/category/${categoryId}`);
  };

  const handleToggleChange = (checked: boolean) => {
    setReadWhileTyping(checked);
  };

  const getCategoryIcon = (categoryId: string) => {
    switch (categoryId) {
      case 'general':
        return 'fas fa-phone';
      case 'finance':
        return 'fas fa-credit-card';
      case 'entertainment':
        return 'fas fa-play';
      default:
        return 'fas fa-circle';
    }
  };

  const getCategoryColor = (categoryId: string) => {
    switch (categoryId) {
      case 'general':
        return 'blue';
      case 'finance':
        return 'green';
      case 'entertainment':
        return 'red';
      default:
        return 'gray';
    }
  };

  const getBadgeStyles = (practice: string, color: string) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
    
    switch (color) {
      case 'blue':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'green':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'red':
        return `${baseClasses} bg-red-100 text-red-800`;
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        showToggle={true}
        readWhileTyping={readWhileTyping}
        onToggleChange={handleToggleChange}
      />

      <main className="flex-1 p-6">
        <div className="max-w-md mx-auto space-y-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-2" data-testid="text-main-title">
              Choose a Category
            </h2>
            <p className="text-muted-foreground" data-testid="text-main-subtitle">
              Select what you'd like to practice today
            </p>
          </div>

          <div className="space-y-4">
            {categories.map((category) => (
              <Card 
                key={category.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1"
                onClick={() => handleCategoryClick(category.id as CategoryId)}
                data-testid={`card-category-${category.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 bg-${category.color}-100 rounded-lg flex items-center justify-center`}>
                      <i className={`${getCategoryIcon(category.id)} text-${category.color}-600 text-xl`}></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-card-foreground" data-testid={`text-category-title-${category.id}`}>
                        {category.title}
                      </h3>
                      <p className="text-sm text-muted-foreground" data-testid={`text-category-description-${category.id}`}>
                        {category.description}
                      </p>
                    </div>
                    <i className="fas fa-chevron-right text-muted-foreground"></i>
                  </div>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    {category.scenarios.map((scenario) => (
                      <span 
                        key={scenario.id}
                        className={getBadgeStyles(scenario.title, category.color)}
                        data-testid={`badge-practice-${scenario.id}`}
                      >
                        {scenario.title}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Progress Section */}
          <Card className="bg-accent mt-8">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-accent-foreground" data-testid="text-progress-title">
                  Your Progress
                </h4>
                <span className="text-sm text-muted-foreground" data-testid="text-progress-count">
                  {completedCount}/{totalCount} completed
                </span>
              </div>
              <div className="w-full bg-border rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${progressPercentage}%` }}
                  data-testid="progress-bar"
                ></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
