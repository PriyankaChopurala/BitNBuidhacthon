import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { validatePhoneNumber } from '@/lib/validation';
import { LocalStorage, STORAGE_KEYS } from '@/lib/storage';
import { useSpeech } from '@/hooks/use-speech';

export default function PhoneEntry() {
  const [, setLocation] = useLocation();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');
  const { speak } = useSpeech();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validation = validatePhoneNumber(phoneNumber);
    
    if (!validation.isValid) {
      setError(validation.message);
      return;
    }

    // Save phone number and mark first launch as complete
    LocalStorage.set(STORAGE_KEYS.PHONE_NUMBER, phoneNumber);
    LocalStorage.set(STORAGE_KEYS.IS_FIRST_LAUNCH, false);
    
    // Navigate to welcome screen
    setLocation('/welcome');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center p-6">
      <Card className="w-full max-w-md shadow-xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-mobile-alt text-white text-2xl"></i>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2" data-testid="text-welcome-title">
              Welcome to Digi Sethu
            </h1>
            <p className="text-gray-600" data-testid="text-welcome-subtitle">
              Enter your phone number to get started
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-gray-500">+91</span>
                <Input
                  type="tel"
                  id="phoneNumber"
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value);
                    setError('');
                  }}
                  className="pl-12 text-lg h-12"
                  placeholder="Enter 10-digit number"
                  maxLength={10}
                  data-testid="input-phone"
                />
              </div>
              {error && (
                <p className="text-sm text-red-600 mt-1" data-testid="text-error">{error}</p>
              )}
              <p className="text-sm text-gray-500 mt-1">Must be at least 10 digits</p>
            </div>
            
            <Button 
              type="submit" 
              className="w-full h-12 text-lg"
              data-testid="button-continue"
            >
              Continue
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
