import { useLocation, useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/header';
import { useSpeech } from '@/hooks/use-speech';
import { useLocalStorage } from '@/hooks/use-storage';
import { categories } from '@shared/schema';
import { STORAGE_KEYS } from '@/lib/storage';
import type { CategoryId, UserProgress, ScenarioData } from '@/types';

export default function CategoryDetail() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute('/category/:categoryId');
  const { speak } = useSpeech();
  const [userProgress] = useLocalStorage<UserProgress>(STORAGE_KEYS.USER_PROGRESS, {
    dialer: false,
    sms: false,
    whatsapp: false,
    "upi-send": false,
    "upi-scanner": false,
    "upi-history": false,
    facebook: false,
    instagram: false,
    ott: false,
  });
  
  if (!match || !params?.categoryId) {
    setLocation('/home');
    return null;
  }

  const categoryId = params.categoryId as CategoryId;
  const category = categories.find(c => c.id === categoryId);

  if (!category) {
    setLocation('/home');
    return null;
  }

  const handleBack = () => {
    setLocation('/home');
  };

  const handleScenarioInstructions = (scenario: ScenarioData) => {
    speak(scenario.instructions);
  };

  const handleScenarioPractice = (scenario: ScenarioData) => {
    setLocation(`/practice/${categoryId}/${scenario.id}`);
  };

  const isScenarioCompleted = (scenarioId: string) => {
    return userProgress[scenarioId as keyof UserProgress] || false;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        title={category.title}
        showBackButton={true}
        onBackClick={handleBack}
      />

      <main className="flex-1 p-6">
        <div className="max-w-md mx-auto space-y-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <i className={`${category.icon} text-white text-xl`}></i>
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2" data-testid="text-category-title">
              Choose an App to Practice
            </h2>
            <p className="text-muted-foreground" data-testid="text-category-subtitle">
              Select which app interface you'd like to learn
            </p>
          </div>

          <div className="space-y-4">
            {category.scenarios.map((scenario) => {
              const isCompleted = isScenarioCompleted(scenario.id);
              
              return (
                <Card 
                  key={scenario.id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-200"
                  data-testid={`card-scenario-${scenario.id}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                          <i className={`${scenario.icon} text-gray-600 text-xl`}></i>
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground">{scenario.title}</h3>
                          <p className="text-sm text-muted-foreground">{scenario.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">App: {scenario.appName}</p>
                        </div>
                        {isCompleted && (
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <i className="fas fa-check text-white text-xs"></i>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 border-blue-200 text-blue-700 hover:bg-blue-50"
                        onClick={() => handleScenarioInstructions(scenario)}
                        data-testid={`button-instructions-${scenario.id}`}
                      >
                        <i className="fas fa-volume-up mr-2"></i>
                        Instructions
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        className="flex-1 bg-green-500 hover:bg-green-600"
                        onClick={() => handleScenarioPractice(scenario)}
                        data-testid={`button-practice-${scenario.id}`}
                      >
                        <i className="fas fa-keyboard mr-2"></i>
                        Practice
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
}
