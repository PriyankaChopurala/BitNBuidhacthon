import { useState, useEffect } from 'react';
import { useLocation, useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/header';
import { SimulatorShell, LightSimulatorShell } from '@/components/simulator-shell';
import { useSimulator } from '@/components/simulator-context';
import { ActionButton, InputField, Keypad } from '@/components/primitives';
import { MobilePracticeInterface } from '@/components/mobile-practice-interface';
import { useSpeech } from '@/hooks/use-speech';
import { useLocalStorage } from '@/hooks/use-storage';
import { validatePracticeInput, validatePracticeInputByCategory } from '@/lib/validation';
import { STORAGE_KEYS } from '@/lib/storage';
import { categories } from '@shared/schema';
import type { CategoryId, ScenarioId, UserProgress, ScenarioData } from '@/types';

// Helper function to find scenario data
const findScenarioData = (categoryId: CategoryId, scenarioId?: ScenarioId): ScenarioData | null => {
  const category = categories.find(c => c.id === categoryId);
  if (!category) return null;
  
  if (scenarioId) {
    return category.scenarios.find(s => s.id === scenarioId) || null;
  }
  
  // For backward compatibility - return first scenario if no specific scenario provided
  return category.scenarios[0] || null;
};

export default function Practice() {
  const [, setLocation] = useLocation();
  // Try scenario-specific route first, then fall back to category-only route
  const [scenarioMatch, scenarioParams] = useRoute('/practice/:categoryId/:scenarioId');
  const [categoryMatch, categoryParams] = useRoute('/practice/:categoryId');
  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const [userProgress, setUserProgress] = useLocalStorage<UserProgress>(STORAGE_KEYS.USER_PROGRESS, {
    dialer: false,
    sms: false,
    whatsapp: false,
    "upi-send": false,
    "upi-scanner": false,
    "upi-history": false,
    facebook: false,
    instagram: false,
    ott: false,
  });
  const [readWhileTyping] = useLocalStorage<boolean>(STORAGE_KEYS.READ_WHILE_TYPING, false);
  const { speak } = useSpeech();

  // Determine which route matched and extract parameters
  let categoryId: CategoryId;
  let scenarioId: ScenarioId | undefined;
  
  if (scenarioMatch && scenarioParams) {
    categoryId = scenarioParams.categoryId as CategoryId;
    scenarioId = scenarioParams.scenarioId as ScenarioId;
  } else if (categoryMatch && categoryParams) {
    categoryId = categoryParams.categoryId as CategoryId;
    scenarioId = undefined;
  } else {
    setLocation('/home');
    return null;
  }

  const scenario = findScenarioData(categoryId, scenarioId);
  
  if (!scenario) {
    setLocation('/home');
    return null;
  }

  const handleBack = () => {
    setLocation(`/category/${categoryId}`);
  };

  // If we have a specific scenarioId, use the mobile simulator
  if (scenarioId) {
    return (
      <SimulatorShell scenario={scenario} onBackClick={handleBack}>
        <MobilePracticeInterface scenario={scenario} scenarioId={scenarioId} />
      </SimulatorShell>
    );
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInput(value);
    setFeedback({ type: null, message: '' });

    // Speak character if read while typing is enabled
    if (readWhileTyping && value.length > input.length) {
      const newChar = value.slice(-1);
      speak(newChar);
    }
  };

  const handleValidation = () => {
    let validation;
    
    if (scenarioId) {
      // Use scenario-specific validation
      validation = validatePracticeInput(input, scenarioId);
    } else {
      // Use category-based validation for backward compatibility
      validation = validatePracticeInputByCategory(input, categoryId);
    }
    
    if (validation.isValid) {
      setFeedback({ type: 'success', message: 'Well done! You completed the practice.' });
      speak('Well done. You completed the practice.');
      
      // Update progress - track scenario completion
      if (scenarioId) {
        setUserProgress(prev => ({
          ...prev,
          [scenarioId]: true
        }));
      }
    } else {
      setFeedback({ type: 'error', message: validation.message });
      speak('Try again. Follow the instructions and try again.');
    }
  };

  const handleContinue = () => {
    setLocation('/home');
  };

  // Fallback to old interface for backward compatibility (category-only routes)
  return (
    <LightSimulatorShell>
      <div className="min-h-screen bg-background">
        <Header 
          title="Practice"
          showBackButton={true}
          onBackClick={handleBack}
        />

        <main className="flex-1 p-6">
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className={`${scenario.icon} text-gray-600 text-xl`}></i>
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-2" data-testid="text-practice-title">
                {scenario.title} Practice
              </h2>
              <p className="text-muted-foreground mb-2" data-testid="text-practice-prompt">
                {scenario.prompt}
              </p>
              <p className="text-xs text-muted-foreground" data-testid="text-app-name">
                App: {scenario.appName}
              </p>
            </div>

            <div className="space-y-6">
              <div>
                <label htmlFor="practiceInput" className="block text-sm font-medium text-gray-700 mb-2">
                  {scenario.label}
                </label>
                <Input
                  type="text"
                  id="practiceInput"
                  value={input}
                  onChange={handleInputChange}
                  className="text-lg h-12"
                  placeholder={scenario.placeholder}
                  data-testid="input-practice"
                />
                <p className="text-sm text-gray-500 mt-1" data-testid="text-input-hint">
                  {scenario.hint}
                </p>
              </div>

              <Button 
                onClick={handleValidation} 
                className="w-full h-12 text-lg"
                data-testid="button-check-answer"
              >
                Check Answer
              </Button>
            </div>

            {/* Feedback Section */}
            {feedback.type && (
              <Card className={`mt-8 ${feedback.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      feedback.type === 'success' ? 'bg-green-500' : 'bg-red-500'
                    }`}>
                      <i className={`fas ${feedback.type === 'success' ? 'fa-check' : 'fa-times'} text-white`}></i>
                    </div>
                    <span 
                      className={`font-semibold ${feedback.type === 'success' ? 'text-green-800' : 'text-red-800'}`}
                      data-testid="text-feedback"
                    >
                      {feedback.message}
                    </span>
                  </div>
                  
                  {feedback.type === 'success' && (
                    <Button 
                      onClick={handleContinue}
                      className="w-full mt-4 bg-green-500 hover:bg-green-600"
                      data-testid="button-continue-learning"
                    >
                      Continue Learning
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </LightSimulatorShell>
  );
}
