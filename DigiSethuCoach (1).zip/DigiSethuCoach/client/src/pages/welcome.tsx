import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useSpeech } from '@/hooks/use-speech';

export default function Welcome() {
  const [, setLocation] = useLocation();
  const { speak } = useSpeech();

  useEffect(() => {
    speak('Welcome! Your phone number has been saved successfully. Let\'s begin your digital learning journey.');
  }, [speak]);

  const handleGetStarted = () => {
    setLocation('/home');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center p-6">
      <Card className="w-full max-w-md shadow-xl">
        <CardContent className="p-8 text-center">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-check text-white text-2xl"></i>
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-4" data-testid="text-welcome">
            Welcome!
          </h2>
          
          <p className="text-gray-600 mb-6" data-testid="text-success-message">
            Your phone number has been saved successfully. Let's begin your digital learning journey.
          </p>
          
          <Button 
            onClick={handleGetStarted}
            className="w-full h-12 bg-green-500 hover:bg-green-600"
            data-testid="button-get-started"
          >
            Get Started
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
