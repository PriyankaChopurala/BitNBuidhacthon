export class LocalStorage {
  static get<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error(`Error getting ${key} from localStorage:`, error);
      return null;
    }
  }

  static set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error setting ${key} in localStorage:`, error);
    }
  }

  static remove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error(`Error removing ${key} from localStorage:`, error);
    }
  }

  static clear(): void {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }
}

export const STORAGE_KEYS = {
  PHONE_NUMBER: 'userPhone',
  IS_FIRST_LAUNCH: 'isFirstLaunch',
  USER_PROGRESS: 'userProgress',
  READ_WHILE_TYPING: 'readWhileTyping',
} as const;

// Migration utility for old category-based progress to new scenario-based progress
export function migrateUserProgress(): void {
  try {
    const existingProgress = LocalStorage.get<any>(STORAGE_KEYS.USER_PROGRESS);
    
    if (!existingProgress) return;
    
    // Check if it's the old format (has 'general', 'finance', 'entertainment' keys)
    const isOldFormat = typeof existingProgress === 'object' && 
      ('general' in existingProgress || 'finance' in existingProgress || 'entertainment' in existingProgress);
    
    if (isOldFormat) {
      // Migrate old format to new format
      const newProgress = {
        // General scenarios
        dialer: existingProgress.general || false,
        sms: existingProgress.general || false,
        whatsapp: existingProgress.general || false,
        // Finance scenarios
        "upi-send": existingProgress.finance || false,
        "upi-scanner": existingProgress.finance || false,
        "upi-history": existingProgress.finance || false,
        // Entertainment scenarios
        facebook: existingProgress.entertainment || false,
        instagram: existingProgress.entertainment || false,
        ott: existingProgress.entertainment || false,
      };
      
      LocalStorage.set(STORAGE_KEYS.USER_PROGRESS, newProgress);
      console.log('Migrated user progress from category-based to scenario-based format');
    }
  } catch (error) {
    console.error('Error migrating user progress:', error);
  }
}

// Call migration on module load
migrateUserProgress();
