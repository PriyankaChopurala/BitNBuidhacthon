import type { CategoryId, ScenarioId } from '@/types';

export interface ValidationResult {
  isValid: boolean;
  message: string;
}

export function validatePhoneNumber(phone: string): ValidationResult {
  const cleaned = phone.trim();
  
  if (cleaned.length < 10) {
    return {
      isValid: false,
      message: 'Phone number must be at least 10 digits'
    };
  }
  
  if (!/^\d+$/.test(cleaned)) {
    return {
      isValid: false,
      message: 'Phone number must contain only digits'
    };
  }
  
  return {
    isValid: true,
    message: 'Valid phone number'
  };
}

export function validateByRule(input: string, rule: 'phone' | 'upi' | 'message' | 'search'): ValidationResult {
  const trimmedInput = input.trim();
  
  switch (rule) {
    case 'phone':
      // Phone number validation (exactly 10 digits)
      if (trimmedInput.length !== 10) {
        return {
          isValid: false,
          message: 'Phone number must be exactly 10 digits'
        };
      }
      if (!/^\d+$/.test(trimmedInput)) {
        return {
          isValid: false,
          message: 'Phone number must contain only digits'
        };
      }
      return {
        isValid: true,
        message: 'Valid phone number'
      };
      
    case 'upi':
      // UPI ID validation (must contain @)
      if (!trimmedInput.includes('@')) {
        return {
          isValid: false,
          message: 'UPI ID must contain @ symbol'
        };
      }
      if (trimmedInput.length < 5) {
        return {
          isValid: false,
          message: 'UPI ID is too short'
        };
      }
      return {
        isValid: true,
        message: 'Valid UPI ID'
      };
      
    case 'message':
      // Text validation (at least 3 characters)
      if (trimmedInput.length < 3) {
        return {
          isValid: false,
          message: 'Message must be at least 3 characters'
        };
      }
      return {
        isValid: true,
        message: 'Valid message'
      };
      
    case 'search':
      // Search validation (at least 2 characters)
      if (trimmedInput.length < 2) {
        return {
          isValid: false,
          message: 'Search must be at least 2 characters'
        };
      }
      return {
        isValid: true,
        message: 'Valid search query'
      };
      
    default:
      return {
        isValid: false,
        message: 'Unknown validation rule'
      };
  }
}

export function validatePracticeInput(input: string, scenarioId: ScenarioId): ValidationResult {
  // Map scenarios to validation rules
  const scenarioRules: Record<ScenarioId, 'phone' | 'upi' | 'message' | 'search'> = {
    'dialer': 'phone',
    'sms': 'message',
    'whatsapp': 'search',
    'upi-send': 'upi',
    'upi-scanner': 'search',
    'upi-history': 'search',
    'facebook': 'search',
    'instagram': 'search',
    'ott': 'search'
  };
  
  const rule = scenarioRules[scenarioId];
  if (!rule) {
    return {
      isValid: false,
      message: 'Unknown scenario'
    };
  }
  
  return validateByRule(input, rule);
}

// Legacy function for backward compatibility
export function validatePracticeInputByCategory(input: string, category: CategoryId): ValidationResult {
  const trimmedInput = input.trim();
  
  switch (category) {
    case 'general':
      return validateByRule(trimmedInput, 'phone');
    case 'finance':
      return validateByRule(trimmedInput, 'upi');
    case 'entertainment':
      return validateByRule(trimmedInput, 'message');
    default:
      return {
        isValid: false,
        message: 'Unknown category'
      };
  }
}
