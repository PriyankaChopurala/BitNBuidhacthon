import { ToggleSwitch } from './toggle-switch';

interface HeaderProps {
  title?: string;
  showBackButton?: boolean;
  onBackClick?: () => void;
  showToggle?: boolean;
  readWhileTyping?: boolean;
  onToggleChange?: (checked: boolean) => void;
}

export function Header({ 
  title = "Digi Sethu", 
  showBackButton = false, 
  onBackClick,
  showToggle = false,
  readWhileTyping = false,
  onToggleChange
}: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-border p-4">
      <div className="flex items-center justify-between max-w-md mx-auto">
        <div className="flex items-center space-x-3">
          {showBackButton && (
            <button 
              onClick={onBackClick} 
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              data-testid="button-back"
            >
              <i className="fas fa-arrow-left text-gray-600"></i>
            </button>
          )}
          
          {!showBackButton && (
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white"></i>
            </div>
          )}
          
          <h1 className="text-xl font-bold text-foreground" data-testid="text-title">{title}</h1>
        </div>
        
        {showToggle && onToggleChange && (
          <div className="flex items-center space-x-3">
            <span className="text-sm text-muted-foreground">Read while typing</span>
            <ToggleSwitch 
              checked={readWhileTyping} 
              onChange={onToggleChange}
              data-testid="toggle-speech"
            />
          </div>
        )}
      </div>
    </header>
  );
}
