import { createContext, useContext, useCallback, ReactNode } from 'react';
import { useSpeech } from '@/hooks/use-speech';
import { useLocalStorage } from '@/hooks/use-storage';
import { validatePracticeInput, type ValidationResult } from '@/lib/validation';
import { STORAGE_KEYS } from '@/lib/storage';
import type { ScenarioId, UserProgress } from '@/types';

interface SimulatorContextValue {
  // TTS functions
  speak: (text: string, options?: { rate?: number; pitch?: number; volume?: number }) => void;
  stopSpeech: () => void;
  isSpeaking: boolean;
  
  // Settings
  readWhileTyping: boolean;
  setReadWhileTyping: (enabled: boolean) => void;
  
  // Progress tracking
  userProgress: UserProgress;
  markScenarioComplete: (scenarioId: ScenarioId) => void;
  
  // Validation
  validateInput: (input: string, scenarioId: ScenarioId) => ValidationResult;
  
  // Feedback
  provideFeedback: (success: boolean, message?: string) => void;
}

const SimulatorContext = createContext<SimulatorContextValue | null>(null);

export interface SimulatorProviderProps {
  children: ReactNode;
}

export function SimulatorProvider({ children }: SimulatorProviderProps) {
  const { speak, stop: stopSpeech, isPlaying: isSpeaking } = useSpeech();
  const [readWhileTyping, setReadWhileTyping] = useLocalStorage<boolean>(STORAGE_KEYS.READ_WHILE_TYPING, false);
  const [userProgress, setUserProgress] = useLocalStorage<UserProgress>(STORAGE_KEYS.USER_PROGRESS, {
    dialer: false,
    sms: false,
    whatsapp: false,
    "upi-send": false,
    "upi-scanner": false,
    "upi-history": false,
    facebook: false,
    instagram: false,
    ott: false,
  });

  const markScenarioComplete = useCallback((scenarioId: ScenarioId) => {
    setUserProgress(prev => ({
      ...prev,
      [scenarioId]: true
    }));
  }, [setUserProgress]);

  const validateInput = useCallback((input: string, scenarioId: ScenarioId) => {
    return validatePracticeInput(input, scenarioId);
  }, []);

  const provideFeedback = useCallback((success: boolean, message?: string) => {
    const feedbackMessage = message || (success ? 'Well done! You completed the practice.' : 'Try again. Follow the instructions and try again.');
    speak(feedbackMessage);
  }, [speak]);

  const handleCharacterInput = useCallback((char: string) => {
    if (readWhileTyping && char.trim()) {
      speak(char);
    }
  }, [speak, readWhileTyping]);

  const contextValue: SimulatorContextValue = {
    speak,
    stopSpeech,
    isSpeaking,
    readWhileTyping,
    setReadWhileTyping,
    userProgress,
    markScenarioComplete,
    validateInput,
    provideFeedback,
  };

  return (
    <SimulatorContext.Provider value={contextValue}>
      {children}
    </SimulatorContext.Provider>
  );
}

export function useSimulator(): SimulatorContextValue {
  const context = useContext(SimulatorContext);
  if (!context) {
    throw new Error('useSimulator must be used within a SimulatorProvider');
  }
  return context;
}

// Additional hook for character-by-character input with TTS
export function useSimulatorInput() {
  const { speak, readWhileTyping } = useSimulator();
  
  const handleInputChange = useCallback((value: string, previousValue: string = '') => {
    if (readWhileTyping && value.length > previousValue.length) {
      const newChar = value.slice(-1);
      speak(newChar);
    }
  }, [speak, readWhileTyping]);

  return { handleInputChange };
}