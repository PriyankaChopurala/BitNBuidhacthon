import { ReactNode } from 'react';
import { SimulatorProvider } from './simulator-context';
import { StatusBar, AppHeader } from './primitives';
import type { ScenarioData } from '@/types';

export interface SimulatorShellProps {
  scenario: ScenarioData;
  children: ReactNode;
  onBackClick: () => void;
}

export function SimulatorShell({ scenario, children, onBackClick }: SimulatorShellProps) {
  return (
    <SimulatorProvider>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
        {/* Mobile Phone Frame */}
        <div className="relative">
          {/* Outer Phone Case */}
          <div className="bg-gradient-to-b from-gray-900 to-black rounded-[3rem] p-1 shadow-2xl">
            {/* Phone Frame/Bezel */}
            <div className="bg-black rounded-[2.8rem] p-[6px] shadow-inner">
              {/* Screen Container with realistic proportions */}
              <div className="bg-white rounded-[2.2rem] overflow-hidden w-[375px] h-[812px] relative shadow-lg">
                {/* Status Bar */}
                <StatusBar />
                
                {/* App Header */}
                <AppHeader
                  appName={scenario.appName}
                  appIcon={scenario.icon}
                  onBackClick={onBackClick}
                />
                
                {/* Main Content Area */}
                <div className="flex-1 bg-gray-50 overflow-hidden" style={{ height: 'calc(100% - 88px)' }}>
                  <div className="h-full overflow-y-auto">
                    {children}
                  </div>
                </div>
                
                {/* Home Indicator (iPhone style) */}
                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 z-20">
                  <div className="w-32 h-1 bg-black rounded-full opacity-40" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SimulatorProvider>
  );
}

// Alternative lightweight shell for non-simulator mode (backward compatibility)
export interface LightSimulatorShellProps {
  children: ReactNode;
}

export function LightSimulatorShell({ children }: LightSimulatorShellProps) {
  return (
    <SimulatorProvider>
      <div className="min-h-screen bg-background">
        {children}
      </div>
    </SimulatorProvider>
  );
}