import { useState } from 'react';
import { useLocation } from 'wouter';
import { useSimulator } from './simulator-context';
import { ActionButton, InputField, Keypad, ContactCard, MessageBubble } from './primitives';
import type { ScenarioData, ScenarioId } from '@/types';

interface MobilePracticeInterfaceProps {
  scenario: ScenarioData;
  scenarioId: ScenarioId;
}

export function MobilePracticeInterface({ scenario, scenarioId }: MobilePracticeInterfaceProps) {
  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const [showSuccess, setShowSuccess] = useState(false);
  const [, setLocation] = useLocation();
  
  // UPI-specific state management
  const [upiStep, setUpiStep] = useState<'upiId' | 'amount' | 'confirm'>('upiId');
  const [upiData, setUpiData] = useState({
    upiId: '',
    amount: '',
    recipientName: '',
    merchantName: '',
    transactionId: ''
  });
  const [scanningActive, setScanningActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { validateInput, provideFeedback, markScenarioComplete } = useSimulator();

  const handleInputChange = (value: string) => {
    setInput(value);
    setFeedback({ type: null, message: '' });
  };

  const handleValidation = () => {
    const validation = validateInput(input, scenarioId);
    
    if (validation.isValid) {
      setFeedback({ type: 'success', message: 'Well done! You completed the practice.' });
      provideFeedback(true, 'Well done! You completed the practice.');
      markScenarioComplete(scenarioId);
      setShowSuccess(true);
    } else {
      setFeedback({ type: 'error', message: validation.message });
      provideFeedback(false, 'Try again. Follow the instructions and try again.');
    }
  };

  const handleContinue = () => {
    setLocation('/home');
  };

  // Enhanced keypad with delete button for dialer
  const handleDialerKeyPress = (key: string) => {
    if (key === 'delete') {
      setInput(prev => prev.slice(0, -1));
    } else if (key === 'call') {
      handleValidation();
    } else {
      setInput(prev => prev + key);
    }
  };

  // Format phone number for display (e.g., 123-456-7890)
  const formatPhoneDisplay = (number: string) => {
    if (number.length === 0) return '';
    if (number.length <= 3) return number;
    if (number.length <= 6) return `${number.slice(0, 3)}-${number.slice(3)}`;
    return `${number.slice(0, 3)}-${number.slice(3, 6)}-${number.slice(6, 10)}`;
  };

  const handleKeyPress = (key: string) => {
    if (key === 'call') {
      handleValidation();
    } else {
      setInput(prev => prev + key);
    }
  };

  // Render different interfaces based on scenario type
  const renderScenarioInterface = () => {
    switch (scenarioId) {
      case 'dialer':
        return (
          <div className="h-full flex flex-col bg-white">
            {/* Phone number display area */}
            <div className="flex-1 flex flex-col justify-center px-8 py-6 bg-gradient-to-b from-gray-50 to-white">
              <div className="text-center">
                <div className="text-4xl font-light text-gray-900 min-h-[3rem] flex items-center justify-center mb-2">
                  {input ? formatPhoneDisplay(input) : <span className="text-gray-400">Enter number</span>}
                </div>
                <div className="text-sm text-gray-500">
                  {input.length === 0 && "Tap numbers to dial"}
                  {input.length > 0 && input.length < 10 && `${10 - input.length} more digits needed`}
                  {input.length === 10 && "Ready to call"}
                </div>
              </div>
            </div>
            
            {/* Enhanced keypad */}
            <div className="bg-white pb-6">
              {/* Numbers grid */}
              <div className="grid grid-cols-3 gap-6 px-8 mb-6">
                {[
                  ['1', ''], ['2', 'ABC'], ['3', 'DEF'],
                  ['4', 'GHI'], ['5', 'JKL'], ['6', 'MNO'],
                  ['7', 'PQRS'], ['8', 'TUV'], ['9', 'WXYZ'],
                  ['*', ''], ['0', '+'], ['#', '']
                ].map(([digit, letters]) => (
                  <button
                    key={digit}
                    onClick={() => handleDialerKeyPress(digit)}
                    disabled={showSuccess}
                    className="h-16 w-16 rounded-full bg-gray-100 hover:bg-gray-200 active:bg-gray-300 
                             flex flex-col items-center justify-center transition-colors duration-150
                             disabled:opacity-50 disabled:cursor-not-allowed"
                    data-testid={`button-keypad-${digit}`}
                  >
                    <span className="text-2xl font-normal text-gray-900">{digit}</span>
                    {letters && <span className="text-xs text-gray-500 -mt-1">{letters}</span>}
                  </button>
                ))}
              </div>
              
              {/* Action buttons */}
              <div className="flex items-center justify-center space-x-12 px-8">
                {/* Delete button */}
                <button
                  onClick={() => handleDialerKeyPress('delete')}
                  disabled={!input || showSuccess}
                  className="h-12 w-12 rounded-full flex items-center justify-center
                           disabled:opacity-30 disabled:cursor-not-allowed
                           active:bg-gray-200 transition-colors duration-150"
                  data-testid="button-delete"
                >
                  <i className="fas fa-backspace text-gray-600 text-lg"></i>
                </button>
                
                {/* Call button */}
                <button
                  onClick={() => handleDialerKeyPress('call')}
                  disabled={input.length !== 10 || showSuccess}
                  className="h-16 w-16 rounded-full bg-green-500 hover:bg-green-600 active:bg-green-700
                           disabled:bg-gray-300 disabled:cursor-not-allowed
                           flex items-center justify-center transition-all duration-200
                           shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
                  data-testid="button-call"
                >
                  <i className="fas fa-phone text-white text-xl"></i>
                </button>
                
                {/* Placeholder for symmetry */}
                <div className="h-12 w-12"></div>
              </div>
            </div>
          </div>
        );
        
      case 'sms':
        return (
          <div className="h-full flex flex-col bg-white">
            {/* Contact header - iOS Messages style */}
            <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center flex-1">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mr-3 flex items-center justify-center">
                    <span className="text-white font-semibold text-lg">M</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 text-lg">Mom</h3>
                    <p className="text-sm text-gray-500">iMessage</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <button className="p-2 rounded-full hover:bg-gray-200">
                    <i className="fas fa-phone text-blue-500 text-lg"></i>
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-200">
                    <i className="fas fa-video text-blue-500 text-lg"></i>
                  </button>
                </div>
              </div>
            </div>
            
            {/* Messages conversation area */}
            <div className="flex-1 p-4 overflow-y-auto bg-gray-50" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(0,0,0,0.15) 1px, transparent 0)', backgroundSize: '20px 20px' }}>
              <div className="space-y-4">
                {/* Sample conversation messages */}
                <div className="flex justify-start">
                  <div className="max-w-xs">
                    <div className="bg-white rounded-2xl rounded-bl-md px-4 py-2 shadow-sm">
                      <p className="text-gray-900">Hey! How was your day?</p>
                    </div>
                    <div className="text-xs text-gray-500 mt-1 ml-3">2:30 PM</div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <div className="max-w-xs">
                    <div className="bg-blue-500 text-white rounded-2xl rounded-br-md px-4 py-2">
                      <p>It was great! Just finished work.</p>
                    </div>
                    <div className="text-xs text-gray-500 mt-1 mr-3 text-right">2:32 PM</div>
                  </div>
                </div>
                
                {/* User's current message being typed */}
                {input.trim() && (
                  <div className="flex justify-end">
                    <div className="max-w-xs">
                      <div className="bg-blue-500 text-white rounded-2xl rounded-br-md px-4 py-2">
                        <p>{input}</p>
                      </div>
                      <div className="text-xs text-gray-500 mt-1 mr-3 text-right flex items-center justify-end">
                        <span>now</span>
                        <i className="fas fa-circle text-blue-500 text-xs ml-2" title="Sending..."></i>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Message composer - iOS style */}
            <div className="bg-white border-t border-gray-200 px-4 py-3">
              <div className="flex items-end space-x-3">
                <button className="p-2 rounded-full hover:bg-gray-100 flex-shrink-0">
                  <i className="fas fa-camera text-gray-500"></i>
                </button>
                
                <div className="flex-1 relative">
                  <div className="bg-gray-100 rounded-full px-4 py-2 min-h-[40px] flex items-center">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="iMessage"
                      className="flex-1 bg-transparent outline-none text-gray-900 placeholder-gray-500"
                      data-testid="input-message"
                    />
                    {input.trim() && (
                      <button
                        onClick={handleValidation}
                        className="ml-2 text-blue-500 font-semibold hover:text-blue-600"
                        data-testid="button-send-message"
                      >
                        Send
                      </button>
                    )}
                  </div>
                </div>
                
                {!input.trim() && (
                  <button className="p-2 rounded-full hover:bg-gray-100 flex-shrink-0">
                    <i className="fas fa-microphone text-gray-500"></i>
                  </button>
                )}
              </div>
            </div>
          </div>
        );
        
      case 'whatsapp':
        return (
          <div className="h-full flex flex-col bg-white">
            {/* WhatsApp header */}
            <div className="bg-green-600 px-4 py-3">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <h1 className="text-white text-xl font-medium">WhatsApp</h1>
                </div>
                <div className="flex items-center space-x-4">
                  <button className="text-white hover:text-green-200">
                    <i className="fas fa-camera text-lg"></i>
                  </button>
                  <button className="text-white hover:text-green-200">
                    <i className="fas fa-search text-lg"></i>
                  </button>
                  <button className="text-white hover:text-green-200">
                    <i className="fas fa-ellipsis-v text-lg"></i>
                  </button>
                </div>
              </div>
              
              {/* Search bar */}
              <div className="relative">
                <div className="bg-white bg-opacity-20 rounded-full px-4 py-2 flex items-center">
                  <i className="fas fa-search text-white opacity-70 mr-3"></i>
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => handleInputChange(e.target.value)}
                    placeholder="Search or start new chat"
                    className="flex-1 bg-transparent text-white placeholder-white placeholder-opacity-70 outline-none"
                    data-testid="input-search"
                  />
                </div>
              </div>
            </div>
            
            {/* Contact/Chat list */}
            <div className="flex-1 overflow-y-auto bg-white">
              {!input ? (
                // Default contact list when no search
                <div className="divide-y divide-gray-100">
                  {[
                    { name: "Mom", message: "How was your day?", time: "3:45 PM", unread: 2, avatar: "M" },
                    { name: "John Smith", message: "See you tomorrow!", time: "2:30 PM", unread: 0, avatar: "J" },
                    { name: "Work Group", message: "Meeting at 10 AM", time: "1:15 PM", unread: 5, avatar: "W" },
                    { name: "Sarah Wilson", message: "Thanks for lunch!", time: "Yesterday", unread: 0, avatar: "S" },
                    { name: "Dad", message: "Call me when you're free", time: "Yesterday", unread: 1, avatar: "D" }
                  ].map((contact, index) => (
                    <div key={index} className="flex items-center px-4 py-3 hover:bg-gray-50 active:bg-gray-100">
                      <div className="w-12 h-12 rounded-full mr-3 flex items-center justify-center bg-gray-300 flex-shrink-0">
                        <span className="text-white font-semibold">{contact.avatar}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold text-gray-900 truncate">{contact.name}</h3>
                          <div className="flex items-center">
                            <span className="text-xs text-gray-500">{contact.time}</span>
                            {contact.unread > 0 && (
                              <div className="bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center ml-2">
                                {contact.unread}
                              </div>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 truncate">{contact.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                // Search results and chat interface
                <div className="h-full flex flex-col">
                  {input.length >= 2 ? (
                    // Chat interface when user has typed enough
                    <div className="h-full flex flex-col">
                      {/* Chat header */}
                      <div className="bg-gray-50 border-b border-gray-200 px-4 py-3">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full mr-3 flex items-center justify-center bg-gray-400">
                            <span className="text-white font-semibold">{input.charAt(0).toUpperCase()}</span>
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{input}</h3>
                            <p className="text-sm text-gray-500">online</p>
                          </div>
                          <div className="flex items-center space-x-3">
                            <button className="text-green-600">
                              <i className="fas fa-video text-lg"></i>
                            </button>
                            <button className="text-green-600">
                              <i className="fas fa-phone text-lg"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                      
                      {/* Chat messages area */}
                      <div className="flex-1 p-4 bg-gray-100" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23e5e7eb' fill-opacity='0.3' fill-rule='evenodd'%3E%3Cpath d='m0 40l40-40h-40v40z'/%3E%3C/g%3E%3C/svg%3E")` }}>
                        <div className="space-y-3">
                          <div className="flex justify-start">
                            <div className="bg-white rounded-lg rounded-bl-sm px-3 py-2 max-w-xs shadow-sm">
                              <p className="text-gray-900">Hi there! How can I help you today?</p>
                              <div className="text-xs text-gray-500 mt-1">10:30 AM</div>
                            </div>
                          </div>
                          
                          {/* Show user's practice message when ready */}
                          {input.length >= 2 && (
                            <div className="flex justify-end">
                              <div className="bg-green-500 text-white rounded-lg rounded-br-sm px-3 py-2 max-w-xs">
                                <p>Hello {input}! This is a practice message.</p>
                                <div className="text-xs text-green-100 mt-1 flex items-center justify-end">
                                  <span>now</span>
                                  <i className="fas fa-check-double ml-2 text-xs"></i>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Message composer */}
                      <div className="bg-gray-50 border-t border-gray-200 px-4 py-3">
                        <div className="flex items-end space-x-3">
                          <button className="text-gray-500 hover:text-gray-700">
                            <i className="fas fa-smile text-xl"></i>
                          </button>
                          
                          <div className="flex-1 bg-white rounded-full px-4 py-2 border border-gray-200">
                            <div className="flex items-center">
                              <input
                                type="text"
                                placeholder="Type a message"
                                className="flex-1 outline-none text-gray-900"
                                readOnly
                              />
                              <button className="text-gray-500 hover:text-gray-700 ml-2">
                                <i className="fas fa-paperclip"></i>
                              </button>
                            </div>
                          </div>
                          
                          <button
                            onClick={handleValidation}
                            className="bg-green-500 hover:bg-green-600 text-white w-10 h-10 rounded-full flex items-center justify-center"
                            data-testid="button-send-message"
                          >
                            <i className="fas fa-paper-plane"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    // Search suggestions
                    <div className="p-4">
                      <p className="text-gray-500 text-center">Start typing to search contacts...</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );
        
      case 'upi-send':
        return (
          <div className="h-full flex flex-col bg-gradient-to-b from-blue-50 to-white">
            {/* Google Pay style header */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-500 px-6 py-4 text-white">
              <div className="flex items-center mb-3">
                <button className="mr-4">
                  <i className="fas fa-arrow-left text-xl"></i>
                </button>
                <h1 className="text-xl font-semibold">Send Money</h1>
              </div>
              <div className="flex items-center space-x-2">
                <i className="fas fa-shield-alt text-lg"></i>
                <span className="text-sm opacity-90">Secure & Encrypted</span>
              </div>
            </div>
            
            {upiStep === 'upiId' && (
              <div className="flex-1 p-6">
                {/* Quick contacts */}
                <div className="mb-6">
                  <h3 className="text-gray-700 font-medium mb-3">Recent Contacts</h3>
                  <div className="flex space-x-4 overflow-x-auto pb-2">
                    {['Mom', 'Dad', 'Shop', 'John'].map((contact, index) => (
                      <div key={index} className="flex-shrink-0 text-center">
                        <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mb-2">
                          <span className="text-white font-semibold text-lg">{contact[0]}</span>
                        </div>
                        <span className="text-xs text-gray-600">{contact}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* UPI ID input */}
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 mb-6">
                  <div className="flex items-center mb-3">
                    <i className="fas fa-at text-blue-500 mr-2"></i>
                    <h4 className="font-semibold text-gray-800">Enter UPI ID</h4>
                  </div>
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => handleInputChange(e.target.value)}
                    placeholder="john@paytm, 9876543210@ybl"
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none text-lg"
                    data-testid="input-upi"
                  />
                  <p className="text-sm text-gray-500 mt-2">Enter phone number or UPI ID</p>
                </div>
                
                <button
                  onClick={() => {
                    if (input.includes('@') && input.length >= 5) {
                      setUpiData(prev => ({ ...prev, upiId: input, recipientName: input.split('@')[0] }));
                      setUpiStep('amount');
                      setInput('');
                    } else {
                      setFeedback({ type: 'error', message: 'Please enter a valid UPI ID with @ symbol' });
                    }
                  }}
                  disabled={!input.trim() || showSuccess}
                  className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-4 rounded-xl font-semibold text-lg 
                           disabled:bg-gray-300 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform transition-all
                           disabled:transform-none"
                  data-testid="button-continue"
                >
                  Continue
                </button>
              </div>
            )}
            
            {upiStep === 'amount' && (
              <div className="flex-1 p-6">
                {/* Recipient info */}
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 mb-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-semibold text-lg">{upiData.recipientName[0]?.toUpperCase()}</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 capitalize">{upiData.recipientName}</h3>
                      <p className="text-sm text-gray-500">{upiData.upiId}</p>
                    </div>
                    <i className="fas fa-check-circle text-green-500 text-xl"></i>
                  </div>
                </div>
                
                {/* Amount input */}
                <div className="text-center mb-8">
                  <div className="mb-4">
                    <span className="text-4xl font-light text-gray-400">₹</span>
                    <input
                      type="number"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="0"
                      className="text-4xl font-light text-gray-900 bg-transparent outline-none text-center w-48"
                      data-testid="input-amount"
                    />
                  </div>
                  <p className="text-gray-500">Enter amount to send</p>
                </div>
                
                {/* Quick amount buttons */}
                <div className="grid grid-cols-3 gap-3 mb-8">
                  {['100', '500', '1000'].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setInput(amount)}
                      className="bg-gray-100 hover:bg-gray-200 py-3 rounded-lg font-medium text-gray-700"
                      data-testid={`button-amount-${amount}`}
                    >
                      ₹{amount}
                    </button>
                  ))}
                </div>
                
                <button
                  onClick={() => {
                    if (parseFloat(input) >= 1 && parseFloat(input) <= 100000) {
                      setUpiData(prev => ({ ...prev, amount: input }));
                      setUpiStep('confirm');
                    } else {
                      setFeedback({ type: 'error', message: 'Amount must be between ₹1 and ₹100,000' });
                    }
                  }}
                  disabled={!input || parseFloat(input) < 1 || showSuccess}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-semibold text-lg 
                           disabled:bg-gray-300 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform transition-all
                           disabled:transform-none"
                  data-testid="button-pay-now"
                >
                  Pay ₹{input || '0'}
                </button>
              </div>
            )}
            
            {upiStep === 'confirm' && (
              <div className="flex-1 p-6">
                {/* Transaction summary */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-rupee-sign text-white text-2xl"></i>
                    </div>
                    <h2 className="text-2xl font-bold text-gray-800">₹{upiData.amount}</h2>
                    <p className="text-gray-500">to {upiData.recipientName}</p>
                  </div>
                  
                  <div className="space-y-3 border-t pt-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">From</span>
                      <span className="font-medium">****1234 SBI</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">To</span>
                      <span className="font-medium">{upiData.upiId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Transaction Fee</span>
                      <span className="font-medium text-green-600">FREE</span>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={handleValidation}
                  disabled={showSuccess}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-semibold text-lg 
                           disabled:bg-gray-300 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform transition-all
                           disabled:transform-none flex items-center justify-center"
                  data-testid="button-confirm-payment"
                >
                  <i className="fas fa-lock mr-2"></i>
                  Confirm Payment
                </button>
                
                <p className="text-center text-sm text-gray-500 mt-4">
                  <i className="fas fa-shield-alt mr-1"></i>
                  Protected by 256-bit encryption
                </p>
              </div>
            )}
          </div>
        );
        
      case 'upi-scanner':
        return (
          <div className="h-full flex flex-col bg-black">
            {/* Scanner header */}
            <div className="bg-black text-white px-6 py-4 relative z-10">
              <div className="flex items-center mb-2">
                <button className="mr-4">
                  <i className="fas fa-arrow-left text-xl"></i>
                </button>
                <h1 className="text-xl font-semibold">QR Scanner</h1>
                <div className="ml-auto">
                  <button className="p-2">
                    <i className="fas fa-image text-lg"></i>
                  </button>
                </div>
              </div>
              <p className="text-sm opacity-75">Point camera at QR code to scan</p>
            </div>
            
            {!scanningActive ? (
              <div className="flex-1 relative bg-black">
                {/* Mock camera viewfinder */}
                <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-black flex items-center justify-center">
                  <div className="relative">
                    {/* Scanning frame */}
                    <div className="w-64 h-64 relative">
                      {/* Corner frames */}
                      <div className="absolute top-0 left-0 w-8 h-8 border-l-4 border-t-4 border-green-400"></div>
                      <div className="absolute top-0 right-0 w-8 h-8 border-r-4 border-t-4 border-green-400"></div>
                      <div className="absolute bottom-0 left-0 w-8 h-8 border-l-4 border-b-4 border-green-400"></div>
                      <div className="absolute bottom-0 right-0 w-8 h-8 border-r-4 border-b-4 border-green-400"></div>
                      
                      {/* Scanning line animation */}
                      <div className="absolute inset-0 border border-green-400 border-opacity-50">
                        <div className="w-full h-1 bg-gradient-to-r from-transparent via-green-400 to-transparent 
                                     animate-pulse" style={{ animation: 'scan 2s linear infinite' }}></div>
                      </div>
                      
                      {/* Mock QR code appears when user types */}
                      {input.length >= 2 && (
                        <div className="absolute inset-4 bg-white rounded-lg flex items-center justify-center">
                          <div className="w-40 h-40 bg-black rounded-lg p-4">
                            {/* QR code pattern */}
                            <div className="grid grid-cols-8 gap-1 h-full">
                              {Array.from({ length: 64 }, (_, i) => (
                                <div key={i} className={`${Math.random() > 0.5 ? 'bg-black' : 'bg-white'} aspect-square`}></div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Bottom controls */}
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black to-transparent">
                  <div className="text-center mb-6">
                    <div className="bg-white bg-opacity-20 rounded-full px-6 py-3 mx-auto w-fit mb-4">
                      <i className="fas fa-qrcode text-white text-2xl"></i>
                    </div>
                    <p className="text-white text-lg mb-2">Scan QR Code</p>
                    <p className="text-gray-300 text-sm">Place QR code inside the frame</p>
                  </div>
                  
                  {/* Manual merchant input */}
                  <div className="bg-white bg-opacity-10 rounded-xl p-4 mb-4">
                    <h3 className="text-white font-medium mb-2">Or enter merchant name:</h3>
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="Shop name, restaurant, etc."
                      className="w-full p-3 bg-white bg-opacity-20 text-white placeholder-gray-300 rounded-lg border border-white border-opacity-30 focus:border-green-400 focus:outline-none"
                      data-testid="input-merchant"
                    />
                  </div>
                  
                  {input.length >= 3 && (
                    <button
                      onClick={() => {
                        setScanningActive(true);
                        setUpiData(prev => ({ 
                          ...prev, 
                          merchantName: input, 
                          transactionId: `TXN${Date.now()}`,
                          upiId: `${input.toLowerCase()}@merchant` 
                        }));
                        setInput('');
                      }}
                      className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-semibold text-lg shadow-lg"
                      data-testid="button-scan-qr"
                    >
                      <i className="fas fa-qrcode mr-2"></i>
                      Scan QR Code
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex-1 bg-gradient-to-b from-green-50 to-white p-6">
                {/* Scan success */}
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <i className="fas fa-check text-white text-2xl"></i>
                  </div>
                  <h2 className="text-xl font-bold text-gray-800 mb-2">QR Code Detected!</h2>
                  <p className="text-gray-600">Pay to {upiData.merchantName}</p>
                </div>
                
                {/* Merchant details */}
                <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 mb-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center mr-4">
                      <i className="fas fa-store text-white text-lg"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 capitalize">{upiData.merchantName}</h3>
                      <p className="text-sm text-gray-500">{upiData.upiId}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-green-600 font-medium bg-green-100 px-2 py-1 rounded">
                        Verified
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Amount input */}
                <div className="text-center mb-8">
                  <div className="mb-4">
                    <span className="text-4xl font-light text-gray-400">₹</span>
                    <input
                      type="number"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="0"
                      className="text-4xl font-light text-gray-900 bg-transparent outline-none text-center w-48"
                      data-testid="input-amount"
                    />
                  </div>
                  <p className="text-gray-500">Enter amount to pay</p>
                </div>
                
                {/* Quick amount buttons */}
                <div className="grid grid-cols-3 gap-3 mb-8">
                  {['50', '100', '200'].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setInput(amount)}
                      className="bg-gray-100 hover:bg-gray-200 py-3 rounded-lg font-medium text-gray-700"
                      data-testid={`button-amount-${amount}`}
                    >
                      ₹{amount}
                    </button>
                  ))}
                </div>
                
                <button
                  onClick={handleValidation}
                  disabled={!input || parseFloat(input) < 1 || showSuccess}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-semibold text-lg 
                           disabled:bg-gray-300 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform transition-all
                           disabled:transform-none flex items-center justify-center"
                  data-testid="button-pay-merchant"
                >
                  <i className="fas fa-mobile-alt mr-2"></i>
                  Pay ₹{input || '0'}
                </button>
              </div>
            )}
          </div>
        );
        
      case 'upi-history':
        return (
          <div className="h-full flex flex-col bg-gray-50">
            {/* History header */}
            <div className="bg-gradient-to-r from-purple-600 to-purple-500 px-6 py-4 text-white">
              <div className="flex items-center mb-3">
                <button className="mr-4">
                  <i className="fas fa-arrow-left text-xl"></i>
                </button>
                <h1 className="text-xl font-semibold">Transaction History</h1>
                <div className="ml-auto">
                  <button className="p-2">
                    <i className="fas fa-filter text-lg"></i>
                  </button>
                </div>
              </div>
              
              {/* Search bar */}
              <div className="relative">
                <div className="bg-white bg-opacity-20 rounded-full px-4 py-2 flex items-center">
                  <i className="fas fa-search text-white opacity-70 mr-3"></i>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setInput(e.target.value);
                    }}
                    placeholder="Search transactions..."
                    className="flex-1 bg-transparent text-white placeholder-white placeholder-opacity-70 outline-none"
                    data-testid="input-search"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setInput('');
                      }}
                      className="text-white opacity-70 hover:opacity-100"
                    >
                      <i className="fas fa-times"></i>
                    </button>
                  )}
                </div>
              </div>
            </div>
            
            {/* Balance card */}
            <div className="p-6 pb-4">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-blue-100">Current Balance</span>
                  <i className="fas fa-eye-slash text-blue-200"></i>
                </div>
                <div className="text-3xl font-bold mb-1">₹ 12,547.85</div>
                <div className="text-blue-200 text-sm">SBI Bank ****1234</div>
              </div>
            </div>
            
            {/* Transaction list */}
            <div className="flex-1 px-6 pb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800">Recent Transactions</h2>
                <button
                  onClick={handleValidation}
                  className="text-purple-600 font-medium text-sm"
                  data-testid="button-search-filter"
                >
                  {searchQuery ? 'Apply Filter' : 'View All'}
                </button>
              </div>
              
              <div className="space-y-3">
                {[
                  { id: 'TXN001', type: 'sent', merchant: 'Coffee Shop', amount: 250, status: 'success', time: '2:30 PM', date: 'Today' },
                  { id: 'TXN002', type: 'received', merchant: 'John Doe', amount: 500, status: 'success', time: '1:15 PM', date: 'Today' },
                  { id: 'TXN003', type: 'sent', merchant: 'Grocery Store', amount: 1200, status: 'success', time: '11:30 AM', date: 'Today' },
                  { id: 'TXN004', type: 'sent', merchant: 'Uber Ride', amount: 180, status: 'pending', time: '9:45 PM', date: 'Yesterday' },
                  { id: 'TXN005', type: 'received', merchant: 'Salary Credit', amount: 45000, status: 'success', time: '8:00 AM', date: 'Yesterday' },
                  { id: 'TXN006', type: 'sent', merchant: 'Netflix', amount: 199, status: 'failed', time: '6:30 PM', date: '2 days ago' }
                ].filter(transaction => 
                  !searchQuery || 
                  transaction.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  transaction.id.toLowerCase().includes(searchQuery.toLowerCase())
                ).map((transaction, index) => (
                  <div key={index} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                    <div className="flex items-center">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                        transaction.type === 'sent' 
                          ? 'bg-red-100' 
                          : 'bg-green-100'
                      }`}>
                        <i className={`${
                          transaction.type === 'sent' 
                            ? 'fas fa-arrow-up text-red-600' 
                            : 'fas fa-arrow-down text-green-600'
                        } text-lg`}></i>
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold text-gray-800">{transaction.merchant}</h3>
                          <div className="text-right">
                            <div className={`text-lg font-semibold ${
                              transaction.type === 'sent' ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {transaction.type === 'sent' ? '-' : '+'}₹{transaction.amount}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-500">
                            {transaction.date} • {transaction.time}
                          </div>
                          <div className={`text-xs px-2 py-1 rounded-full font-medium ${
                            transaction.status === 'success' 
                              ? 'bg-green-100 text-green-800'
                              : transaction.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {transaction.status === 'success' ? '✓ Success' : 
                             transaction.status === 'pending' ? '⏳ Pending' : '✗ Failed'}
                          </div>
                        </div>
                        
                        <div className="text-xs text-gray-400 mt-1">
                          ID: {transaction.id}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {searchQuery && [
                  { id: 'TXN001', type: 'sent', merchant: 'Coffee Shop', amount: 250, status: 'success', time: '2:30 PM', date: 'Today' },
                  { id: 'TXN002', type: 'received', merchant: 'John Doe', amount: 500, status: 'success', time: '1:15 PM', date: 'Today' },
                  { id: 'TXN003', type: 'sent', merchant: 'Grocery Store', amount: 1200, status: 'success', time: '11:30 AM', date: 'Today' },
                  { id: 'TXN004', type: 'sent', merchant: 'Uber Ride', amount: 180, status: 'pending', time: '9:45 PM', date: 'Yesterday' },
                  { id: 'TXN005', type: 'received', merchant: 'Salary Credit', amount: 45000, status: 'success', time: '8:00 AM', date: 'Yesterday' },
                  { id: 'TXN006', type: 'sent', merchant: 'Netflix', amount: 199, status: 'failed', time: '6:30 PM', date: '2 days ago' }
                ].filter(transaction => 
                  transaction.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  transaction.id.toLowerCase().includes(searchQuery.toLowerCase())
                ).length === 0 && (
                  <div className="text-center py-8">
                    <i className="fas fa-search text-gray-400 text-3xl mb-3"></i>
                    <p className="text-gray-500">No transactions found for "{searchQuery}"</p>
                    <p className="text-sm text-gray-400 mt-1">Try searching with different keywords</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
        
      case 'facebook':
        return (
          <div className="h-full flex flex-col bg-gray-50">
            {/* Facebook Header */}
            <div className="bg-blue-600 px-4 py-3">
              <div className="flex items-center space-x-3 mb-3">
                <h1 className="text-white text-2xl font-bold">facebook</h1>
                <div className="flex-1">
                  <div className="relative">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="Search Facebook"
                      className="w-full bg-blue-500 bg-opacity-50 text-white placeholder-blue-200 px-4 py-2 rounded-full focus:bg-white focus:text-gray-900 focus:placeholder-gray-500 transition-colors outline-none"
                      data-testid="input-facebook-search"
                    />
                    <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-200"></i>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <button className="text-white">
                    <i className="fas fa-plus text-xl"></i>
                  </button>
                  <button className="text-white">
                    <i className="fab fa-facebook-messenger text-xl"></i>
                  </button>
                </div>
              </div>
            </div>

            {/* News Feed */}
            <div className="flex-1 overflow-y-auto">
              {/* Status Update Composer */}
              <div className="bg-white border-b border-gray-200 p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold">U</span>
                  </div>
                  <div className="flex-1 bg-gray-100 rounded-full px-4 py-2">
                    <span className="text-gray-500">What's on your mind?</span>
                  </div>
                </div>
                <div className="flex items-center justify-around mt-3 pt-3 border-t border-gray-100">
                  <div className="flex items-center text-gray-600">
                    <i className="fas fa-video text-red-500 mr-2"></i>
                    <span className="text-sm">Live</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <i className="fas fa-camera text-green-500 mr-2"></i>
                    <span className="text-sm">Photo</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <i className="fas fa-smile text-yellow-500 mr-2"></i>
                    <span className="text-sm">Feeling</span>
                  </div>
                </div>
              </div>

              {/* Posts Feed */}
              <div className="space-y-1">
                {!input ? (
                  // Default posts when no search
                  [
                    { name: "Sarah Johnson", avatar: "S", time: "2h", content: "Just had the most amazing coffee at this little café downtown! ☕️ Perfect way to start the weekend.", likes: 24, comments: 8, shares: 3, type: "text" },
                    { name: "Tech News Daily", avatar: "T", time: "4h", content: "Breaking: New smartphone features announced at today's conference. What do you think about the latest innovations?", likes: 156, comments: 42, shares: 28, type: "article", verified: true },
                    { name: "Mark Wilson", avatar: "M", time: "6h", content: "Family vacation memories! 🏖️ Thanks for an incredible week by the beach.", likes: 89, comments: 23, shares: 5, type: "photo" },
                    { name: "Food Network", avatar: "F", time: "8h", content: "Recipe of the day: Classic Italian Carbonara 🍝 Who's cooking this tonight?", likes: 324, comments: 76, shares: 89, type: "recipe", verified: true }
                  ].map((post, index) => (
                    <div key={index} className="bg-white p-4">
                      {/* Post Header */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-semibold">{post.avatar}</span>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center">
                              <h3 className="font-semibold text-gray-900">{post.name}</h3>
                              {post.verified && <i className="fas fa-check-circle text-blue-500 text-sm ml-1"></i>}
                            </div>
                            <p className="text-sm text-gray-500">{post.time} · <i className="fas fa-globe-americas text-xs"></i></p>
                          </div>
                        </div>
                        <button className="text-gray-500">
                          <i className="fas fa-ellipsis-h"></i>
                        </button>
                      </div>

                      {/* Post Content */}
                      <div className="mb-3">
                        <p className="text-gray-900">{post.content}</p>
                        {post.type === 'photo' && (
                          <div className="mt-3 bg-gray-200 rounded-lg h-64 flex items-center justify-center">
                            <i className="fas fa-image text-gray-400 text-4xl"></i>
                          </div>
                        )}
                        {post.type === 'article' && (
                          <div className="mt-3 border border-gray-200 rounded-lg overflow-hidden">
                            <div className="bg-gray-200 h-32 flex items-center justify-center">
                              <i className="fas fa-newspaper text-gray-400 text-3xl"></i>
                            </div>
                            <div className="p-3">
                              <h4 className="font-semibold text-sm">Tech Innovation Breakthrough</h4>
                              <p className="text-xs text-gray-500 mt-1">technews.com</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Post Stats */}
                      <div className="flex items-center justify-between py-2 border-b border-gray-100">
                        <div className="flex items-center text-sm text-gray-500">
                          <div className="flex items-center">
                            <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center mr-1">
                              <i className="fas fa-thumbs-up text-white text-xs"></i>
                            </div>
                            <span>{post.likes}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>{post.comments} comments</span>
                          <span>{post.shares} shares</span>
                        </div>
                      </div>

                      {/* Post Actions */}
                      <div className="flex items-center justify-around pt-2">
                        <button className="flex items-center space-x-2 py-2 px-4 hover:bg-gray-50 rounded">
                          <i className="far fa-thumbs-up text-gray-600"></i>
                          <span className="text-gray-600 text-sm font-medium">Like</span>
                        </button>
                        <button className="flex items-center space-x-2 py-2 px-4 hover:bg-gray-50 rounded">
                          <i className="far fa-comment text-gray-600"></i>
                          <span className="text-gray-600 text-sm font-medium">Comment</span>
                        </button>
                        <button className="flex items-center space-x-2 py-2 px-4 hover:bg-gray-50 rounded">
                          <i className="far fa-share text-gray-600"></i>
                          <span className="text-gray-600 text-sm font-medium">Share</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  // Search results
                  <div className="bg-white p-4">
                    {input.length >= 2 ? (
                      <div>
                        <div className="mb-4">
                          <h3 className="font-semibold text-gray-900 mb-3">Search Results for "{input}"</h3>
                          {/* People Results */}
                          <div className="space-y-3">
                            {['John Smith', 'Sarah Wilson', 'Mike Johnson'].filter(name => 
                              name.toLowerCase().includes(input.toLowerCase())
                            ).map((name, index) => (
                              <div key={index} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded">
                                <div className="flex items-center">
                                  <div className="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center mr-3">
                                    <span className="text-white font-semibold">{name.charAt(0)}</span>
                                  </div>
                                  <div>
                                    <h4 className="font-semibold text-gray-900">{name}</h4>
                                    <p className="text-sm text-gray-500">3 mutual friends</p>
                                  </div>
                                </div>
                                <button 
                                  onClick={handleValidation}
                                  className="bg-blue-600 text-white px-4 py-1 rounded text-sm font-medium hover:bg-blue-700"
                                  data-testid="button-add-friend"
                                >
                                  Add Friend
                                </button>
                              </div>
                            ))}
                          </div>

                          {/* Posts Results */}
                          <div className="mt-6">
                            <h4 className="font-semibold text-gray-700 mb-3">Related Posts</h4>
                            <div className="space-y-3">
                              <div className="p-3 border border-gray-200 rounded hover:bg-gray-50">
                                <div className="flex items-center mb-2">
                                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                                    <span className="text-white font-semibold text-sm">A</span>
                                  </div>
                                  <span className="font-semibold text-gray-900">Alex Brown</span>
                                </div>
                                <p className="text-gray-700 text-sm">Found this amazing place that matches "{input}"! Highly recommend checking it out.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <i className="fas fa-search text-gray-400 text-3xl mb-3"></i>
                        <p className="text-gray-500">Type at least 2 characters to search</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        );

      case 'instagram':
        return (
          <div className="h-full flex flex-col bg-white">
            {/* Instagram Header */}
            <div className="bg-white border-b border-gray-200 px-4 py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <button className="mr-4">
                    <i className="fas fa-camera text-2xl text-gray-900"></i>
                  </button>
                  <h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'serif' }}>Instagram</h1>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="Search"
                      className="bg-gray-100 px-3 py-1 rounded-full text-sm w-32 focus:outline-none focus:bg-white focus:ring-1 focus:ring-gray-300"
                      data-testid="input-instagram-search"
                    />
                    <i className="fas fa-search absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                  </div>
                  <button>
                    <i className="far fa-heart text-2xl text-gray-900"></i>
                  </button>
                  <button>
                    <i className="fab fa-facebook-messenger text-2xl text-gray-900"></i>
                  </button>
                </div>
              </div>
            </div>

            {/* Stories Bar */}
            <div className="bg-white border-b border-gray-100 px-4 py-3">
              <div className="flex items-center space-x-4 overflow-x-auto">
                {/* Your Story */}
                <div className="flex-shrink-0 text-center">
                  <div className="relative">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-gray-600 font-semibold">You</span>
                    </div>
                    <div className="absolute bottom-0 right-0 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                      <i className="fas fa-plus text-white text-xs"></i>
                    </div>
                  </div>
                  <span className="text-xs text-gray-900 mt-1 block">Your Story</span>
                </div>

                {/* Friends Stories */}
                {['Sarah', 'Mike', 'Anna', 'John', 'Lisa', 'Tom'].map((name, index) => (
                  <div key={index} className="flex-shrink-0 text-center">
                    <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500">
                      <div className="w-full h-full bg-gray-300 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">{name.charAt(0)}</span>
                      </div>
                    </div>
                    <span className="text-xs text-gray-900 mt-1 block">{name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Posts Feed */}
            <div className="flex-1 overflow-y-auto">
              {!input ? (
                // Default feed when no search
                [
                  { username: "sarah_travels", avatar: "S", location: "Bali, Indonesia", image: "travel", likes: 1240, caption: "Paradise found! 🌴 This view never gets old. #bali #travel #paradise", comments: 89, timeAgo: "2 hours ago" },
                  { username: "foodie_mike", avatar: "M", location: "New York, NY", image: "food", likes: 892, caption: "Homemade pasta night! Recipe in my stories 🍝 #cooking #pasta #homemade", comments: 34, timeAgo: "5 hours ago" },
                  { username: "fitness_anna", avatar: "A", location: "Gym", image: "fitness", likes: 567, caption: "Morning workout done! ✨ Remember, progress over perfection 💪 #fitness #motivation", comments: 28, timeAgo: "8 hours ago" }
                ].map((post, index) => (
                  <div key={index} className="border-b border-gray-100">
                    {/* Post Header */}
                    <div className="flex items-center justify-between p-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-0.5 mr-3">
                          <div className="w-full h-full bg-gray-400 rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold text-sm">{post.avatar}</span>
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h3 className="font-semibold text-gray-900 text-sm">{post.username}</h3>
                            <i className="fas fa-check-circle text-blue-500 text-xs ml-1"></i>
                          </div>
                          <p className="text-xs text-gray-500">{post.location}</p>
                        </div>
                      </div>
                      <button>
                        <i className="fas fa-ellipsis-h text-gray-600"></i>
                      </button>
                    </div>

                    {/* Post Image */}
                    <div className="bg-gray-200 aspect-square flex items-center justify-center">
                      <i className={`fas ${post.image === 'travel' ? 'fa-mountain' : post.image === 'food' ? 'fa-utensils' : 'fa-dumbbell'} text-gray-400 text-4xl`}></i>
                    </div>

                    {/* Post Actions */}
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-4">
                          <button>
                            <i className="far fa-heart text-2xl text-gray-900"></i>
                          </button>
                          <button>
                            <i className="far fa-comment text-2xl text-gray-900"></i>
                          </button>
                          <button>
                            <i className="far fa-paper-plane text-2xl text-gray-900"></i>
                          </button>
                        </div>
                        <button>
                          <i className="far fa-bookmark text-2xl text-gray-900"></i>
                        </button>
                      </div>

                      {/* Likes */}
                      <div className="mb-2">
                        <p className="font-semibold text-sm text-gray-900">{post.likes.toLocaleString()} likes</p>
                      </div>

                      {/* Caption */}
                      <div className="mb-2">
                        <span className="font-semibold text-sm text-gray-900">{post.username}</span>
                        <span className="text-sm text-gray-900 ml-2">{post.caption}</span>
                      </div>

                      {/* Comments */}
                      {post.comments > 0 && (
                        <button className="text-sm text-gray-500 mb-2">
                          View all {post.comments} comments
                        </button>
                      )}

                      {/* Time */}
                      <p className="text-xs text-gray-500 uppercase">{post.timeAgo}</p>
                    </div>
                  </div>
                ))
              ) : (
                // Search results
                <div className="p-4">
                  {input.length >= 2 ? (
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-4">Search Results</h3>
                      
                      {/* Accounts */}
                      <div className="mb-6">
                        <h4 className="text-gray-600 font-medium mb-3">Accounts</h4>
                        <div className="space-y-3">
                          {['travel_blogger', 'food_lover', 'fitness_guru'].filter(name => 
                            name.includes(input.toLowerCase()) || input.toLowerCase().includes(name.split('_')[0])
                          ).map((username, index) => (
                            <div key={index} className="flex items-center justify-between">
                              <div className="flex items-center">
                                <div className="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center mr-3">
                                  <span className="text-white font-semibold">{username.charAt(0).toUpperCase()}</span>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-gray-900 text-sm">{username}</h4>
                                  <p className="text-gray-500 text-xs">2.4M followers</p>
                                </div>
                              </div>
                              <button 
                                onClick={handleValidation}
                                className="bg-blue-500 text-white px-6 py-1 rounded text-sm font-medium hover:bg-blue-600"
                                data-testid="button-follow"
                              >
                                Follow
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Hashtags */}
                      <div className="mb-6">
                        <h4 className="text-gray-600 font-medium mb-3">Tags</h4>
                        <div className="space-y-3">
                          {[`#${input}`, `#${input}love`, `#${input}life`].map((hashtag, index) => (
                            <div key={index} className="flex items-center">
                              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center mr-3">
                                <i className="fas fa-hashtag text-gray-600"></i>
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900 text-sm">{hashtag}</h4>
                                <p className="text-gray-500 text-xs">{Math.floor(Math.random() * 1000000).toLocaleString()} posts</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <i className="fas fa-search text-gray-400 text-3xl mb-3"></i>
                      <p className="text-gray-500">Search for people and hashtags</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Navigation */}
            <div className="bg-white border-t border-gray-200 px-4 py-2">
              <div className="flex items-center justify-around">
                <button className="p-2">
                  <i className="fas fa-home text-2xl text-gray-900"></i>
                </button>
                <button className="p-2">
                  <i className="fas fa-search text-2xl text-gray-400"></i>
                </button>
                <button className="p-2">
                  <i className="fas fa-plus-square text-2xl text-gray-400"></i>
                </button>
                <button className="p-2">
                  <i className="fas fa-heart text-2xl text-gray-400"></i>
                </button>
                <button className="p-2">
                  <div className="w-6 h-6 bg-gray-400 rounded-full"></div>
                </button>
              </div>
            </div>
          </div>
        );

      case 'ott':
        return (
          <div className="h-full flex flex-col bg-black text-white">
            {/* OTT Header */}
            <div className="bg-black bg-opacity-90 backdrop-blur-sm px-4 py-3 sticky top-0 z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <h1 className="text-red-600 text-2xl font-bold">StreamFlix</h1>
                  <nav className="hidden md:flex items-center space-x-6">
                    <button className="text-white hover:text-gray-300">Home</button>
                    <button className="text-gray-400 hover:text-white">TV Shows</button>
                    <button className="text-gray-400 hover:text-white">Movies</button>
                    <button className="text-gray-400 hover:text-white">My List</button>
                  </nav>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      placeholder="Search movies, shows..."
                      className="bg-gray-800 bg-opacity-80 text-white placeholder-gray-400 px-4 py-2 rounded focus:outline-none focus:bg-gray-700 w-64"
                      data-testid="input-ott-search"
                    />
                    <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  </div>
                  <button>
                    <i className="fas fa-bell text-xl text-white"></i>
                  </button>
                  <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center">
                    <span className="text-white font-semibold text-sm">U</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
              {!input ? (
                <div>
                  {/* Featured Content */}
                  <div className="relative h-96 bg-gradient-to-r from-purple-900 via-blue-900 to-teal-900 flex items-center">
                    <div className="absolute inset-0 bg-black bg-opacity-40"></div>
                    <div className="relative z-10 px-8 max-w-2xl">
                      <h2 className="text-4xl font-bold mb-4">Stranger Things</h2>
                      <p className="text-lg mb-6 text-gray-200">When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.</p>
                      <div className="flex items-center space-x-4">
                        <button className="bg-white text-black px-8 py-3 rounded flex items-center space-x-2 font-semibold hover:bg-gray-200">
                          <i className="fas fa-play"></i>
                          <span>Play</span>
                        </button>
                        <button className="bg-gray-600 bg-opacity-70 text-white px-6 py-3 rounded flex items-center space-x-2 hover:bg-gray-500">
                          <i className="fas fa-info-circle"></i>
                          <span>More Info</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Continue Watching */}
                  <div className="px-8 py-6">
                    <h3 className="text-xl font-semibold mb-4">Continue Watching</h3>
                    <div className="flex space-x-4 overflow-x-auto">
                      {[
                        { title: "The Crown", progress: 65, episode: "S4 E3" },
                        { title: "Ozark", progress: 23, episode: "S3 E8" },
                        { title: "Breaking Bad", progress: 89, episode: "S2 E7" }
                      ].map((show, index) => (
                        <div key={index} className="flex-shrink-0 w-64">
                          <div className="relative">
                            <div className="bg-gray-800 h-36 rounded flex items-center justify-center">
                              <i className="fas fa-play-circle text-4xl text-white opacity-80"></i>
                            </div>
                            <div className="absolute bottom-1 left-1 right-1 bg-gray-600 h-1 rounded">
                              <div className="bg-red-600 h-full rounded" style={{ width: `${show.progress}%` }}></div>
                            </div>
                          </div>
                          <div className="mt-2">
                            <h4 className="font-medium">{show.title}</h4>
                            <p className="text-sm text-gray-400">{show.episode}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Trending Now */}
                  <div className="px-8 py-6">
                    <h3 className="text-xl font-semibold mb-4">Trending Now</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {[
                        "The Witcher", "Money Heist", "Dark", "Squid Game", "Bridgerton", "Lupin",
                        "The Queen's Gambit", "Narcos", "Peaky Blinders", "Black Mirror", "Mindhunter", "Ozark"
                      ].map((title, index) => (
                        <div key={index} className="group cursor-pointer">
                          <div className="bg-gray-800 aspect-video rounded flex items-center justify-center group-hover:scale-105 transition-transform">
                            <i className="fas fa-play text-2xl text-white opacity-60"></i>
                          </div>
                          <h4 className="mt-2 text-sm font-medium group-hover:text-gray-300">{title}</h4>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Movies */}
                  <div className="px-8 py-6">
                    <h3 className="text-xl font-semibold mb-4">Action Movies</h3>
                    <div className="flex space-x-4 overflow-x-auto">
                      {[
                        { title: "John Wick", rating: "8.2", year: "2014" },
                        { title: "Mad Max", rating: "8.1", year: "2015" },
                        { title: "Extraction", rating: "6.7", year: "2020" },
                        { title: "6 Underground", rating: "6.1", year: "2019" },
                        { title: "The Gray Man", rating: "6.5", year: "2022" }
                      ].map((movie, index) => (
                        <div key={index} className="flex-shrink-0 w-48 group cursor-pointer">
                          <div className="bg-gray-800 h-72 rounded flex flex-col items-center justify-center group-hover:scale-105 transition-transform">
                            <i className="fas fa-film text-3xl text-white opacity-60 mb-2"></i>
                            <div className="text-center px-4">
                              <h4 className="font-medium mb-1">{movie.title}</h4>
                              <div className="flex items-center justify-center space-x-2 text-sm text-gray-400">
                                <span>{movie.year}</span>
                                <span>•</span>
                                <div className="flex items-center">
                                  <i className="fas fa-star text-yellow-500 text-xs mr-1"></i>
                                  <span>{movie.rating}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                // Search results
                <div className="px-8 py-6">
                  {input.length >= 2 ? (
                    <div>
                      <h3 className="text-2xl font-semibold mb-6">Search Results for "{input}"</h3>
                      
                      {/* Movies Results */}
                      <div className="mb-8">
                        <h4 className="text-lg font-medium mb-4 text-gray-300">Movies</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                          {[
                            { title: "Action Hero", type: "Movie", year: "2022", rating: "7.2" },
                            { title: "Adventure Quest", type: "Movie", year: "2023", rating: "8.1" },
                            { title: "Thriller Night", type: "Movie", year: "2021", rating: "6.8" }
                          ].filter(item => 
                            item.title.toLowerCase().includes(input.toLowerCase()) ||
                            input.toLowerCase().includes(item.title.toLowerCase().split(' ')[0])
                          ).map((movie, index) => (
                            <div key={index} className="group cursor-pointer">
                              <div 
                                className="bg-gray-800 aspect-video rounded flex flex-col items-center justify-center group-hover:scale-105 transition-transform p-4"
                                onClick={handleValidation}
                              >
                                <i className="fas fa-film text-3xl text-white opacity-60 mb-2"></i>
                                <h4 className="font-medium text-center text-sm">{movie.title}</h4>
                                <div className="flex items-center space-x-2 text-xs text-gray-400 mt-1">
                                  <span>{movie.year}</span>
                                  <span>•</span>
                                  <div className="flex items-center">
                                    <i className="fas fa-star text-yellow-500 text-xs mr-1"></i>
                                    <span>{movie.rating}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* TV Shows Results */}
                      <div className="mb-8">
                        <h4 className="text-lg font-medium mb-4 text-gray-300">TV Shows</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                          {[
                            { title: "Action Series", type: "Series", seasons: "3 Seasons", rating: "8.4" },
                            { title: "Adventure Chronicles", type: "Series", seasons: "2 Seasons", rating: "7.9" }
                          ].filter(item => 
                            item.title.toLowerCase().includes(input.toLowerCase()) ||
                            input.toLowerCase().includes(item.title.toLowerCase().split(' ')[0])
                          ).map((show, index) => (
                            <div key={index} className="group cursor-pointer">
                              <div 
                                className="bg-gray-800 aspect-video rounded flex flex-col items-center justify-center group-hover:scale-105 transition-transform p-4"
                                onClick={handleValidation}
                              >
                                <i className="fas fa-tv text-3xl text-white opacity-60 mb-2"></i>
                                <h4 className="font-medium text-center text-sm">{show.title}</h4>
                                <div className="flex items-center space-x-2 text-xs text-gray-400 mt-1">
                                  <span>{show.seasons}</span>
                                  <span>•</span>
                                  <div className="flex items-center">
                                    <i className="fas fa-star text-yellow-500 text-xs mr-1"></i>
                                    <span>{show.rating}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={handleValidation}
                        className="bg-red-600 text-white px-8 py-3 rounded font-semibold hover:bg-red-700 flex items-center space-x-2"
                        data-testid="button-play-content"
                      >
                        <i className="fas fa-play"></i>
                        <span>Watch Now</span>
                      </button>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <i className="fas fa-search text-gray-600 text-4xl mb-4"></i>
                      <h3 className="text-xl font-medium text-gray-300 mb-2">Search for movies and TV shows</h3>
                      <p className="text-gray-500">Type at least 2 characters to search our catalog</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );

      default:
        // Generic interface for other scenarios
        return (
          <div className="h-full flex flex-col bg-white p-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className={`${scenario.icon} text-gray-600 text-xl`}></i>
              </div>
              <h2 className="text-xl font-bold mb-2" data-testid="text-practice-title">
                {scenario.title} Practice
              </h2>
              <p className="text-gray-600 mb-2" data-testid="text-practice-prompt">
                {scenario.prompt}
              </p>
            </div>

            <div className="space-y-6 flex-1">
              <InputField
                label={scenario.label}
                placeholder={scenario.placeholder}
                value={input}
                onChange={handleInputChange}
                hint={scenario.hint}
                testId="input-practice"
              />

              <ActionButton
                variant="primary"
                fullWidth
                onClick={handleValidation}
                testId="button-check-answer"
              >
                Check Answer
              </ActionButton>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="h-full relative">
      {renderScenarioInterface()}
      
      {/* Success overlay */}
      {showSuccess && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-10">
          <div className="bg-white rounded-lg p-6 m-6 text-center max-w-sm">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-check text-white text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold mb-2" data-testid="text-success-title">
              Well Done!
            </h3>
            <p className="text-gray-600 mb-6" data-testid="text-success-message">
              You completed the practice successfully.
            </p>
            <ActionButton
              variant="success"
              fullWidth
              onClick={handleContinue}
              testId="button-continue-learning"
            >
              Continue Learning
            </ActionButton>
          </div>
        </div>
      )}
      
      {/* Error feedback */}
      {feedback.type === 'error' && (
        <div className="absolute bottom-4 left-4 right-4 bg-red-500 text-white p-4 rounded-lg z-10">
          <div className="flex items-center">
            <i className="fas fa-exclamation-triangle mr-3"></i>
            <span data-testid="text-error-feedback">{feedback.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}