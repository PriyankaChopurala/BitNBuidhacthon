import { useEffect, useState } from 'react';

export function StatusBar() {
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: false
      });
      setCurrentTime(timeString);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white h-11 px-4 flex items-center justify-between text-sm font-semibold text-black">
      {/* Left side - Time */}
      <div className="flex items-center">
        <span data-testid="text-current-time">{currentTime}</span>
      </div>
      
      {/* Right side - Status Icons */}
      <div className="flex items-center space-x-1">
        {/* Signal Bars */}
        <div className="flex items-end space-x-0.5" data-testid="icon-signal-bars">
          <div className="w-1 h-1 bg-black rounded-full"></div>
          <div className="w-1 h-1.5 bg-black rounded-full"></div>
          <div className="w-1 h-2 bg-black rounded-full"></div>
          <div className="w-1 h-2.5 bg-black rounded-full"></div>
        </div>
        
        {/* WiFi Icon */}
        <div className="ml-1" data-testid="icon-wifi">
          <svg width="15" height="11" viewBox="0 0 15 11" fill="none">
            <path d="M7.5 3C9.36 3 11.16 3.69 12.55 4.93L13.5 3.93C11.84 2.41 9.74 1.5 7.5 1.5C5.26 1.5 3.16 2.41 1.5 3.93L2.45 4.93C3.84 3.69 5.64 3 7.5 3Z" fill="black"/>
            <path d="M7.5 6C8.61 6 9.68 6.41 10.5 7.14L11.5 6.07C10.43 5.16 9.01 4.5 7.5 4.5C5.99 4.5 4.57 5.16 3.5 6.07L4.5 7.14C5.32 6.41 6.39 6 7.5 6Z" fill="black"/>
            <path d="M8.5 9C8.5 9.55 8.05 10 7.5 10C6.95 10 6.5 9.55 6.5 9C6.5 8.45 6.95 8 7.5 8C8.05 8 8.5 8.45 8.5 9Z" fill="black"/>
          </svg>
        </div>
        
        {/* Battery Icon */}
        <div className="ml-1 flex items-center" data-testid="icon-battery">
          <div className="relative">
            <svg width="24" height="12" viewBox="0 0 24 12" fill="none">
              <rect x="1" y="2" width="20" height="8" rx="2" stroke="black" strokeWidth="1" fill="none"/>
              <rect x="2.5" y="3.5" width="15" height="5" rx="1" fill="black"/>
              <rect x="21.5" y="4.5" width="1.5" height="3" rx="0.75" fill="black"/>
            </svg>
          </div>
          <span className="ml-1 text-xs">85%</span>
        </div>
      </div>
    </div>
  );
}