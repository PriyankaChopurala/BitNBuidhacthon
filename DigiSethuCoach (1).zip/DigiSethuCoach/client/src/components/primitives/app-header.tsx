import { Button } from '@/components/ui/button';

export interface AppHeaderProps {
  appName: string;
  appIcon: string;
  onBackClick: () => void;
  rightActions?: React.ReactNode;
  title?: string;
}

export function AppHeader({ appName, appIcon, onBackClick, rightActions, title }: AppHeaderProps) {
  return (
    <div className="bg-white h-14 px-4 flex items-center justify-between border-b border-gray-200">
      {/* Left side - Back button and app info */}
      <div className="flex items-center space-x-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBackClick}
          className="p-2 hover:bg-gray-100 rounded-full"
          data-testid="button-back"
        >
          <i className="fas fa-arrow-left text-gray-700 text-lg"></i>
        </Button>
        
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
            <i className={`${appIcon} text-white text-sm`} data-testid="icon-app"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gray-900" data-testid="text-app-name">
              {title || appName}
            </h1>
          </div>
        </div>
      </div>
      
      {/* Right side - Actions */}
      {rightActions && (
        <div className="flex items-center space-x-2" data-testid="container-header-actions">
          {rightActions}
        </div>
      )}
    </div>
  );
}