import { Input } from '@/components/ui/input';
import { useSimulatorInput } from '../simulator-context';
import { useState } from 'react';

export interface InputFieldProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'tel' | 'email' | 'password' | 'search';
  disabled?: boolean;
  error?: string;
  hint?: string;
  leftIcon?: string;
  rightIcon?: string;
  onRightIconClick?: () => void;
  maxLength?: number;
  testId?: string;
}

export function InputField({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  disabled = false,
  error,
  hint,
  leftIcon,
  rightIcon,
  onRightIconClick,
  maxLength,
  testId
}: InputFieldProps) {
  const { handleInputChange } = useSimulatorInput();
  const [previousValue, setPreviousValue] = useState(value);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    
    // Handle character-by-character TTS
    handleInputChange(newValue, previousValue);
    setPreviousValue(newValue);
    
    onChange(newValue);
  };

  return (
    <div className="mb-4">
      {/* Label */}
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-2" data-testid="label-input">
          {label}
        </label>
      )}
      
      {/* Input Container */}
      <div className="relative">
        {/* Left Icon */}
        {leftIcon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
            <i className={`${leftIcon} text-gray-400`} data-testid="icon-input-left"></i>
          </div>
        )}
        
        {/* Input Field */}
        <Input
          type={type}
          value={value}
          onChange={handleChange}
          placeholder={placeholder}
          disabled={disabled}
          maxLength={maxLength}
          className={`
            h-12 text-base
            ${leftIcon ? 'pl-10' : ''}
            ${rightIcon ? 'pr-10' : ''}
            ${error ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'}
          `}
          data-testid={testId || 'input-field'}
        />
        
        {/* Right Icon */}
        {rightIcon && (
          <button
            type="button"
            onClick={onRightIconClick}
            disabled={disabled}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
            data-testid="button-input-right"
          >
            <i className={`${rightIcon} text-gray-400 hover:text-gray-600`}></i>
          </button>
        )}
      </div>
      
      {/* Error Message */}
      {error && (
        <p className="mt-1 text-sm text-red-600" data-testid="text-input-error">
          {error}
        </p>
      )}
      
      {/* Hint Text */}
      {hint && !error && (
        <p className="mt-1 text-sm text-gray-500" data-testid="text-input-hint">
          {hint}
        </p>
      )}
    </div>
  );
}