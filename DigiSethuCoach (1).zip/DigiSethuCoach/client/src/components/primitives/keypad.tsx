import { Button } from '@/components/ui/button';
import { useSimulator } from '../simulator-context';

export interface KeypadProps {
  onKeyPress: (key: string) => void;
  onCallPress?: () => void;
  showCallButton?: boolean;
  disabled?: boolean;
}

const KEYPAD_NUMBERS = [
  ['1', '2', '3'],
  ['4', '5', '6'],
  ['7', '8', '9'],
  ['*', '0', '#']
];

export function Keypad({ onKeyPress, onCallPress, showCallButton = false, disabled = false }: KeypadProps) {
  const { speak } = useSimulator();

  const handleKeyPress = (key: string) => {
    if (disabled) return;
    speak(key);
    onKeyPress(key);
  };

  return (
    <div className="p-6 bg-white">
      {/* Number Grid */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {KEYPAD_NUMBERS.map((row, rowIndex) =>
          row.map((key) => (
            <Button
              key={key}
              onClick={() => handleKeyPress(key)}
              disabled={disabled}
              className="h-16 text-2xl font-normal bg-gray-100 hover:bg-gray-200 text-gray-900 border-0 rounded-full shadow-none"
              data-testid={`button-keypad-${key}`}
            >
              {key}
            </Button>
          ))
        )}
      </div>

      {/* Call Button */}
      {showCallButton && onCallPress && (
        <div className="flex justify-center">
          <Button
            onClick={onCallPress}
            disabled={disabled}
            className="h-16 w-16 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center"
            data-testid="button-call"
          >
            <i className="fas fa-phone text-xl"></i>
          </Button>
        </div>
      )}
    </div>
  );
}