export interface ContactCardProps {
  name: string;
  phoneNumber?: string;
  avatar?: string;
  status?: string;
  lastSeen?: string;
  onClick?: () => void;
  showPhone?: boolean;
}

export function ContactCard({ 
  name, 
  phoneNumber, 
  avatar, 
  status, 
  lastSeen, 
  onClick,
  showPhone = true 
}: ContactCardProps) {
  return (
    <div
      className={`flex items-center p-4 border-b border-gray-200 ${onClick ? 'cursor-pointer hover:bg-gray-50' : ''}`}
      onClick={onClick}
      data-testid={`card-contact-${name.toLowerCase().replace(/\s+/g, '-')}`}
    >
      {/* Avatar */}
      <div className="w-12 h-12 rounded-full bg-gray-300 mr-3 flex items-center justify-center flex-shrink-0">
        {avatar ? (
          <img src={avatar} alt={name} className="w-full h-full rounded-full object-cover" />
        ) : (
          <i className="fas fa-user text-gray-600 text-lg"></i>
        )}
      </div>
      
      {/* Contact Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900 truncate" data-testid="text-contact-name">
            {name}
          </h3>
          {lastSeen && (
            <span className="text-xs text-gray-500" data-testid="text-last-seen">
              {lastSeen}
            </span>
          )}
        </div>
        
        {showPhone && phoneNumber && (
          <p className="text-sm text-gray-600 truncate" data-testid="text-phone-number">
            {phoneNumber}
          </p>
        )}
        
        {status && (
          <p className="text-sm text-gray-500 truncate" data-testid="text-contact-status">
            {status}
          </p>
        )}
      </div>
      
      {/* Action indicator */}
      {onClick && (
        <div className="ml-2">
          <i className="fas fa-chevron-right text-gray-400 text-sm"></i>
        </div>
      )}
    </div>
  );
}