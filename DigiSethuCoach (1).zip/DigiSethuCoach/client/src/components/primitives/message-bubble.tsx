export interface MessageBubbleProps {
  message: string;
  sent?: boolean;
  timestamp?: string;
  avatar?: string;
  senderName?: string;
}

export function MessageBubble({ message, sent = false, timestamp, avatar, senderName }: MessageBubbleProps) {
  return (
    <div className={`flex mb-4 ${sent ? 'justify-end' : 'justify-start'}`}>
      {/* Avatar for received messages */}
      {!sent && avatar && (
        <div className="w-8 h-8 rounded-full bg-gray-300 mr-2 flex items-center justify-center flex-shrink-0">
          {avatar ? (
            <img src={avatar} alt={senderName} className="w-full h-full rounded-full object-cover" />
          ) : (
            <i className="fas fa-user text-gray-600 text-sm"></i>
          )}
        </div>
      )}
      
      <div className={`max-w-xs ${sent ? 'ml-12' : 'mr-12'}`}>
        {/* Sender name for received messages */}
        {!sent && senderName && (
          <div className="text-xs text-gray-500 mb-1 ml-3" data-testid="text-sender-name">
            {senderName}
          </div>
        )}
        
        {/* Message bubble */}
        <div
          className={`px-4 py-2 rounded-2xl ${
            sent
              ? 'bg-blue-500 text-white rounded-br-md'
              : 'bg-gray-200 text-gray-900 rounded-bl-md'
          }`}
          data-testid={`message-${sent ? 'sent' : 'received'}`}
        >
          <p className="text-sm">{message}</p>
        </div>
        
        {/* Timestamp */}
        {timestamp && (
          <div
            className={`text-xs text-gray-500 mt-1 ${sent ? 'text-right mr-3' : 'text-left ml-3'}`}
            data-testid="text-message-timestamp"
          >
            {timestamp}
          </div>
        )}
      </div>
    </div>
  );
}