import { Button } from '@/components/ui/button';

export interface ActionButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'warning';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
  fullWidth?: boolean;
  testId?: string;
}

export function ActionButton({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  icon,
  fullWidth = false,
  testId
}: ActionButtonProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return 'bg-blue-500 hover:bg-blue-600 text-white';
      case 'secondary':
        return 'bg-gray-200 hover:bg-gray-300 text-gray-900';
      case 'success':
        return 'bg-green-500 hover:bg-green-600 text-white';
      case 'danger':
        return 'bg-red-500 hover:bg-red-600 text-white';
      case 'warning':
        return 'bg-yellow-500 hover:bg-yellow-600 text-white';
      default:
        return 'bg-blue-500 hover:bg-blue-600 text-white';
    }
  };

  const getSizeStyles = () => {
    switch (size) {
      case 'sm':
        return 'h-10 px-4 text-sm';
      case 'md':
        return 'h-12 px-6 text-base';
      case 'lg':
        return 'h-14 px-8 text-lg';
      default:
        return 'h-12 px-6 text-base';
    }
  };

  return (
    <Button
      onClick={onClick}
      disabled={disabled || loading}
      className={`
        ${getVariantStyles()}
        ${getSizeStyles()}
        ${fullWidth ? 'w-full' : ''}
        font-semibold rounded-lg border-0 shadow-none
        min-h-[44px] flex items-center justify-center
        ${loading ? 'opacity-70' : ''}
      `}
      data-testid={testId}
    >
      {loading && (
        <i className="fas fa-spinner fa-spin mr-2" data-testid="icon-loading"></i>
      )}
      
      {!loading && icon && (
        <i className={`${icon} mr-2`} data-testid="icon-action"></i>
      )}
      
      {children}
    </Button>
  );
}