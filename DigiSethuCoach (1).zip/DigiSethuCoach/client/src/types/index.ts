// Import types from shared schema for consistency
export type { 
  ScenarioId, 
  CategoryId, 
  UserProgress, 
  AppSettings, 
  PracticeInput,
  CategoryData,
  ScenarioData
} from '@shared/schema';

// Legacy types for backward compatibility - import CategoryId first
import type { CategoryId } from '@shared/schema';

export interface Category {
  id: CategoryId;
  title: string;
  description: string;
  icon: string;
  color: string;
  practices: string[];
}

export interface PracticeData {
  prompt: string;
  label: string;
  hint: string;
  placeholder: string;
  instructions: string;
}
