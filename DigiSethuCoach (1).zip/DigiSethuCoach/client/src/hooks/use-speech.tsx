import { useCallback, useEffect, useState } from 'react';
import { speechService } from '@/lib/speech';

export function useSpeech() {
  const [isSupported, setIsSupported] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    setIsSupported(speechService.getSupported());
    
    // Check if speech is playing periodically
    const interval = setInterval(() => {
      setIsPlaying(speechService.isPlaying());
    }, 100);

    return () => clearInterval(interval);
  }, []);

  const speak = useCallback((text: string, options?: { rate?: number; pitch?: number; volume?: number }) => {
    speechService.speak(text, options);
  }, []);

  const stop = useCallback(() => {
    speechService.stop();
  }, []);

  return {
    speak,
    stop,
    isSupported,
    isPlaying
  };
}
