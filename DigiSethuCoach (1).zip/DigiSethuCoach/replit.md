# Overview

Digi Sethu is a progressive web application designed for digital literacy training. The app provides interactive practice modules covering phone usage, UPI/financial transactions, and social media applications. Built as a single-page React application with Express.js backend, it features speech synthesis capabilities, local data persistence, and a mobile-first responsive design optimized for accessibility.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **Routing**: Wouter for client-side navigation with file-based routing approach
- **UI Components**: Radix UI primitives with shadcn/ui component library using Tailwind CSS for styling
- **State Management**: React hooks with custom localStorage persistence layer for app settings and user progress
- **Data Fetching**: TanStack Query for server state management (though minimal server interaction currently)

## Backend Architecture
- **Server**: Express.js with TypeScript running in ESM mode
- **Development**: Hot reload with Vite middleware in development, static file serving in production
- **API Structure**: RESTful endpoints prefixed with `/api` (currently minimal backend functionality)
- **Storage Interface**: Abstract storage layer prepared for future database integration

## Data Storage Solutions
- **Primary Storage**: Browser localStorage for user progress, settings, and phone number persistence
- **Future Database**: Drizzle ORM configured for PostgreSQL with Neon Database serverless driver
- **Schema Management**: Centralized Zod schemas in shared directory for validation across frontend/backend

## Authentication and Authorization
- **Current**: Phone number-based user identification stored locally
- **Session Management**: Prepared infrastructure using connect-pg-simple for future PostgreSQL session storage
- **Security**: Input validation using Zod schemas with type-safe validation patterns

## Progressive Web App Features
- **Service Worker**: Custom caching strategy for offline functionality
- **Manifest**: Full PWA manifest with app icons, splash screens, and standalone display mode
- **Accessibility**: Speech synthesis integration with configurable reading features
- **Mobile Optimization**: Touch-friendly interface with responsive breakpoints

## Development Tools
- **Type Safety**: Full TypeScript coverage with strict configuration
- **Code Quality**: ESLint and Prettier configurations for consistent code style
- **Build Process**: Dual build system - Vite for frontend, esbuild for backend bundling
- **Path Mapping**: Alias resolution for clean imports (@/, @shared/, @assets/)

# External Dependencies

## UI and Styling
- **Radix UI**: Complete set of accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework with custom design system variables
- **Font Awesome**: Icon library for consistent iconography across the application
- **Google Fonts**: Inter font family for modern typography

## Database and Persistence
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe SQL toolkit with automatic migration generation
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## Development and Build
- **Vite**: Fast build tool with HMR and plugin ecosystem
- **esbuild**: Fast JavaScript bundler for production server builds
- **Replit Plugins**: Development banner, error overlay, and cartographer for Replit environment

## Speech and Accessibility
- **Web Speech API**: Browser-native speech synthesis for text-to-speech functionality
- **Screen Reader Support**: Semantic HTML and ARIA attributes for accessibility compliance

## Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation with TypeScript integration
- **Date-fns**: Date manipulation utilities for consistent date handling