// Simple storage interface for future extension
// Currently all data is stored in localStorage on the frontend

export interface IStorage {
  // Future API endpoints can be added here if needed
}

export class MemStorage implements IStorage {
  constructor() {
    // Currently all data persistence is handled by localStorage on frontend
  }
}

export const storage = new MemStorage();
