import { z } from "zod";

// Scenario ID enums for different app interfaces
export const scenarioIdSchema = z.enum([
  "dialer", "sms", "whatsapp", // General scenarios
  "upi-send", "upi-scanner", "upi-history", // Finance scenarios  
  "facebook", "instagram", "ott" // Entertainment scenarios
]);

export const categoryIdSchema = z.enum(["general", "finance", "entertainment"]);

export const phoneNumberSchema = z.object({
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits").regex(/^\d+$/, "Phone number must contain only digits"),
});

// Updated user progress to track scenario completion
export const userProgressSchema = z.object({
  // General scenarios
  dialer: z.boolean().default(false),
  sms: z.boolean().default(false),
  whatsapp: z.boolean().default(false),
  // Finance scenarios
  "upi-send": z.boolean().default(false),
  "upi-scanner": z.boolean().default(false),
  "upi-history": z.boolean().default(false),
  // Entertainment scenarios
  facebook: z.boolean().default(false),
  instagram: z.boolean().default(false),
  ott: z.boolean().default(false),
});

export const appSettingsSchema = z.object({
  readWhileTyping: z.boolean().default(false),
  isFirstLaunch: z.boolean().default(true),
  phoneNumber: z.string().optional(),
});

export const practiceInputSchema = z.object({
  category: categoryIdSchema,
  scenarioId: scenarioIdSchema,
  input: z.string().min(1, "Input is required"),
});

export type ScenarioId = z.infer<typeof scenarioIdSchema>;
export type CategoryId = z.infer<typeof categoryIdSchema>;
export type PhoneNumber = z.infer<typeof phoneNumberSchema>;
export type UserProgress = z.infer<typeof userProgressSchema>;
export type AppSettings = z.infer<typeof appSettingsSchema>;
export type PracticeInput = z.infer<typeof practiceInputSchema>;

export interface ScenarioData {
  id: ScenarioId;
  title: string;
  description: string;
  icon: string;
  appName: string;
  instructions: string;
  prompt: string;
  label: string;
  hint: string;
  placeholder: string;
  validationRule: 'phone' | 'upi' | 'message' | 'search';
}

export interface CategoryData {
  id: CategoryId;
  title: string;
  description: string;
  icon: string;
  color: string;
  scenarios: ScenarioData[];
}

export const categories: CategoryData[] = [
  {
    id: "general",
    title: "General",
    description: "Phone, WhatsApp, SMS",
    icon: "fas fa-phone",
    color: "blue",
    scenarios: [
      {
        id: "dialer",
        title: "Phone Dialer",
        description: "Make phone calls",
        icon: "fas fa-phone",
        appName: "Phone",
        instructions: "To make a phone call, first open your phone app. Then tap the dial pad and enter the phone number. Finally, press the call button to start the call.",
        prompt: "Enter a phone number (10 digits)",
        label: "Phone Number",
        hint: "Must be exactly 10 digits",
        placeholder: "9876543210",
        validationRule: "phone"
      },
      {
        id: "sms",
        title: "SMS Messages",
        description: "Send text messages",
        icon: "fas fa-sms",
        appName: "Messages",
        instructions: "To send an SMS, open your messages app. Select a contact or enter a phone number. Type your message and tap send.",
        prompt: "Type a message to send (at least 3 characters)",
        label: "Message Text",
        hint: "Minimum 3 characters",
        placeholder: "Hello, how are you?",
        validationRule: "message"
      },
      {
        id: "whatsapp",
        title: "WhatsApp",
        description: "Chat with contacts",
        icon: "fab fa-whatsapp",
        appName: "WhatsApp",
        instructions: "To send a WhatsApp message, open WhatsApp. Find your contact or search for them. Tap to open the chat and type your message.",
        prompt: "Search for a contact (at least 2 characters)",
        label: "Contact Search",
        hint: "Minimum 2 characters",
        placeholder: "John Doe",
        validationRule: "search"
      }
    ]
  },
  {
    id: "finance",
    title: "Finance / UPI",
    description: "Scanner, Send, History",
    icon: "fas fa-credit-card",
    color: "green",
    scenarios: [
      {
        id: "upi-send",
        title: "Send Money",
        description: "Transfer money via UPI",
        icon: "fas fa-paper-plane",
        appName: "UPI Pay",
        instructions: "To send money using UPI, open your payment app. Enter the recipient's UPI ID, which usually ends with @ followed by a bank name. Enter the amount and confirm the payment.",
        prompt: "Enter a UPI ID (must contain @)",
        label: "UPI ID",
        hint: "Format: name@bankname",
        placeholder: "username@paytm",
        validationRule: "upi"
      },
      {
        id: "upi-scanner",
        title: "QR Scanner",
        description: "Scan QR codes to pay",
        icon: "fas fa-qrcode",
        appName: "QR Scanner",
        instructions: "To scan and pay, open the scanner in your payment app. Point your camera at the QR code. Enter the amount and confirm payment.",
        prompt: "Enter merchant name (at least 3 characters)",
        label: "Merchant Name",
        hint: "Minimum 3 characters",
        placeholder: "Coffee Shop",
        validationRule: "search"
      },
      {
        id: "upi-history",
        title: "Payment History",
        description: "View transaction history",
        icon: "fas fa-history",
        appName: "Transaction History",
        instructions: "To view your payment history, open your payment app and look for the history or transactions section. You can filter by date or amount.",
        prompt: "Search transactions (at least 2 characters)",
        label: "Search Query",
        hint: "Minimum 2 characters",
        placeholder: "Coffee",
        validationRule: "search"
      }
    ]
  },
  {
    id: "entertainment",
    title: "Entertainment",
    description: "Facebook, Instagram, OTT",
    icon: "fas fa-play",
    color: "red",
    scenarios: [
      {
        id: "facebook",
        title: "Facebook",
        description: "Social networking",
        icon: "fab fa-facebook",
        appName: "Facebook",
        instructions: "To use Facebook, open the app and scroll through your feed. You can like posts, comment, or share content with friends.",
        prompt: "Search for friends or posts (at least 2 characters)",
        label: "Search",
        hint: "Minimum 2 characters",
        placeholder: "Friends, pages, posts",
        validationRule: "search"
      },
      {
        id: "instagram",
        title: "Instagram", 
        description: "Photo and video sharing",
        icon: "fab fa-instagram",
        appName: "Instagram",
        instructions: "To use Instagram, open the app to view your feed. You can like, comment, or share posts. Tap the camera icon to take photos or videos.",
        prompt: "Search for users or hashtags (at least 2 characters)",
        label: "Search",
        hint: "Minimum 2 characters",
        placeholder: "#travel or @username",
        validationRule: "search"
      },
      {
        id: "ott",
        title: "OTT Streaming",
        description: "Watch movies and shows",
        icon: "fas fa-tv",
        appName: "Video Streaming",
        instructions: "To watch content on streaming platforms, open your preferred app. Browse categories or search for movies and shows. Tap to play.",
        prompt: "Search for movies or shows (at least 2 characters)",
        label: "Search Content",
        hint: "Minimum 2 characters",
        placeholder: "Action movies",
        validationRule: "search"
      }
    ]
  }
];
