# DigiSethuCoach - AI-Powered Digital Literacy Training Simulator

## Overview

DigiSethuCoach is a React-based web application that provides interactive digital literacy and soft skills training through realistic simulations. The app offers practice environments for phone calls, messaging, digital payments, form filling, and customer support interactions, with AI-powered coaching and feedback to help users build confidence in handling digital tasks and real-world communication scenarios.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui design system for accessible, consistent interface
- **Styling**: Tailwind CSS with custom design tokens and mobile-first responsive design
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Design**: RESTful endpoints with JSON responses
- **Development**: Hot module replacement and development middleware integration
- **Storage**: In-memory storage implementation with interface for future database integration

### Data Storage Solutions
- **Database**: PostgreSQL configured with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL for scalable cloud hosting
- **Schema**: Structured tables for users, simulations, progress tracking, and achievements
- **Development**: In-memory storage fallback for development and testing

### Authentication and Authorization
- **Current**: Demo user system for development and testing
- **Architecture**: Session-based authentication structure prepared for future implementation
- **User Management**: Basic user model with username/password schema ready for expansion

### Core Simulation System
- **AI Integration**: OpenAI GPT-5 API for realistic conversation simulation and coaching feedback
- **Simulation Types**: Five distinct modules (calls, messaging, payments, forms, support)
- **Progress Tracking**: Comprehensive scoring and skill progression system
- **Coaching Engine**: Automated feedback generation with strengths, improvements, and next steps

## External Dependencies

### AI and Machine Learning
- **OpenAI API**: GPT-5 model for natural language processing, conversation simulation, and coaching feedback generation
- **Usage**: Real-time response generation, scenario adaptation, and personalized coaching insights

### Database and Storage
- **Neon Database**: Serverless PostgreSQL hosting for production data persistence
- **Drizzle ORM**: Type-safe database operations with schema migration support
- **Connection Pooling**: Built-in connection management for optimal performance

### UI and Design System
- **Radix UI**: Comprehensive accessible component primitives for form controls, dialogs, and interactive elements
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens and responsive utilities
- **Lucide React**: Consistent icon system for interface elements

### Development and Build Tools
- **Vite**: Fast build tool with hot module replacement and optimized bundling
- **TypeScript**: Static type checking for enhanced developer experience and code reliability
- **ESLint/Prettier**: Code quality and formatting tools for consistent codebase maintenance

### Deployment and Platform
- **Replit Integration**: Development environment optimization with runtime error handling and development banners
- **Environment Configuration**: Flexible configuration for development, staging, and production deployments