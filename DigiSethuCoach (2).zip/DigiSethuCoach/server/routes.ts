import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiCoach } from "./services/openai";
import { insertSimulationSchema, type CoachingFeedback } from "@shared/schema";
import { z } from "zod";

const createSimulationSchema = z.object({
  type: z.string()
});

const messageSchema = z.object({
  simulationId: z.string(),
  message: z.string(),
  sender: z.enum(["user", "ai"])
});

const sendMessageSchema = z.object({
  message: z.string().min(1)
});

const completeSimulationSchema = z.object({
  simulationId: z.string()
});

export async function registerRoutes(app: Express): Promise<Server> {
  const DEMO_USER_ID = "demo-user-123";

  // Get user progress and statistics
  app.get("/api/progress", async (req, res) => {
    try {
      const progress = await storage.getUserProgress(DEMO_USER_ID);
      const simulations = await storage.getUserSimulations(DEMO_USER_ID);
      const achievements = await storage.getUserAchievements(DEMO_USER_ID);

      const totalSimulations = simulations.length;
      const completedSimulations = simulations.filter(s => s.status === 'completed');
      const averageScore = completedSimulations.length > 0 
        ? Math.round(completedSimulations.reduce((sum, s) => sum + (s.score || 0), 0) / completedSimulations.length)
        : 0;

      res.json({
        progress,
        achievements,
        totalSimulations,
        averageScore,
        recentActivities: completedSimulations.slice(0, 5).map(s => ({
          id: s.id,
          type: s.type,
          scenario: s.scenario,
          score: s.score,
          completedAt: s.completedAt
        }))
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get progress data" });
    }
  });

  // Create new simulation
  app.post("/api/simulations", async (req, res) => {
    try {
      console.log("Creating simulation with request body:", req.body);
      const { type } = createSimulationSchema.parse(req.body);
      
      console.log("Generating scenario for type:", type);
      const scenario = await aiCoach.generateScenario(type);
      console.log("Generated scenario:", scenario);
      
      const simulation = await storage.createSimulation({
        userId: DEMO_USER_ID,
        type,
        scenario
      });

      console.log("Created simulation:", simulation.id);
      res.json(simulation);
    } catch (error) {
      console.error("Error creating simulation:", error);
      res.status(400).json({ error: "Failed to create simulation", details: (error as Error).message });
    }
  });

  // Get simulation by ID
  app.get("/api/simulations/:id", async (req, res) => {
    try {
      const simulation = await storage.getSimulation(req.params.id);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }
      res.json(simulation);
    } catch (error) {
      res.status(500).json({ error: "Failed to get simulation" });
    }
  });

  // Send message in simulation
  app.post("/api/simulations/:id/messages", async (req, res) => {
    try {
      const { message } = sendMessageSchema.parse(req.body);
      const simulationId = req.params.id;
      
      const simulation = await storage.getSimulation(simulationId);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }

      // Get conversation history
      const conversationHistory = simulation.conversationHistory as any[] || [];
      
      // Add user message to history
      const userMessage = { sender: "user", message, timestamp: new Date() };
      conversationHistory.push(userMessage);

      // Generate AI response
      const aiResponse = await aiCoach.generateSimulationResponse(
        simulation.type,
        simulation.scenario,
        conversationHistory,
        message
      );

      // Add AI response to history
      const aiMessage = { 
        sender: "ai", 
        message: aiResponse.message, 
        timestamp: new Date() 
      };
      conversationHistory.push(aiMessage);

      // Update simulation with new conversation history
      await storage.updateSimulation(simulationId, {
        conversationHistory: conversationHistory
      });

      res.json({
        message: aiResponse.message,
        isComplete: aiResponse.isComplete
      });
    } catch (error) {
      console.error("Error handling message:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Complete simulation and get feedback
  app.post("/api/simulations/:id/complete", async (req, res) => {
    try {
      const simulationId = req.params.id;
      
      const simulation = await storage.getSimulation(simulationId);
      if (!simulation) {
        return res.status(404).json({ error: "Simulation not found" });
      }

      // Generate coaching feedback
      const conversationHistory = simulation.conversationHistory as any[] || [];
      const feedback = await aiCoach.generateCoachingFeedback(
        simulation.type,
        simulation.scenario,
        conversationHistory
      );

      // Update simulation as completed
      const updatedSimulation = await storage.updateSimulation(simulationId, {
        status: "completed",
        score: feedback.score,
        feedback: feedback,
        completedAt: new Date()
      });

      // Update user progress
      const existingProgress = await storage.getSkillProgress(DEMO_USER_ID, simulation.type);
      const newTotalSims = (existingProgress?.totalSimulations || 0) + 1;
      const newAvgScore = existingProgress 
        ? Math.round(((existingProgress.averageScore * existingProgress.totalSimulations) + feedback.score) / newTotalSims)
        : feedback.score;

      await storage.updateUserProgress(DEMO_USER_ID, simulation.type, {
        totalSimulations: newTotalSims,
        averageScore: newAvgScore,
        lastActivityAt: new Date()
      });

      // Check for new achievements
      if (feedback.score >= 90 && newTotalSims >= 5) {
        const achievements = await storage.getUserAchievements(DEMO_USER_ID);
        const hasHighScorerAchievement = achievements.some(a => a.type === 'high_scorer' && a.title.includes(simulation.type));
        
        if (!hasHighScorerAchievement) {
          await storage.createAchievement({
            userId: DEMO_USER_ID,
            title: `${simulation.type.charAt(0).toUpperCase() + simulation.type.slice(1)} Expert`,
            description: `Scored 90+ on multiple ${simulation.type} simulations`,
            type: 'high_scorer'
          });
        }
      }

      res.json({
        simulation: updatedSimulation,
        feedback
      });
    } catch (error) {
      console.error("Error completing simulation:", error);
      res.status(500).json({ error: "Failed to complete simulation" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
