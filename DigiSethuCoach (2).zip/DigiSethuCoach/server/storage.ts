import { type User, type InsertUser, type Simulation, type InsertSimulation, type UserProgress, type InsertUserProgress, type Achievement, type InsertAchievement } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Simulation management
  createSimulation(simulation: InsertSimulation): Promise<Simulation>;
  getSimulation(id: string): Promise<Simulation | undefined>;
  getUserSimulations(userId: string): Promise<Simulation[]>;
  updateSimulation(id: string, updates: Partial<Simulation>): Promise<Simulation | undefined>;

  // Progress tracking
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getSkillProgress(userId: string, skillType: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, skillType: string, updates: Partial<UserProgress>): Promise<UserProgress>;

  // Achievements
  getUserAchievements(userId: string): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private simulations: Map<string, Simulation>;
  private userProgress: Map<string, UserProgress>;
  private achievements: Map<string, Achievement>;

  constructor() {
    this.users = new Map();
    this.simulations = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();

    // Initialize demo user and progress
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create demo user
    const demoUser: User = {
      id: "demo-user-123",
      username: "demo",
      password: "demo"
    };
    this.users.set(demoUser.id, demoUser);

    // Initialize skill progress for demo user
    const skills = ['phone', 'messaging', 'payments', 'forms', 'support'];
    skills.forEach(skill => {
      const progress: UserProgress = {
        id: randomUUID(),
        userId: demoUser.id,
        skillType: skill,
        level: Math.floor(Math.random() * 3) + 1,
        totalSimulations: Math.floor(Math.random() * 15) + 5,
        averageScore: Math.floor(Math.random() * 30) + 70,
        lastActivityAt: new Date()
      };
      this.userProgress.set(`${demoUser.id}-${skill}`, progress);
    });

    // Add some achievements
    const sampleAchievements: Achievement[] = [
      {
        id: randomUUID(),
        userId: demoUser.id,
        title: "Phone Master",
        description: "Completed 10 phone simulations",
        type: "skill_master",
        unlockedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      {
        id: randomUUID(),
        userId: demoUser.id,
        title: "Payment Pro",
        description: "Scored 90+ on 5 payment simulations",
        type: "high_scorer",
        unlockedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      }
    ];

    sampleAchievements.forEach(achievement => {
      this.achievements.set(achievement.id, achievement);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createSimulation(insertSimulation: InsertSimulation): Promise<Simulation> {
    const id = randomUUID();
    const simulation: Simulation = {
      ...insertSimulation,
      id,
      status: "active",
      score: null,
      feedback: null,
      conversationHistory: null,
      createdAt: new Date(),
      completedAt: null
    };
    this.simulations.set(id, simulation);
    return simulation;
  }

  async getSimulation(id: string): Promise<Simulation | undefined> {
    return this.simulations.get(id);
  }

  async getUserSimulations(userId: string): Promise<Simulation[]> {
    return Array.from(this.simulations.values()).filter(
      simulation => simulation.userId === userId
    ).sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async updateSimulation(id: string, updates: Partial<Simulation>): Promise<Simulation | undefined> {
    const simulation = this.simulations.get(id);
    if (!simulation) return undefined;

    const updated = { ...simulation, ...updates };
    this.simulations.set(id, updated);
    return updated;
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      progress => progress.userId === userId
    );
  }

  async getSkillProgress(userId: string, skillType: string): Promise<UserProgress | undefined> {
    return this.userProgress.get(`${userId}-${skillType}`);
  }

  async updateUserProgress(userId: string, skillType: string, updates: Partial<UserProgress>): Promise<UserProgress> {
    const key = `${userId}-${skillType}`;
    const existing = this.userProgress.get(key);
    
    const progress: UserProgress = {
      id: existing?.id || randomUUID(),
      userId,
      skillType,
      level: 1,
      totalSimulations: 0,
      averageScore: 0,
      lastActivityAt: new Date(),
      ...existing,
      ...updates
    };
    
    this.userProgress.set(key, progress);
    return progress;
  }

  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(
      achievement => achievement.userId === userId
    ).sort((a, b) => (b.unlockedAt?.getTime() || 0) - (a.unlockedAt?.getTime() || 0));
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = randomUUID();
    const achievement: Achievement = {
      ...insertAchievement,
      id,
      unlockedAt: new Date()
    };
    this.achievements.set(id, achievement);
    return achievement;
  }
}

export const storage = new MemStorage();
