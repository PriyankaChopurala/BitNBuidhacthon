import OpenAI from "openai";
import type { CoachingFeedback, SimulationResponse } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export class AICoachService {
  async generateSimulationResponse(
    simulationType: string,
    scenario: string,
    conversationHistory: any[],
    userInput: string
  ): Promise<SimulationResponse> {
    const contextPrompts = {
      call: "You are conducting a phone call simulation. Respond as the other person in the conversation (interviewer, bank agent, customer service, etc.). Keep responses natural and conversational.",
      message: "You are in a WhatsApp-style chat simulation. Respond as the other person in casual, natural texting style with appropriate emojis and informal language.",
      payment: "You are guiding someone through a UPI payment process. Provide clear instructions and handle any issues that arise during the transaction.",
      form: "You are helping someone fill out an online form. Validate their inputs, point out errors clearly, and guide them through corrections.",
      support: "You are a customer support agent. Be helpful, professional, and guide the user through resolving their issue step by step."
    };

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `${contextPrompts[simulationType as keyof typeof contextPrompts] || contextPrompts.support}
            
            Scenario: ${scenario}
            
            Conversation so far: ${JSON.stringify(conversationHistory)}
            
            Respond naturally to the user's input. Keep responses concise (1-2 sentences max). If this seems like a natural ending point for the simulation, include "SIMULATION_COMPLETE" in your response.
            
            Respond in JSON format: { "message": "your response", "isComplete": false }`
          },
          {
            role: "user",
            content: userInput
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        message: result.message || "I understand. Please continue.",
        isComplete: result.isComplete || result.message?.includes("SIMULATION_COMPLETE") || false
      };
    } catch (error) {
      console.error("Error generating AI response:", error);
      return {
        message: "I'm having trouble responding right now. Please try again.",
        isComplete: false
      };
    }
  }

  async generateCoachingFeedback(
    simulationType: string,
    scenario: string,
    conversationHistory: any[]
  ): Promise<CoachingFeedback> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `You are DigiSethuCoach, an AI coaching system for digital literacy training. Analyze this ${simulationType} simulation and provide constructive feedback.
            
            Scenario: ${scenario}
            Full conversation: ${JSON.stringify(conversationHistory)}
            
            Provide feedback in JSON format:
            {
              "score": number (0-100),
              "strengths": ["strength1", "strength2"],
              "improvements": ["area1", "area2"],
              "nextSteps": ["step1", "step2"],
              "overallComment": "encouraging summary comment"
            }
            
            Focus on communication skills, digital literacy aspects, and practical improvements. Be encouraging but specific.`
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        score: Math.max(0, Math.min(100, result.score || 75)),
        strengths: result.strengths || ["Clear communication"],
        improvements: result.improvements || ["Continue practicing"],
        nextSteps: result.nextSteps || ["Try another simulation"],
        overallComment: result.overallComment || "Keep up the good work!"
      };
    } catch (error) {
      console.error("Error generating coaching feedback:", error);
      return {
        score: 75,
        strengths: ["Completed the simulation"],
        improvements: ["Continue practicing to improve"],
        nextSteps: ["Try more simulations"],
        overallComment: "Good effort! Keep practicing to improve your skills."
      };
    }
  }

  async generateScenario(simulationType: string): Promise<string> {
    const scenarioPrompts = {
      call: "Generate a realistic phone call scenario (job interview, bank inquiry, customer service call, etc.)",
      message: "Generate a realistic WhatsApp chat scenario (friend conversation, customer inquiry, family chat, etc.)",
      payment: "Generate a realistic UPI payment scenario (merchant payment, bill payment, money transfer, etc.)",
      form: "Generate a realistic online form scenario (bank KYC, job application, government form, etc.)",
      support: "Generate a realistic customer support scenario (product issue, service inquiry, complaint resolution, etc.)"
    };

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `${scenarioPrompts[simulationType as keyof typeof scenarioPrompts]}. 
            
            Return a brief, realistic scenario description (2-3 sentences) that someone in India might encounter. Make it specific and practical.
            
            Respond in JSON format: { "scenario": "your scenario description" }`
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return result.scenario || `Practice ${simulationType} simulation`;
    } catch (error) {
      console.error("Error generating scenario:", error);
      return `Practice ${simulationType} simulation`;
    }
  }
}

export const aiCoach = new AICoachService();
