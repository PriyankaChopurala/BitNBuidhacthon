import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const simulations = pgTable("simulations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: varchar("type").notNull(), // 'call', 'message', 'payment', 'form', 'support'
  scenario: text("scenario").notNull(),
  status: varchar("status").notNull().default("active"), // 'active', 'completed'
  score: integer("score"),
  feedback: jsonb("feedback"),
  conversationHistory: jsonb("conversation_history"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  skillType: varchar("skill_type").notNull(), // 'phone', 'messaging', 'payments', 'forms', 'support'
  level: integer("level").notNull().default(1),
  totalSimulations: integer("total_simulations").notNull().default(0),
  averageScore: integer("average_score").notNull().default(0),
  lastActivityAt: timestamp("last_activity_at").defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: varchar("type").notNull(), // 'skill_master', 'high_scorer', 'streak', etc.
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSimulationSchema = createInsertSchema(simulations).pick({
  userId: true,
  type: true,
  scenario: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  skillType: true,
  level: true,
  totalSimulations: true,
  averageScore: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  userId: true,
  title: true,
  description: true,
  type: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSimulation = z.infer<typeof insertSimulationSchema>;
export type Simulation = typeof simulations.$inferSelect;

export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// API Response Types
export type CoachingFeedback = {
  score: number;
  strengths: string[];
  improvements: string[];
  nextSteps: string[];
  overallComment: string;
};

export type SimulationResponse = {
  message: string;
  isComplete?: boolean;
  feedback?: CoachingFeedback;
};
