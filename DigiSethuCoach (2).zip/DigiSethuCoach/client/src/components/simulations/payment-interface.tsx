import { useState } from "react";
import { ArrowLeft, MoreVertical, Store, University, CreditCard, CheckCircle, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

interface PaymentMethod {
  id: string;
  type: "bank" | "upi" | "card";
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface PaymentInterfaceProps {
  merchantName: string;
  amount: string;
  paymentMethods: PaymentMethod[];
  onProcessPayment: (selectedMethod: string, pin: string[]) => void;
  onBack: () => void;
  isProcessing?: boolean;
  disabled?: boolean;
}

export default function PaymentInterface({
  merchantName,
  amount,
  paymentMethods,
  onProcessPayment,
  onBack,
  isProcessing = false,
  disabled = false
}: PaymentInterfaceProps) {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(paymentMethods[0]?.id || "");
  const [upiPin, setUpiPin] = useState(["", "", "", ""]);

  const handlePinChange = (index: number, value: string) => {
    if (value.length <= 1 && /^[0-9]*$/.test(value)) {
      const newPin = [...upiPin];
      newPin[index] = value;
      setUpiPin(newPin);
      
      // Auto-focus next input
      if (value && index < 3) {
        const nextInput = document.querySelector(`input[data-pin-index="${index + 1}"]`) as HTMLInputElement;
        nextInput?.focus();
      }
    }
  };

  const handleProcessPayment = () => {
    onProcessPayment(selectedPaymentMethod, upiPin);
  };

  return (
    <div className="bg-background min-h-screen" data-testid="payment-interface">
      {/* Payment Header */}
      <div className="payment-gradient text-white p-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-white hover:text-white/80 p-0"
            data-testid="back-button"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h2 className="text-lg font-semibold" data-testid="header-title">DigiPay Simulator</h2>
          <Button variant="ghost" size="sm" className="text-white hover:text-white/80 p-0" data-testid="menu-button">
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Store className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Pay to Merchant</h3>
          <p className="text-white/80" data-testid="merchant-name">
            {merchantName}
          </p>
        </div>
      </div>
      
      {/* Payment Form */}
      <div className="p-6 -mt-4">
        <Card className="rounded-xl shadow-lg p-6 border" data-testid="payment-form">
          <div className="text-center mb-6">
            <div className="text-3xl font-bold text-primary mb-2" data-testid="payment-amount">{amount}</div>
            <p className="text-muted-foreground">Amount to pay</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Payment Method</label>
              <div className="space-y-2" data-testid="payment-methods">
                {paymentMethods.map((method) => (
                  <div 
                    key={method.id}
                    className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedPaymentMethod === method.id 
                        ? "bg-primary/5 border-primary" 
                        : "hover:bg-muted/50"
                    }`}
                    onClick={() => setSelectedPaymentMethod(method.id)}
                    data-testid={`payment-method-${method.id}`}
                  >
                    <div className={`mr-3 w-5 h-5 ${
                      selectedPaymentMethod === method.id ? "text-primary" : "text-muted-foreground"
                    }`}>
                      {method.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{method.name}</p>
                      <p className="text-sm text-muted-foreground">{method.description}</p>
                    </div>
                    {selectedPaymentMethod === method.id && (
                      <CheckCircle className="text-primary w-5 h-5" />
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">UPI PIN</label>
              <div className="grid grid-cols-4 gap-2" data-testid="upi-pin-inputs">
                {upiPin.map((digit, index) => (
                  <Input
                    key={index}
                    type="password"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handlePinChange(index, e.target.value)}
                    data-pin-index={index}
                    data-testid={`pin-input-${index}`}
                    className="w-full h-12 text-center text-lg font-mono focus:outline-none focus:ring-2 focus:ring-primary"
                    disabled={disabled || isProcessing}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <Button 
            onClick={handleProcessPayment}
            disabled={disabled || isProcessing || upiPin.some(digit => !digit)}
            className="w-full py-3 font-semibold mt-6 transition-colors"
            data-testid="pay-button"
          >
            {isProcessing ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </div>
            ) : (
              `Pay ${amount}`
            )}
          </Button>
          
          <div className="flex items-center justify-center mt-4 text-sm text-muted-foreground" data-testid="security-notice">
            <Shield className="w-4 h-4 mr-2" />
            Secured by 256-bit encryption
          </div>
        </Card>
      </div>
    </div>
  );
}
