import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Paperclip, Send, MoreVertical, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Message {
  sender: "user" | "ai";
  message: string;
  timestamp: Date;
}

interface MessageInterfaceProps {
  title: string;
  subtitle: string;
  messages: Message[];
  isTyping: boolean;
  onSendMessage: (message: string) => void;
  onBack: () => void;
  disabled?: boolean;
}

export default function MessageInterface({
  title,
  subtitle,
  messages,
  isTyping,
  onSendMessage,
  onBack,
  disabled = false
}: MessageInterfaceProps) {
  const [userInput, setUserInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSendMessage = () => {
    if (!userInput.trim() || disabled) return;
    
    onSendMessage(userInput);
    setUserInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="bg-muted min-h-screen flex flex-col" data-testid="message-interface">
      {/* Chat Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center space-x-3">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onBack}
          className="text-primary-foreground hover:text-primary-foreground/80 p-0"
          data-testid="back-button"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
          <Bot className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold" data-testid="chat-title">{title}</h3>
          <p className="text-xs text-primary-foreground/80" data-testid="chat-subtitle">
            {subtitle}
          </p>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-primary-foreground hover:text-primary-foreground/80 p-0"
          data-testid="menu-button"
        >
          <MoreVertical className="w-5 h-5" />
        </Button>
      </div>
      
      {/* Chat Messages */}
      <div 
        className="flex-1 p-4 space-y-4 overflow-y-auto"
        style={{
          backgroundImage: `url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><defs><pattern id='chat-bg' patternUnits='userSpaceOnUse' width='40' height='40'><circle cx='20' cy='20' r='1' fill='%23000' opacity='0.05'/></pattern></defs><rect width='100' height='100' fill='url(%23chat-bg)'/></svg>")`
        }}
        data-testid="chat-messages"
      >
        {messages.map((msg, index) => (
          <div key={index} className={`flex items-start space-x-2 ${
            msg.sender === "user" ? "justify-end" : "justify-start"
          }`}>
            {msg.sender === "ai" && (
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-primary-foreground w-4 h-4" />
              </div>
            )}
            
            <div className={`rounded-lg p-3 max-w-xs shadow-sm ${
              msg.sender === "user" 
                ? "chat-bubble-user" 
                : "chat-bubble-ai"
            }`} data-testid={`message-${msg.sender}-${index}`}>
              <p className="text-sm">{msg.message}</p>
              <div className={`text-xs text-muted-foreground mt-1 ${
                msg.sender === "user" ? "text-right" : "text-left"
              }`}>
                {formatTime(new Date(msg.timestamp))} {msg.sender === "user" && "✓✓"}
              </div>
            </div>
            
            {msg.sender === "user" && (
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <User className="text-primary-foreground w-4 h-4" />
              </div>
            )}
          </div>
        ))}
        
        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start space-x-2" data-testid="typing-indicator">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="text-primary-foreground w-4 h-4" />
            </div>
            <div className="chat-bubble-ai rounded-lg p-3 shadow-sm">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Chat Input */}
      <div className="bg-card border-t p-4" data-testid="chat-input-area">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground" data-testid="attachment-button">
            <Paperclip className="w-4 h-4" />
          </Button>
          <Input 
            type="text" 
            placeholder="Type a message..." 
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={disabled}
            className="flex-1 bg-secondary border border-border rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            data-testid="message-input"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!userInput.trim() || disabled}
            className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground hover:bg-primary/80 transition-colors"
            data-testid="send-button"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
