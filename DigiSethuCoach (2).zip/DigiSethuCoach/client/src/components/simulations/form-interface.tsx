import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface FormField {
  id: string;
  label: string;
  type: "text" | "date" | "tel" | "radio" | "select";
  placeholder?: string;
  required?: boolean;
  options?: { value: string; label: string }[];
  validation?: (value: string) => string | null;
}

interface FormStep {
  id: number;
  title: string;
  fields: FormField[];
}

interface FormInterfaceProps {
  formTitle: string;
  steps: FormStep[];
  currentStep: number;
  formData: { [key: string]: string };
  errors: { [key: string]: string };
  onFieldChange: (fieldId: string, value: string) => void;
  onNextStep: () => void;
  onPreviousStep: () => void;
  onBack: () => void;
  isSubmitting?: boolean;
  disabled?: boolean;
}

export default function FormInterface({
  formTitle,
  steps,
  currentStep,
  formData,
  errors,
  onFieldChange,
  onNextStep,
  onPreviousStep,
  onBack,
  isSubmitting = false,
  disabled = false
}: FormInterfaceProps) {
  const currentStepData = steps.find(step => step.id === currentStep);
  const progressPercentage = (currentStep / steps.length) * 100;
  const isLastStep = currentStep === steps.length;
  const isFirstStep = currentStep === 1;

  const renderField = (field: FormField) => {
    switch (field.type) {
      case "text":
      case "date":
      case "tel":
        return (
          <div key={field.id}>
            <label className="block text-sm font-medium mb-2">
              {field.label} {field.required && "*"}
            </label>
            {field.type === "tel" && field.id === "mobileNumber" ? (
              <div className="flex">
                <span className="inline-flex items-center px-3 border border-r-0 border-border rounded-l-lg bg-muted text-muted-foreground">
                  +91
                </span>
                <Input 
                  type={field.type}
                  placeholder={field.placeholder}
                  value={formData[field.id] || ""}
                  onChange={(e) => onFieldChange(field.id, e.target.value)}
                  className={`flex-1 rounded-l-none ${errors[field.id] ? "border-destructive" : ""}`}
                  disabled={disabled}
                  data-testid={`input-${field.id}`}
                />
              </div>
            ) : (
              <Input 
                type={field.type}
                placeholder={field.placeholder}
                value={formData[field.id] || ""}
                onChange={(e) => onFieldChange(field.id, e.target.value)}
                className={errors[field.id] ? "border-destructive" : ""}
                disabled={disabled}
                data-testid={`input-${field.id}`}
              />
            )}
            {field.id === "mobileNumber" && (
              <p className="text-xs text-muted-foreground mt-1">We'll send an OTP for verification</p>
            )}
            {errors[field.id] && (
              field.id === "aadhaarNumber" ? (
                <Alert className="mt-2 border-destructive/20 bg-destructive/10" data-testid={`error-${field.id}`}>
                  <AlertDescription className="text-destructive">
                    {errors[field.id]}
                  </AlertDescription>
                </Alert>
              ) : (
                <p className="text-sm text-destructive mt-1" data-testid={`error-${field.id}`}>
                  {errors[field.id]}
                </p>
              )
            )}
          </div>
        );

      case "radio":
        return (
          <div key={field.id}>
            <label className="block text-sm font-medium mb-2">
              {field.label} {field.required && "*"}
            </label>
            <div className="flex space-x-4" data-testid={`radio-group-${field.id}`}>
              {field.options?.map((option) => (
                <label key={option.value} className="flex items-center cursor-pointer">
                  <input 
                    type="radio" 
                    name={field.id}
                    value={option.value}
                    checked={formData[field.id] === option.value}
                    onChange={(e) => onFieldChange(field.id, e.target.value)}
                    className="mr-2 text-primary focus:ring-primary"
                    disabled={disabled}
                    data-testid={`radio-${field.id}-${option.value}`}
                  />
                  {option.label}
                </label>
              ))}
            </div>
            {errors[field.id] && (
              <p className="text-sm text-destructive mt-1" data-testid={`error-${field.id}`}>
                {errors[field.id]}
              </p>
            )}
          </div>
        );

      case "select":
        return (
          <div key={field.id}>
            <label className="block text-sm font-medium mb-2">
              {field.label} {field.required && "*"}
            </label>
            <select
              value={formData[field.id] || ""}
              onChange={(e) => onFieldChange(field.id, e.target.value)}
              className={`w-full border rounded-lg px-3 py-2 bg-background ${
                errors[field.id] ? "border-destructive" : "border-border"
              }`}
              disabled={disabled}
              data-testid={`select-${field.id}`}
            >
              <option value="">Select {field.label}</option>
              {field.options?.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            {errors[field.id] && (
              <p className="text-sm text-destructive mt-1" data-testid={`error-${field.id}`}>
                {errors[field.id]}
              </p>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="bg-background min-h-screen" data-testid="form-interface">
      {/* Form Header */}
      <div className="bg-card border-b p-4">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-muted-foreground hover:text-foreground p-0"
            data-testid="back-button"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h2 className="font-semibold" data-testid="form-title">
              {formTitle}
            </h2>
            <p className="text-sm text-muted-foreground">Complete your profile</p>
          </div>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="p-4 bg-card border-b" data-testid="progress-section">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Step {currentStep} of {steps.length}</span>
          <span className="text-sm text-muted-foreground">{Math.round(progressPercentage)}% Complete</span>
        </div>
        <Progress value={progressPercentage} className="transition-all duration-300" />
      </div>
      
      {/* Form Content */}
      <div className="p-6">
        <h3 className="text-lg font-semibold mb-6" data-testid="section-title">
          {currentStepData?.title}
        </h3>
        
        <div className="space-y-4" data-testid={`step-${currentStep}-form`}>
          {currentStepData?.fields.map(renderField)}
        </div>
        
        <div className="flex space-x-4 mt-8" data-testid="form-navigation">
          <Button 
            variant="outline"
            onClick={onPreviousStep}
            disabled={isFirstStep || disabled}
            className="flex-1"
            data-testid="previous-button"
          >
            Previous
          </Button>
          <Button 
            onClick={onNextStep}
            disabled={disabled || isSubmitting}
            className="flex-1"
            data-testid="next-button"
          >
            {isLastStep ? (isSubmitting ? "Submitting..." : "Complete") : "Next Step"}
          </Button>
        </div>
      </div>
    </div>
  );
}
