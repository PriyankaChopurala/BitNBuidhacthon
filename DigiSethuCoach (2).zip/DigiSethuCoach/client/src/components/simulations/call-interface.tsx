import { useState, useEffect } from "react";
import { PhoneOff, Mic, MicOff, Volume2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface CallInterfaceProps {
  contactName: string;
  contactRole: string;
  contactImage?: string;
  currentMessage: string;
  isAISpeaking: boolean;
  onSendMessage: (message: string) => void;
  onEndCall: () => void;
  disabled?: boolean;
  callDuration?: number;
}

export default function CallInterface({
  contactName,
  contactRole,
  contactImage,
  currentMessage,
  isAISpeaking,
  onSendMessage,
  onEndCall,
  disabled = false,
  callDuration = 0
}: CallInterfaceProps) {
  const [userInput, setUserInput] = useState("");
  const [isMuted, setIsMuted] = useState(false);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendMessage = () => {
    if (!userInput.trim() || disabled) return;
    
    onSendMessage(userInput);
    setUserInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="call-screen-bg min-h-screen flex flex-col justify-between text-white p-6" data-testid="call-interface">
      {/* Call Header */}
      <div className="text-center pt-12">
        <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
          {contactImage ? (
            <img 
              src={contactImage}
              alt={`${contactName}`}
              className="w-28 h-28 rounded-full object-cover"
              data-testid="contact-image"
            />
          ) : (
            <div className="w-28 h-28 rounded-full bg-white/30 flex items-center justify-center">
              <span className="text-2xl font-bold">{contactName.charAt(0)}</span>
            </div>
          )}
        </div>
        <h2 className="text-xl font-semibold mb-1" data-testid="contact-name">
          {contactName}
        </h2>
        <p className="text-white/80" data-testid="contact-role">
          {contactRole}
        </p>
        <div className="text-lg font-mono mt-4" data-testid="call-timer">
          {formatTime(callDuration)}
        </div>
      </div>
      
      {/* Call Content */}
      <div className="flex-1 flex items-center justify-center">
        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-sm mx-auto" data-testid="conversation-area">
          <div className="text-center mb-4">
            {isAISpeaking ? (
              <>
                <div className="animate-pulse-slow w-3 h-3 bg-white rounded-full mx-auto mb-2" data-testid="ai-speaking-indicator"></div>
                <p className="text-sm">AI is speaking...</p>
              </>
            ) : (
              <>
                <div className="w-3 h-3 bg-white/50 rounded-full mx-auto mb-2"></div>
                <p className="text-sm">Your turn to speak</p>
              </>
            )}
          </div>
          <div className="bg-white/20 rounded-lg p-3 mb-4" data-testid="ai-message">
            <p className="text-sm">"{currentMessage}"</p>
          </div>
          <div className="flex space-x-2">
            <Input 
              type="text" 
              placeholder="Type your response..." 
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={disabled || isAISpeaking}
              className="flex-1 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 text-sm"
              data-testid="message-input"
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!userInput.trim() || disabled || isAISpeaking}
              className="bg-accent hover:bg-accent/80 px-4 py-2"
              data-testid="send-button"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Call Controls */}
      <div className="flex justify-center space-x-6" data-testid="call-controls">
        <Button 
          onClick={() => setIsMuted(!isMuted)}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
            isMuted ? "bg-red-600 hover:bg-red-700" : "bg-white/20 hover:bg-white/30"
          }`}
          data-testid="mute-button"
        >
          {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </Button>
        
        <Button 
          onClick={onEndCall}
          disabled={disabled}
          className="w-16 h-16 bg-destructive rounded-full flex items-center justify-center hover:bg-destructive/80 transition-colors"
          data-testid="end-call-button"
        >
          <PhoneOff className="w-6 h-6" />
        </Button>
        
        <Button 
          className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
          data-testid="speaker-button"
        >
          <Volume2 className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}
