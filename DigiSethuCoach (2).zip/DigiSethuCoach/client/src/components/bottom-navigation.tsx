import { Link, useLocation } from "wouter";
import { Home, PlayCircle, TrendingUp, GraduationCap } from "lucide-react";

export default function BottomNavigation() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-card border-t">
      <div className="flex justify-around py-2">
        <Link href="/" data-testid="nav-home">
          <button className={`flex flex-col items-center py-2 px-4 ${
            isActive("/") ? "text-primary" : "text-muted-foreground"
          }`}>
            <Home className="w-5 h-5 mb-1" />
            <span className="text-xs">Home</span>
          </button>
        </Link>
        
        <Link href="/simulations/call" data-testid="nav-simulations">
          <button className={`flex flex-col items-center py-2 px-4 ${
            isActive("/simulations") ? "text-primary" : "text-muted-foreground"
          }`}>
            <PlayCircle className="w-5 h-5 mb-1" />
            <span className="text-xs">Simulations</span>
          </button>
        </Link>
        
        <Link href="/progress" data-testid="nav-progress">
          <button className={`flex flex-col items-center py-2 px-4 ${
            isActive("/progress") ? "text-primary" : "text-muted-foreground"
          }`}>
            <TrendingUp className="w-5 h-5 mb-1" />
            <span className="text-xs">Progress</span>
          </button>
        </Link>
        
        <Link href="/coaching" data-testid="nav-coach">
          <button className={`flex flex-col items-center py-2 px-4 ${
            isActive("/coaching") ? "text-primary" : "text-muted-foreground"
          }`}>
            <GraduationCap className="w-5 h-5 mb-1" />
            <span className="text-xs">Coach</span>
          </button>
        </Link>
      </div>
    </div>
  );
}
