import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import CallSimulation from "@/pages/simulations/call-simulation";
import MessageSimulation from "@/pages/simulations/message-simulation";
import PaymentSimulation from "@/pages/simulations/payment-simulation";
import FormSimulation from "@/pages/simulations/form-simulation";
import Progress from "@/pages/progress";
import Coaching from "@/pages/coaching";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/simulations/call/:id?" component={CallSimulation} />
      <Route path="/simulations/message/:id?" component={MessageSimulation} />
      <Route path="/simulations/payment/:id?" component={PaymentSimulation} />
      <Route path="/simulations/form/:id?" component={FormSimulation} />
      <Route path="/progress" component={Progress} />
      <Route path="/coaching/:simulationId?" component={Coaching} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="max-w-md mx-auto bg-card min-h-screen relative">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
