import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ArrowLeft, Share, ThumbsUp, Lightbulb, Route, Home } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import BottomNavigation from "@/components/bottom-navigation";
import { getSimulation } from "@/lib/api";
import type { CoachingFeedback } from "@shared/schema";

export default function Coaching() {
  const [, params] = useRoute("/coaching/:simulationId?");
  const simulationId = params?.simulationId;

  const { data: simulation, isLoading } = useQuery({
    queryKey: ["/api/simulations", simulationId],
    queryFn: () => simulationId ? getSimulation(simulationId) : null,
    enabled: !!simulationId
  });

  const feedback = simulation?.feedback as CoachingFeedback | null;

  if (!simulationId || (!isLoading && !simulation)) {
    return (
      <div className="bg-background min-h-screen pb-24">
        <div className="bg-primary text-primary-foreground p-6">
          <div className="flex items-center justify-between mb-4">
            <Link href="/" data-testid="back-button">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-primary-foreground/80 p-0">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h2 className="text-lg font-semibold">AI Coach</h2>
            <div className="w-6"></div>
          </div>
          
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-primary-foreground/20 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Route className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Welcome to AI Coaching!</h3>
            <p className="text-primary-foreground/80">Complete a simulation to receive personalized feedback and coaching tips.</p>
          </div>
        </div>
        
        <div className="p-6">
          <Link href="/" data-testid="button-start-simulation">
            <Button className="w-full">Start a Simulation</Button>
          </Link>
        </div>
        
        <BottomNavigation />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-background min-h-screen pb-24">
        <div className="bg-primary text-primary-foreground p-6">
          <div className="flex items-center justify-between mb-4">
            <Link href="/" data-testid="back-button">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-primary-foreground/80 p-0 animate-pulse">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="w-32 h-6 bg-primary-foreground/20 rounded animate-pulse"></div>
            <div className="w-6"></div>
          </div>
          
          <div className="text-center">
            <div className="w-32 h-32 bg-primary-foreground/20 rounded-full mx-auto mb-4 animate-pulse"></div>
            <div className="w-48 h-6 bg-primary-foreground/20 rounded mx-auto mb-2 animate-pulse"></div>
            <div className="w-32 h-4 bg-primary-foreground/20 rounded mx-auto animate-pulse"></div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="space-y-4 animate-pulse">
            <div className="h-32 bg-muted rounded-lg"></div>
            <div className="h-32 bg-muted rounded-lg"></div>
            <div className="h-32 bg-muted rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  const score = feedback?.score || 0;
  const strokeDasharray = 283; // Circumference of circle with radius 45
  const strokeDashoffset = strokeDasharray - (strokeDasharray * score / 100);

  return (
    <div className="bg-background min-h-screen pb-24" data-testid="coaching-screen">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-6">
        <div className="flex items-center justify-between mb-4">
          <Link href="/" data-testid="back-button">
            <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-primary-foreground/80 p-0">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h2 className="text-lg font-semibold">Performance Review</h2>
          <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-primary-foreground/80 p-0" data-testid="share-button">
            <Share className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Score Circle */}
        <div className="text-center">
          <div className="relative w-32 h-32 mx-auto mb-4">
            <svg className="w-full h-full progress-ring" viewBox="0 0 100 100">
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="rgba(255,255,255,0.2)" 
                strokeWidth="8" 
                fill="none"
              />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="white" 
                strokeWidth="8" 
                fill="none" 
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-3xl font-bold" data-testid="score-display">{score}</div>
                <div className="text-sm text-primary-foreground/80">Score</div>
              </div>
            </div>
          </div>
          <h3 className="text-xl font-semibold">
            {score >= 90 ? "Excellent!" : score >= 80 ? "Great Job!" : score >= 70 ? "Good Work!" : "Keep Practicing!"}
          </h3>
          <p className="text-primary-foreground/80" data-testid="simulation-type">
            {simulation?.type ? simulation.type.charAt(0).toUpperCase() + simulation.type.slice(1) : 'Simulation'} Practice
          </p>
        </div>
      </div>
      
      {/* Feedback Content */}
      <div className="p-6">
        {/* Strengths */}
        <div className="mb-6">
          <h4 className="font-semibold text-lg mb-4 flex items-center">
            <ThumbsUp className="text-primary w-5 h-5 mr-2" />
            Strengths Observed
          </h4>
          <div className="space-y-3" data-testid="strengths-section">
            {feedback?.strengths.map((strength, index) => (
              <Card key={index} className="p-3 bg-primary/5 border border-primary/20">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm" data-testid={`strength-${index}`}>{strength}</p>
                </div>
              </Card>
            ))}
            
            {(!feedback?.strengths.length) && (
              <Card className="p-3 bg-primary/5 border border-primary/20">
                <p className="text-sm text-muted-foreground">Complete the simulation to see your strengths!</p>
              </Card>
            )}
          </div>
        </div>
        
        {/* Areas for Improvement */}
        <div className="mb-6">
          <h4 className="font-semibold text-lg mb-4 flex items-center">
            <Lightbulb className="text-accent w-5 h-5 mr-2" />
            Areas for Improvement
          </h4>
          <div className="space-y-3" data-testid="improvements-section">
            {feedback?.improvements.map((improvement, index) => (
              <Card key={index} className="p-3 bg-accent/5 border border-accent/20">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm" data-testid={`improvement-${index}`}>{improvement}</p>
                </div>
              </Card>
            ))}
            
            {(!feedback?.improvements.length) && (
              <Card className="p-3 bg-accent/5 border border-accent/20">
                <p className="text-sm text-muted-foreground">Keep practicing to identify areas for improvement!</p>
              </Card>
            )}
          </div>
        </div>
        
        {/* Next Steps */}
        <div className="mb-8">
          <h4 className="font-semibold text-lg mb-4 flex items-center">
            <Route className="text-destructive w-5 h-5 mr-2" />
            Practical Next Steps
          </h4>
          <div className="space-y-3" data-testid="next-steps-section">
            {feedback?.nextSteps.map((step, index) => (
              <Card key={index} className="p-3 border hover:bg-muted/50 cursor-pointer transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs font-semibold text-primary">
                      {index + 1}
                    </div>
                    <span className="flex-1 text-sm" data-testid={`next-step-${index}`}>{step}</span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 p-1">
                    <ArrowLeft className="w-4 h-4 rotate-180" />
                  </Button>
                </div>
              </Card>
            ))}
            
            {(!feedback?.nextSteps.length) && (
              <Card className="p-3 border">
                <p className="text-sm text-muted-foreground">Complete simulations to get personalized next steps!</p>
              </Card>
            )}
          </div>
        </div>
        
        {feedback?.overallComment && (
          <Card className="p-4 mb-6 bg-secondary" data-testid="overall-comment">
            <p className="text-sm italic">"{feedback.overallComment}"</p>
          </Card>
        )}
        
        <Link href="/" data-testid="continue-learning-button">
          <Button className="w-full">
            <Home className="w-4 h-4 mr-2" />
            Continue Learning
          </Button>
        </Link>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
