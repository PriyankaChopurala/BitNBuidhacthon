import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Trophy, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/bottom-navigation";
import { getProgress } from "@/lib/api";
import { Link } from "wouter";

export default function ProgressPage() {
  const { data: progressData, isLoading } = useQuery({
    queryKey: ["/api/progress"],
    queryFn: () => getProgress()
  });

  const skillNames: { [key: string]: string } = {
    phone: "Phone Communication",
    messaging: "Chat Communication", 
    payments: "Digital Payments",
    forms: "Form Filling",
    support: "Customer Support"
  };

  return (
    <div className="bg-background min-h-screen pb-24">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Link href="/" data-testid="back-button">
            <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-primary-foreground/80 p-0">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h2 className="text-xl font-bold">Your Progress</h2>
        </div>
        <p className="text-primary-foreground/80">Track your digital skills journey</p>
      </div>
      
      {/* Overall Stats */}
      <div className="p-6">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card className="p-4 text-center">
              <div className="w-8 h-8 bg-muted rounded mx-auto mb-2 animate-pulse"></div>
              <div className="w-12 h-3 bg-muted rounded mx-auto animate-pulse"></div>
            </Card>
            <Card className="p-4 text-center">
              <div className="w-8 h-8 bg-muted rounded mx-auto mb-2 animate-pulse"></div>
              <div className="w-12 h-3 bg-muted rounded mx-auto animate-pulse"></div>
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 mb-6" data-testid="stats-overview">
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1" data-testid="total-simulations">
                {progressData?.totalSimulations || 0}
              </div>
              <div className="text-sm text-muted-foreground">Simulations</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-accent mb-1" data-testid="average-score">
                {progressData?.averageScore || 0}
              </div>
              <div className="text-sm text-muted-foreground">Avg Score</div>
            </Card>
          </div>
        )}
        
        {/* Skill Progress */}
        <div className="mb-6">
          <h3 className="font-semibold mb-4">Skill Progress</h3>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="w-32 h-4 bg-muted rounded animate-pulse"></div>
                    <div className="w-8 h-4 bg-muted rounded animate-pulse"></div>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="bg-muted h-2 rounded-full animate-pulse" style={{width: "60%"}}></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4" data-testid="skill-progress">
              {progressData?.progress.map((skill) => (
                <div key={skill.skillType}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium" data-testid={`skill-name-${skill.skillType}`}>
                      {skillNames[skill.skillType] || skill.skillType}
                    </span>
                    <span className="text-sm text-muted-foreground" data-testid={`skill-score-${skill.skillType}`}>
                      {skill.averageScore}%
                    </span>
                  </div>
                  <Progress 
                    value={skill.averageScore} 
                    className={skill.averageScore >= 80 ? "bg-secondary" : "bg-secondary"}
                    data-testid={`skill-progress-${skill.skillType}`}
                  />
                </div>
              ))}
              
              {(!progressData?.progress.length) && (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="w-8 h-8 mx-auto mb-2" />
                  <p>Complete simulations to track your progress!</p>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Recent Achievements */}
        <div>
          <h3 className="font-semibold mb-4">Recent Achievements</h3>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2].map(i => (
                <div key={i} className="flex items-center space-x-3 p-3 bg-primary/5 rounded-lg border animate-pulse">
                  <div className="w-10 h-10 bg-muted rounded-full"></div>
                  <div className="flex-1">
                    <div className="w-24 h-4 bg-muted rounded mb-1"></div>
                    <div className="w-40 h-3 bg-muted rounded"></div>
                  </div>
                  <div className="w-16 h-3 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-3" data-testid="achievements">
              {progressData?.achievements.map((achievement) => (
                <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    {achievement.type === 'high_scorer' ? (
                      <Trophy className="text-primary-foreground w-5 h-5" />
                    ) : (
                      <Star className="text-primary-foreground w-5 h-5" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium" data-testid={`achievement-title-${achievement.id}`}>
                      {achievement.title}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid={`achievement-description-${achievement.id}`}>
                      {achievement.description}
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(achievement.unlockedAt || new Date()).toLocaleDateString()}
                  </div>
                </div>
              ))}
              
              {(!progressData?.achievements.length) && (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="w-8 h-8 mx-auto mb-2" />
                  <p>Complete simulations to unlock achievements!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
