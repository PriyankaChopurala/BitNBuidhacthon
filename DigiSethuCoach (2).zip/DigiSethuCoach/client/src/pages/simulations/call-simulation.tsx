import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { PhoneOff, Mic, MicOff, Volume2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { createSimulation, getSimulation, sendMessage, completeSimulation } from "@/lib/api";

export default function CallSimulation() {
  const [, params] = useRoute("/simulations/call/:id?");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [callTimer, setCallTimer] = useState(42);
  const [userInput, setUserInput] = useState("");
  const [isMuted, setIsMuted] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<any[]>([]);
  const [currentAIMessage, setCurrentAIMessage] = useState("Hi there! Thank you for calling. How can I help you today?");
  const [isAISpeaking, setIsAISpeaking] = useState(true);

  // Create or get simulation
  const { data: simulation, isLoading } = useQuery({
    queryKey: ["/api/simulations", params?.id],
    queryFn: async () => {
      if (params?.id) {
        return await getSimulation(params.id);
      } else {
        return await createSimulation("call");
      }
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: ({ simulationId, message }: { simulationId: string; message: string }) =>
      sendMessage(simulationId, message),
    onSuccess: (response) => {
      setCurrentAIMessage(response.message);
      // Add AI response to conversation
      setConversationHistory(prev => [
        ...prev,
        { sender: "ai", message: response.message, timestamp: new Date() }
      ]);
      
      if (response.isComplete) {
        setTimeout(() => endCall(), 2000);
      } else {
        setTimeout(() => setIsAISpeaking(false), 3000);
      }
    },
    onError: () => {
      // Add fallback AI response for error
      setCurrentAIMessage("I'm having trouble responding right now. Please try again.");
      setConversationHistory(prev => [
        ...prev,
        { sender: "ai", message: "I'm having trouble responding right now. Please try again.", timestamp: new Date() }
      ]);
      setTimeout(() => setIsAISpeaking(false), 2000);
      
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Complete simulation mutation
  const completeMutation = useMutation({
    mutationFn: (simulationId: string) => completeSimulation(simulationId),
    onSuccess: (data) => {
      setLocation(`/coaching/${simulation?.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to complete simulation.",
        variant: "destructive"
      });
    }
  });

  // Call timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setCallTimer(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Auto-start AI speaking after initial load
  useEffect(() => {
    if (simulation && currentAIMessage) {
      setTimeout(() => setIsAISpeaking(false), 3000);
    }
  }, [simulation, currentAIMessage]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendMessage = () => {
    if (!userInput.trim() || !simulation) return;
    
    // Add user message immediately to conversation
    const userMessage = { sender: "user", message: userInput, timestamp: new Date() };
    setConversationHistory(prev => [...prev, userMessage]);
    
    setIsAISpeaking(true);
    sendMessageMutation.mutate({
      simulationId: simulation.id,
      message: userInput
    });
    setUserInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const endCall = () => {
    if (simulation) {
      completeMutation.mutate(simulation.id);
    }
  };

  if (isLoading) {
    return (
      <div className="call-screen-bg min-h-screen flex items-center justify-center text-white">
        <div className="text-center">
          <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-4 animate-pulse"></div>
          <div className="w-48 h-6 bg-white/20 rounded mx-auto mb-2 animate-pulse"></div>
          <div className="w-32 h-4 bg-white/20 rounded mx-auto animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="call-screen-bg min-h-screen flex flex-col justify-between text-white p-6" data-testid="call-screen">
      {/* Call Header */}
      <div className="text-center pt-12">
        <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
          <img 
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150" 
            alt="HR Manager - Rajesh Kumar" 
            className="w-28 h-28 rounded-full object-cover"
            data-testid="contact-image"
          />
        </div>
        <h2 className="text-xl font-semibold mb-1" data-testid="contact-name">
          {simulation?.scenario.includes("interview") ? "HR Manager" : 
           simulation?.scenario.includes("bank") ? "Bank Agent" : 
           "Customer Service"}
        </h2>
        <p className="text-white/80" data-testid="contact-role">
          {simulation?.scenario.slice(0, 50)}...
        </p>
        <div className="text-lg font-mono mt-4" data-testid="call-timer">
          {formatTime(callTimer)}
        </div>
      </div>
      
      {/* Call Content */}
      <div className="flex-1 flex items-center justify-center">
        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-sm mx-auto" data-testid="conversation-area">
          <div className="text-center mb-4">
            {isAISpeaking ? (
              <>
                <div className="animate-pulse-slow w-3 h-3 bg-white rounded-full mx-auto mb-2" data-testid="ai-speaking-indicator"></div>
                <p className="text-sm">AI is speaking...</p>
              </>
            ) : (
              <>
                <div className="w-3 h-3 bg-white/50 rounded-full mx-auto mb-2"></div>
                <p className="text-sm">Your turn to speak</p>
              </>
            )}
          </div>
          <div className="bg-white/20 rounded-lg p-3 mb-4" data-testid="ai-message">
            <p className="text-sm">"{currentAIMessage}"</p>
          </div>
          <div className="flex space-x-2">
            <Input 
              type="text" 
              placeholder="Type your response..." 
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isAISpeaking || sendMessageMutation.isPending}
              className="flex-1 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/60 text-sm"
              data-testid="message-input"
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!userInput.trim() || isAISpeaking || sendMessageMutation.isPending}
              className="bg-accent hover:bg-accent/80 px-4 py-2"
              data-testid="send-button"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Call Controls */}
      <div className="flex justify-center space-x-6" data-testid="call-controls">
        <Button 
          onClick={() => setIsMuted(!isMuted)}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
            isMuted ? "bg-red-600 hover:bg-red-700" : "bg-white/20 hover:bg-white/30"
          }`}
          data-testid="mute-button"
        >
          {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </Button>
        
        <Button 
          onClick={endCall}
          disabled={completeMutation.isPending}
          className="w-16 h-16 bg-destructive rounded-full flex items-center justify-center hover:bg-destructive/80 transition-colors"
          data-testid="end-call-button"
        >
          <PhoneOff className="w-6 h-6" />
        </Button>
        
        <Button 
          className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
          data-testid="speaker-button"
        >
          <Volume2 className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}
