import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { createSimulation, getSimulation, completeSimulation } from "@/lib/api";

interface FormData {
  fullName: string;
  dateOfBirth: string;
  mobileNumber: string;
  aadhaarNumber: string;
  gender: string;
}

interface ValidationErrors {
  [key: string]: string;
}

export default function FormSimulation() {
  const [, params] = useRoute("/simulations/form/:id?");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    fullName: "",
    dateOfBirth: "",
    mobileNumber: "",
    aadhaarNumber: "",
    gender: ""
  });
  const [errors, setErrors] = useState<ValidationErrors>({});

  // Create or get simulation
  const { data: simulation, isLoading } = useQuery({
    queryKey: ["/api/simulations", params?.id],
    queryFn: async () => {
      if (params?.id) {
        return await getSimulation(params.id);
      } else {
        return await createSimulation("form");
      }
    }
  });

  // Complete simulation mutation
  const completeMutation = useMutation({
    mutationFn: (simulationId: string) => completeSimulation(simulationId),
    onSuccess: (data) => {
      setLocation(`/coaching/${simulation?.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to complete simulation.",
        variant: "destructive"
      });
    }
  });

  const validateStep1 = (): ValidationErrors => {
    const newErrors: ValidationErrors = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    }
    
    if (!formData.dateOfBirth) {
      newErrors.dateOfBirth = "Date of birth is required";
    }
    
    if (!formData.mobileNumber.trim()) {
      newErrors.mobileNumber = "Mobile number is required";
    } else if (!/^\d{10}$/.test(formData.mobileNumber)) {
      newErrors.mobileNumber = "Please enter a valid 10-digit mobile number";
    }
    
    if (!formData.aadhaarNumber.trim()) {
      newErrors.aadhaarNumber = "Aadhaar number is required";
    } else if (!/^\d{12}$/.test(formData.aadhaarNumber.replace(/\s/g, ""))) {
      newErrors.aadhaarNumber = "Please enter a valid 12-digit Aadhaar number";
    }
    
    if (!formData.gender) {
      newErrors.gender = "Please select your gender";
    }
    
    return newErrors;
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  const nextStep = () => {
    const stepErrors = validateStep1();
    setErrors(stepErrors);
    
    if (Object.keys(stepErrors).length === 0) {
      if (currentStep < 3) {
        setCurrentStep(prev => prev + 1);
      } else {
        // Complete the simulation
        toast({
          title: "Form Completed!",
          description: "You've successfully filled out the form. Great job!",
        });
        
        if (simulation) {
          setTimeout(() => {
            completeMutation.mutate(simulation.id);
          }, 1500);
        }
      }
    }
  };

  const previousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-background min-h-screen">
        <div className="bg-card border-b p-4 animate-pulse">
          <div className="flex items-center space-x-3">
            <div className="w-6 h-6 bg-muted rounded"></div>
            <div>
              <div className="w-32 h-4 bg-muted rounded mb-1"></div>
              <div className="w-24 h-3 bg-muted rounded"></div>
            </div>
          </div>
        </div>
        
        <div className="p-4 bg-card border-b">
          <div className="w-48 h-4 bg-muted rounded mb-2"></div>
          <div className="w-full h-2 bg-muted rounded"></div>
        </div>
        
        <div className="p-6 space-y-4">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="animate-pulse">
              <div className="w-24 h-4 bg-muted rounded mb-2"></div>
              <div className="w-full h-10 bg-muted rounded"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const progressPercentage = (currentStep / 3) * 100;

  return (
    <div className="bg-background min-h-screen" data-testid="form-screen">
      {/* Form Header */}
      <div className="bg-card border-b p-4">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground p-0"
            data-testid="back-button"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h2 className="font-semibold" data-testid="form-title">
              {simulation?.scenario.includes("KYC") ? "Bank KYC Form" :
               simulation?.scenario.includes("job") ? "Job Application Form" :
               "Registration Form"}
            </h2>
            <p className="text-sm text-muted-foreground">Complete your profile</p>
          </div>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="p-4 bg-card border-b" data-testid="progress-section">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Step {currentStep} of 3</span>
          <span className="text-sm text-muted-foreground">{Math.round(progressPercentage)}% Complete</span>
        </div>
        <Progress value={progressPercentage} className="transition-all duration-300" />
      </div>
      
      {/* Form Content */}
      <div className="p-6">
        <h3 className="text-lg font-semibold mb-6" data-testid="section-title">
          {currentStep === 1 && "Personal Information"}
          {currentStep === 2 && "Address Details"}
          {currentStep === 3 && "Review & Submit"}
        </h3>
        
        {currentStep === 1 && (
          <div className="space-y-4" data-testid="step-1-form">
            <div>
              <label className="block text-sm font-medium mb-2">Full Name *</label>
              <Input 
                type="text" 
                placeholder="Enter your full name" 
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
                className={errors.fullName ? "border-destructive" : ""}
                data-testid="input-full-name"
              />
              {errors.fullName && (
                <p className="text-sm text-destructive mt-1">{errors.fullName}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Date of Birth *</label>
              <Input 
                type="date" 
                value={formData.dateOfBirth}
                onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                className={errors.dateOfBirth ? "border-destructive" : ""}
                data-testid="input-date-of-birth"
              />
              {errors.dateOfBirth && (
                <p className="text-sm text-destructive mt-1">{errors.dateOfBirth}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Mobile Number *</label>
              <div className="flex">
                <span className="inline-flex items-center px-3 border border-r-0 border-border rounded-l-lg bg-muted text-muted-foreground">+91</span>
                <Input 
                  type="tel" 
                  placeholder="Enter 10-digit mobile number" 
                  value={formData.mobileNumber}
                  onChange={(e) => handleInputChange("mobileNumber", e.target.value)}
                  className={`flex-1 rounded-l-none ${errors.mobileNumber ? "border-destructive" : ""}`}
                  data-testid="input-mobile-number"
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">We'll send an OTP for verification</p>
              {errors.mobileNumber && (
                <p className="text-sm text-destructive mt-1">{errors.mobileNumber}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Aadhaar Number *</label>
              <Input 
                type="text" 
                placeholder="Enter 12-digit Aadhaar number" 
                value={formData.aadhaarNumber}
                onChange={(e) => handleInputChange("aadhaarNumber", e.target.value)}
                className={errors.aadhaarNumber ? "border-destructive" : ""}
                data-testid="input-aadhaar-number"
              />
              {errors.aadhaarNumber && (
                <Alert className="mt-2 border-destructive/20 bg-destructive/10" data-testid="aadhaar-error">
                  <AlertDescription className="text-destructive">
                    {errors.aadhaarNumber}
                  </AlertDescription>
                </Alert>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Gender *</label>
              <div className="flex space-x-4" data-testid="gender-options">
                {["male", "female", "other"].map((option) => (
                  <label key={option} className="flex items-center cursor-pointer">
                    <input 
                      type="radio" 
                      name="gender" 
                      value={option}
                      checked={formData.gender === option}
                      onChange={(e) => handleInputChange("gender", e.target.value)}
                      className="mr-2 text-primary focus:ring-primary"
                      data-testid={`radio-gender-${option}`}
                    />
                    {option.charAt(0).toUpperCase() + option.slice(1)}
                  </label>
                ))}
              </div>
              {errors.gender && (
                <p className="text-sm text-destructive mt-1">{errors.gender}</p>
              )}
            </div>
          </div>
        )}
        
        {currentStep === 2 && (
          <div className="space-y-4" data-testid="step-2-form">
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-lg mb-2">Address Details Section</p>
              <p className="text-sm">This step would contain address fields in a real form.</p>
              <p className="text-sm">For this simulation, we'll skip to review.</p>
            </div>
          </div>
        )}
        
        {currentStep === 3 && (
          <div className="space-y-4" data-testid="step-3-form">
            <div className="text-center py-8">
              <Card className="p-6 bg-primary/5 border border-primary/20">
                <h4 className="text-lg font-semibold text-primary mb-4">Form Completed Successfully!</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  You've demonstrated excellent form-filling skills. Your information has been validated and processed.
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Name:</span>
                    <span className="font-medium" data-testid="review-name">{formData.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mobile:</span>
                    <span className="font-medium" data-testid="review-mobile">+91 {formData.mobileNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gender:</span>
                    <span className="font-medium" data-testid="review-gender">
                      {formData.gender.charAt(0).toUpperCase() + formData.gender.slice(1)}
                    </span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}
        
        <div className="flex space-x-4 mt-8" data-testid="form-navigation">
          <Button 
            variant="outline"
            onClick={previousStep}
            disabled={currentStep === 1}
            className="flex-1"
            data-testid="previous-button"
          >
            Previous
          </Button>
          <Button 
            onClick={nextStep}
            disabled={completeMutation.isPending}
            className="flex-1"
            data-testid="next-button"
          >
            {currentStep === 3 ? "Complete" : "Next Step"}
          </Button>
        </div>
      </div>
    </div>
  );
}
