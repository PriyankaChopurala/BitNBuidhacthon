import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { ArrowLeft, MoreVertical, Store, University, CreditCard, CheckCircle, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { createSimulation, getSimulation, completeSimulation } from "@/lib/api";

export default function PaymentSimulation() {
  const [, params] = useRoute("/simulations/payment/:id?");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("bank");
  const [upiPin, setUpiPin] = useState(["", "", "", ""]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Create or get simulation
  const { data: simulation, isLoading } = useQuery({
    queryKey: ["/api/simulations", params?.id],
    queryFn: async () => {
      if (params?.id) {
        return await getSimulation(params.id);
      } else {
        return await createSimulation("payment");
      }
    }
  });

  // Complete simulation mutation
  const completeMutation = useMutation({
    mutationFn: (simulationId: string) => completeSimulation(simulationId),
    onSuccess: (data) => {
      setLocation(`/coaching/${simulation?.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to complete simulation.",
        variant: "destructive"
      });
    }
  });

  const handlePinChange = (index: number, value: string) => {
    if (value.length <= 1 && /^[0-9]*$/.test(value)) {
      const newPin = [...upiPin];
      newPin[index] = value;
      setUpiPin(newPin);
      
      // Auto-focus next input
      if (value && index < 3) {
        const nextInput = document.querySelector(`input[data-pin-index="${index + 1}"]`) as HTMLInputElement;
        nextInput?.focus();
      }
    }
  };

  const processPayment = async () => {
    const pinFilled = upiPin.every(digit => digit !== "");
    
    if (!pinFilled) {
      toast({
        title: "Invalid PIN",
        description: "Please enter your complete 4-digit UPI PIN.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Payment Successful!",
        description: "₹1,250 has been paid to Raj Electronics Store.",
      });
      
      // Complete simulation after successful payment
      if (simulation) {
        setTimeout(() => {
          completeMutation.mutate(simulation.id);
        }, 1500);
      }
    }, 3000);
  };

  if (isLoading) {
    return (
      <div className="bg-background min-h-screen">
        <div className="payment-gradient text-white p-6 pb-8 animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="w-6 h-6 bg-white/20 rounded"></div>
            <div className="w-32 h-6 bg-white/20 rounded"></div>
            <div className="w-6 h-6 bg-white/20 rounded"></div>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4"></div>
            <div className="w-48 h-6 bg-white/20 rounded mx-auto mb-2"></div>
            <div className="w-32 h-4 bg-white/20 rounded mx-auto"></div>
          </div>
        </div>
        
        <div className="p-6 -mt-4">
          <div className="bg-card rounded-xl shadow-lg p-6 border animate-pulse">
            <div className="w-24 h-8 bg-muted rounded mx-auto mb-4"></div>
            <div className="space-y-4">
              <div className="w-full h-20 bg-muted rounded-lg"></div>
              <div className="w-full h-12 bg-muted rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen" data-testid="payment-screen">
      {/* Payment Header */}
      <div className="payment-gradient text-white p-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setLocation("/")}
            className="text-white hover:text-white/80 p-0"
            data-testid="back-button"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h2 className="text-lg font-semibold" data-testid="header-title">DigiPay Simulator</h2>
          <Button variant="ghost" size="sm" className="text-white hover:text-white/80 p-0" data-testid="menu-button">
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Store className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Pay to Merchant</h3>
          <p className="text-white/80" data-testid="merchant-name">
            {simulation?.scenario.includes("store") ? "Electronics Store" :
             simulation?.scenario.includes("restaurant") ? "Restaurant" :
             "Merchant Store"}
          </p>
        </div>
      </div>
      
      {/* Payment Form */}
      <div className="p-6 -mt-4">
        <Card className="rounded-xl shadow-lg p-6 border" data-testid="payment-form">
          <div className="text-center mb-6">
            <div className="text-3xl font-bold text-primary mb-2" data-testid="payment-amount">₹1,250</div>
            <p className="text-muted-foreground">Amount to pay</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Payment Method</label>
              <div className="space-y-2" data-testid="payment-methods">
                <div 
                  className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedPaymentMethod === "bank" 
                      ? "bg-primary/5 border-primary" 
                      : "hover:bg-muted/50"
                  }`}
                  onClick={() => setSelectedPaymentMethod("bank")}
                  data-testid="bank-payment-method"
                >
                  <University className={`mr-3 w-5 h-5 ${
                    selectedPaymentMethod === "bank" ? "text-primary" : "text-muted-foreground"
                  }`} />
                  <div className="flex-1">
                    <p className="font-medium">Bank Account</p>
                    <p className="text-sm text-muted-foreground">HDFC Bank ****1234</p>
                  </div>
                  {selectedPaymentMethod === "bank" && (
                    <CheckCircle className="text-primary w-5 h-5" />
                  )}
                </div>
                
                <div 
                  className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedPaymentMethod === "upi" 
                      ? "bg-primary/5 border-primary" 
                      : "hover:bg-muted/50"
                  }`}
                  onClick={() => setSelectedPaymentMethod("upi")}
                  data-testid="upi-payment-method"
                >
                  <CreditCard className={`mr-3 w-5 h-5 ${
                    selectedPaymentMethod === "upi" ? "text-primary" : "text-muted-foreground"
                  }`} />
                  <div className="flex-1">
                    <p className="font-medium">UPI ID</p>
                    <p className="text-sm text-muted-foreground">user@paytm</p>
                  </div>
                  {selectedPaymentMethod === "upi" && (
                    <CheckCircle className="text-primary w-5 h-5" />
                  )}
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">UPI PIN</label>
              <div className="grid grid-cols-4 gap-2" data-testid="upi-pin-inputs">
                {upiPin.map((digit, index) => (
                  <Input
                    key={index}
                    type="password"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handlePinChange(index, e.target.value)}
                    data-pin-index={index}
                    data-testid={`pin-input-${index}`}
                    className="w-full h-12 text-center text-lg font-mono focus:outline-none focus:ring-2 focus:ring-primary"
                    disabled={isProcessing}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <Button 
            onClick={processPayment}
            disabled={isProcessing || completeMutation.isPending}
            className="w-full py-3 font-semibold mt-6 transition-colors"
            data-testid="pay-button"
          >
            {isProcessing ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </div>
            ) : (
              "Pay ₹1,250"
            )}
          </Button>
          
          <div className="flex items-center justify-center mt-4 text-sm text-muted-foreground" data-testid="security-notice">
            <Shield className="w-4 h-4 mr-2" />
            Secured by 256-bit encryption
          </div>
        </Card>
      </div>
    </div>
  );
}
