import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Phone, MessageCircle, CreditCard, FileText, GraduationCap, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import BottomNavigation from "@/components/bottom-navigation";
import { getProgress } from "@/lib/api";

export default function Home() {
  const { data: progressData, isLoading } = useQuery({
    queryKey: ["/api/progress"],
    queryFn: () => getProgress()
  });

  const overallProgress = progressData?.progress ? 
    progressData.progress.reduce((sum, p) => sum + p.averageScore, 0) / (progressData.progress.length || 1) : 74;

  return (
    <div className="pb-24">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-primary" data-testid="app-title">DigiSethuCoach</h1>
            <p className="text-muted-foreground">Master Digital Skills</p>
          </div>
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
            <GraduationCap className="text-primary-foreground w-6 h-6" />
          </div>
        </div>
        
        {/* Progress Overview */}
        <Card className="bg-gradient-to-r from-primary to-accent text-primary-foreground p-6 mb-6" data-testid="progress-overview">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">Overall Progress</h3>
              <p className="text-primary-foreground/80">Keep going!</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold" data-testid="overall-progress-score">
                {Math.round(overallProgress)}%
              </div>
              <div className="text-sm text-primary-foreground/80">Complete</div>
            </div>
          </div>
          <Progress value={overallProgress} className="bg-primary-foreground/20" />
        </Card>
        
        {/* Quick Start Simulations */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Practice Simulations</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link href="/simulations/call" data-testid="card-mock-call">
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <Phone className="text-primary w-5 h-5" />
                </div>
                <h3 className="font-medium mb-1">Mock Call</h3>
                <p className="text-sm text-muted-foreground">Practice phone conversations</p>
              </Card>
            </Link>
            
            <Link href="/simulations/message" data-testid="card-chat-practice">
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center mb-3">
                  <MessageCircle className="text-primary w-5 h-5" />
                </div>
                <h3 className="font-medium mb-1">Chat Practice</h3>
                <p className="text-sm text-muted-foreground">Learn messaging skills</p>
              </Card>
            </Link>
            
            <Link href="/simulations/payment" data-testid="card-digital-pay">
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center mb-3">
                  <CreditCard className="text-accent w-5 h-5" />
                </div>
                <h3 className="font-medium mb-1">Digital Pay</h3>
                <p className="text-sm text-muted-foreground">Master UPI payments</p>
              </Card>
            </Link>
            
            <Link href="/simulations/form" data-testid="card-form-filling">
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center mb-3">
                  <FileText className="text-destructive w-5 h-5" />
                </div>
                <h3 className="font-medium mb-1">Form Filling</h3>
                <p className="text-sm text-muted-foreground">Practice online forms</p>
              </Card>
            </Link>
          </div>
        </div>
        
        {/* Recent Activities */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4">Recent Activities</h2>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2].map(i => (
                <div key={i} className="p-3 bg-secondary rounded-lg animate-pulse">
                  <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-3" data-testid="recent-activities">
              {progressData?.recentActivities.slice(0, 2).map((activity, index) => (
                <div key={activity.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      {activity.type === 'call' && <Phone className="text-primary-foreground w-4 h-4" />}
                      {activity.type === 'payment' && <CreditCard className="text-primary-foreground w-4 h-4" />}
                      {activity.type === 'message' && <MessageCircle className="text-primary-foreground w-4 h-4" />}
                      {activity.type === 'form' && <FileText className="text-primary-foreground w-4 h-4" />}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{activity.scenario.slice(0, 30)}...</p>
                      <p className="text-xs text-muted-foreground">
                        Completed {new Date(activity.completedAt || new Date()).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-primary" data-testid={`activity-score-${index}`}>
                      {activity.score || 'N/A'}
                    </div>
                    <div className="text-xs text-muted-foreground">Score</div>
                  </div>
                </div>
              ))}
              
              {(!progressData?.recentActivities.length) && (
                <div className="text-center py-8 text-muted-foreground">
                  <Star className="w-8 h-8 mx-auto mb-2" />
                  <p>Start your first simulation to see activities here!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
