import { apiRequest } from "./queryClient";
import type { CoachingFeedback, Simulation, UserProgress, Achievement } from "@shared/schema";

export type ProgressData = {
  progress: UserProgress[];
  achievements: Achievement[];
  totalSimulations: number;
  averageScore: number;
  recentActivities: Array<{
    id: string;
    type: string;
    scenario: string;
    score: number | null;
    completedAt: Date | null;
  }>;
};

export async function createSimulation(type: string): Promise<Simulation> {
  const response = await apiRequest("POST", "/api/simulations", { type });
  return response.json();
}

export async function getSimulation(id: string): Promise<Simulation> {
  const response = await apiRequest("GET", `/api/simulations/${id}`);
  return response.json();
}

export async function sendMessage(simulationId: string, message: string): Promise<{
  message: string;
  isComplete: boolean;
}> {
  const response = await apiRequest("POST", `/api/simulations/${simulationId}/messages`, {
    message,
    sender: "user"
  });
  return response.json();
}

export async function completeSimulation(simulationId: string): Promise<{
  simulation: Simulation;
  feedback: CoachingFeedback;
}> {
  const response = await apiRequest("POST", `/api/simulations/${simulationId}/complete`);
  return response.json();
}

export async function getProgress(): Promise<ProgressData> {
  const response = await apiRequest("GET", "/api/progress");
  return response.json();
}
